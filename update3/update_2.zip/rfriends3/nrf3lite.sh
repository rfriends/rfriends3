#!/bin/sh
# 録音ツール 2021/06/09
#
# sh ex_rfriends.sh menu,ui,height,width
#
# menu 0:normal 1:lite
# menu 0:cui 1:tui
# height 20-100
# width 50-200
#

# 2026/11/08
echo
echo この機能のサポートは終了しました。
echo
exit


cd `dirname $0`
base=`pwd`/

ex=ex_rfriends
#opt=1,1,24,80
opt=1,1,0,0

sh ${base}$ex.sh $opt

echo done
