#!/bin/sh
# -----------------------------------------
# rfriends3 (at,cron -> systemd )
# 作成　2026/02/16
# 修正　2026/02/16
# 確認　
# -----------------------------------------
cd `dirname $0`
base=`pwd`
ver=$base/_Rfriends3

if [ ! -f $ver ]; then
	echo $ver ファイルがありません
	echo ディレクトリ構成が間違っています。
	echo
	exit
fi
# -----------------------------------------
echo
cat $ver
echo ベースディレクトリは　$base です
echo
echo "ジョブスケジューリングをsystemd から at,cronに変更します。"
echo
# -----------------------------------------
systemdini=$base/config/systemd.ini
if [ ! -f $systemdini ]; then
    echo $systemdini ファイルが存在しません
    exit
fi
# -----------------------------------------
sys=`pgrep -o systemd`
ret=$?
if [ $ret -ne 0 ]; then
    echo "systemd を確認できません。
    exit
fi

if [ $sys -ne 1 ] ;then
    echo "systemd が動作していません。
    exit
fi
# -----------------------------------------
user=`whoami`
#
echo 既存の予約および自動実行設定は破棄されます
echo
read -p "実行しますか ? (y/N): " yn
case "$yn" in [yY]*) ;; *) echo "abort." ; exit ;; esac
# --------------------------------------
systemduserdir="/home/$user/.config/systemd/user/";
rm -rf $systemduserdir
echo 予約および自動実行設定をクリアしました
# --------------------------------------
systemctl --user daemon-reload
systemctl --user reset-failed
# --------------------------------------
# システムの起動時にサービスを起動しない
loginctl disable-linger $user
if [ $? -ne 0 ]; then
    echo loginctl の実行に失敗しました
    exit
fi
# --------------------------------------
cat <<EOF > config/systemd.ini
; ------------------------------------------------
; systemd.ini
; 2025/01/11 new
; ------------------------------------------------
; システム管理方式
;
; cron_type_lnx
; = 0 cron
; = 1 systemd
;
; at_type_lnx
; = 0 at
; = 1 systemd
;
; ------------------------------------------------
[systemd]
cron_type_lnx = 0
at_type_lnx = 1
; ------------------------------------------------
EOF

echo $systemdiniファイルをat,cronタイプに設定しました。
echo
echo 正常終了しました。
# -----------------------------------------
# 終了
# -----------------------------------------
echo
echo finished
exit
# -----------------------------------------
