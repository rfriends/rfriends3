<?php
 function rf_error_sleep() { } function dir_check($dir,$dir_init) { global $iniusrdir; if (!array_key_exists($dir, $iniusrdir)) { return $dir_init; } $str = trim($iniusrdir[$dir]); $str = mb_convert_kana($str, "as"); if (strlen($str) !== mb_strlen($str)) { return $dir_init; } $chrs = array('\\','/',':','*','?','"','<','>','|',' '); $str = str_replace($chrs,"_",$str); return $str; } function rf_service_mode_init() { $svcmode = array(); $svcmode["service_mode"] = 0; $svcmode["service_ext"] = 0; $svcmode["service_key"] = ""; $svcmode["service_mgc"] = ""; $svcmode["service_maintenance"] = 0; $svcmode["service_update_beta"] = 0; $svcmode["service_update_beta_mgc"] = ""; $svcmode["service_update_forbid"] = 0; $svcmode["service_log_errors"] = 0; $svcmode["service_log_ffmpeg"] = 0; $svcmode["service_debug"] = 0; $svcmode["service_ajax"] = 0; return $svcmode; } function rf_service_mode_check($iniservice) { if (!array_key_exists("service_mode", $iniservice)) return false; if (!array_key_exists("service_ext", $iniservice)) return false; if (!array_key_exists("service_key", $iniservice)) return false; if (!array_key_exists("service_mgc", $iniservice)) return false; if (!array_key_exists("service_maintenance", $iniservice)) return false; if (!array_key_exists("service_update_beta", $iniservice)) return false; if (!array_key_exists("service_update_beta_mgc", $iniservice)) return false; if (!array_key_exists("service_update_forbid", $iniservice)) return false; if (!array_key_exists("service_log_errors", $iniservice)) return false; if (!array_key_exists("service_log_ffmpeg", $iniservice)) return false; if (!array_key_exists("service_debug", $iniservice)) return false; if (!array_key_exists("service_ajax", $iniservice)) return false; if (!array_key_exists("serv1ce_m0de", $iniservice)) return false; return true; } function rf_service_mode($fl2) { $svcmode = rf_service_mode_init(); if (!file_exists($fl2)) return $svcmode; $iniservice = @parse_ini_file($fl2); if ($iniservice === false) return $svcmode; if (rf_service_mode_check($iniservice) === false) return $svcmode; if ($iniservice["service_mode"] == 1) $svcmode["service_mode"] = 1; if ($iniservice["service_ext"] == 1) $svcmode["service_ext"] = 1; $svcmode["service_key"] = $iniservice["service_key"]; $svcmode["service_mgc"] = $iniservice["service_mgc"]; if ($iniservice["service_maintenance"] == 1) $svcmode["service_maintenance"] = 1; if ($iniservice["service_update_beta"] == 1) $svcmode["service_update_beta"] = 1; $svcmode["service_update_beta_mgc"] = $iniservice["service_update_beta_mgc"]; if ($iniservice["service_update_forbid"] == 1) $svcmode["service_update_forbid"] = 1; if ($iniservice["service_log_errors"] == 1) $svcmode["service_log_errors"] = 1; if ($iniservice["service_log_ffmpeg"] == 1) $svcmode["service_log_ffmpeg"] = 1; if ($iniservice["service_debug"] == 1) $svcmode["service_debug"] = 1; if ($iniservice["service_ajax"] == 1) $svcmode["service_ajax"] = 1; return $svcmode; } $ptedir = $base0."_pte".$DS; $os_s = PHP_OS; $os_l = php_uname(); $cfgdir = $base."config".$DS; $defdir = $base."template".$DS; $scrdir = $base."script".$DS; $etcdir = $base."etc".$DS; $rsvdir = $base."rsv".$DS; $extdir = $base."ext".$DS; $defkwdir = $defdir."kw".$DS; $defkwtemplatedir = $defdir."kw_template".$DS; $schdir = $rsvdir."sch".$DS; $htmldir = $scrdir."html".$DS; $homedir = rfgw_get_homedir(); $usrdir_link = $htmldir."temp".$DS."usr".$DS; $usrdir_sys = $base."usr".$DS; $tmpdir_sys = $base."tmp".$DS; $usrdef = $etcdir."usrdef"; $tmpdef = $etcdir."tmpdef"; $pcastdef = $etcdir."pcastdef"; $editor = $etcdir."rf_editor"; $rfriendsini = "rfriends.ini"; $rfriendsforceini = "rfriends_force.ini"; $rfplayini = "rfplay.ini"; $rfriendstag = "rfriends_tag.ini"; $rfriendstxt = $rfproduct.".txt"; $premiumini = "premium.ini"; $crontabtxt = "crontab"; $sendmailini = "sendmail.ini"; $usrdirini = "usrdir.ini"; $serviceini = "service.ini"; $systemdini = "systemd.ini"; $common_kw = "common.dat"; $radiko_kw = "radiko.dat"; $radiru_kw = "radiru.dat"; $radiru_other_kw = "radiru_other.dat"; $radiru_vod_kw = "radiru_vod.dat"; $radiru_gogaku_kw = "radiru_gogaku.dat"; $timefree_kw = "timefree.dat"; $station_kw = "station.dat"; $program_kw = "program.dat"; $premium_kw = "premium.dat"; $delay_kw = "delay.dat"; $delivery_kw = "delivery.dat"; $radiko_callsigndat = "radiko_callsign.csv"; $radiru_callsigndat = "radiru_callsign.csv"; $podcastdat = "podcast.dat"; $radiko_genredat = "radiko_genre.dat"; $radiru_genredat = "radiru_genre.dat"; $dirindexdat = "dirindex.css"; $webradiodat = "webradio.dat"; $listenradiodat = 'listenradio.dat";
// ---------------------------------------------
// scrdir
$google_podcastsdat ="google_podcasts.dat";
// ---------------------------------------------
$kw_dat = array(
"station"    => $station_kw,
"common"    => $common_kw,
"radiko"    => $radiko_kw,
"radiru"    => $radiru_kw,
"radiru_other"  => $radiru_other_kw,
"timefree"  => $timefree_kw,
"radiru_vod"  => $radiru_vod_kw,
"radiru_gogaku"  => $radiru_gogaku_kw,
"premium"   => $premium_kw,
"program"   => $program_kw,
"delivery"   => $delivery_kw,
"delay"   => $delay_kw,
);

$kw_name_dat = array(
"station"    => "放送局",
"common"    => "共通",
"radiko"    => "ラジコ",
"timefree"  => "タイムフリー",
"premium"   => "エリアフリー",
"radiru"    => "らじる",
"radiru_other"  => "地域",
"radiru_vod"  => "聞き逃し",
"radiru_gogaku"  => "ゴガク",
"program"   => "重複番組",
"delivery"   => "番組配送",
"delay"   => "配信遅れ",
);

$setting_name_dat = array(
 "rfriends.ini" => "パラメータ設定"
,"rfriends_tag.ini" => "タグ設定"
,"radiko_callsign.csv" => "ラジココールサイン設定"
,"radiru_callsign.csv" => "らじるコールサイン設定"
//,"dirindex.css" => "webdav css設定(linux)"
,"podcast.dat" => "ポッドキャスト設定"
,"sendmail.ini" => "メール設定"
,"usrdir.ini" => "録音ディレクトリ設定"
,"premium.ini" => "ラジコプレミアム設定"
,"user_process.bat" => "ユーザプロセス(win)"
,"user_process.sh" => "ユーザプロセス(linux)"
,"user_process2.bat" => "ユーザプロセス2(win)"
,"user_process2.sh" => "ユーザプロセス2(linux)"
,"crontab" => "デイリー処理設定(linux)"
,"rfplay.ini" => "パラメータ(rfplay)設定"
,"systemd.ini" => "システムタイプ(systemd)設定"
);

// authtoken
$auth_token = "";
// エリア 自動で設定される
$home_area_code = "";
$area_code = "";
$nowarea = ",Japan";
// 東京,仙台,名古屋,大阪,札幌,広島,松山,福岡
$radiru_area_1    = "tokyo"; // 東京
//
// $ex_type
// unknown 3,4,6,7
//
$ex_dummy   = -99;
$ex_daily   = -1;
$ex_clean   = 0;
$ex_radiko  = 1;
$ex_radiru  = 2;
$ex_timefree    = 5;
$ex_radiru_vod  = 8;
$ex_radiru_gogaku = 9;
$ex_podcast = 10;

$svcmode["service_mode"] = 0;
$svccode = 2;
// ---------------------------------------------
set_rfriends_dir();
// ---------------------------------------------
if (!file_exists($base.$rfriends)) {
    echo "file not found : $base.$rfriends".$DS;
    exit(1);
}
$rfriends_ver = trim(file_get_contents($base.$rfriends));
$rfriends_parts = explode(" ", $rfriends_ver);
// ================================================================= systemd
rfgw_if_systemd();
$ret = rfgw_systemd_init();
if ($ret === false){
    //echo "rfgw_systemd_init failed".$DS;
    $cron_type_lnx = 0;
    $at_type_lnx = 0;
}

$main_pid = getenv('MAINPID');
if ($main_pid === false) $main_pid = -1;

//echo_msg(2,"init_mode : $init_mode cron : $cron_type_lnx at : $at_type_lnx");
// ================================================================= ini
$fl0 = $scrdir.$rfriendsini;
$fl1 = $defdir.$rfriendsini;
$fl2 = $cfgdir.$rfriendsini;
//rf_cfginit($rfriendsini);
copy_defusr(0, $rfriendsini);
copy_defusr(0, $rfplayini);
copy_defusr(0, $systemdini);

$inidata1 = @parse_ini_file($fl0);
if ($inidata1 === false) {
    echo "\n";
    echo "システム設定が間違っています。: $fl0 \n";
    exit(1);
}
$inidata2 = @parse_ini_file($fl2);
if ($inidata2 === false) {
    $inidata2 = array();
    echo "\n";
    echo "ユーザ設定が間違っています。: $fl2 \n";
    echo "設定を無視します。\n";
    rf_error_sleep();

/*
    echo "\n";
    echo "$rfriendsini を初期化しますか? (y/N): ";
    $ans = trim(fgets(STDIN, 128));
    echo "\n";
    if ($ans != "y" && $ans != "Y") {
        exit(1);
    }
    copy($fl2, $fl2.".bak");
    copy($fl1, $fl2);
    $inidata2 = parse_ini_file($fl2);
    if ($inidata2 === false) {
        echo "システム設定（テンプレート）が間違っています。: $fl2 \n";
        exit(1);
    }
*/
}
// ================================================================= ini set
$inidata = array_merge($inidata1, $inidata2);
$ret = set_inidata($inidata, $inidata1);
$ini_usrdir   = rf_ini($inidata, "usrdir");
$ini_tmpdir   = rf_ini($inidata, "tmpdir");
//$ini_pcastdir = rf_ini($inidata, "pcastdir");
// ================================================================= usrdir
$fl0 = $scrdir.$usrdirini;
$fl1 = $defdir.$usrdirini;
$fl2 = $cfgdir.$usrdirini;
//rf_cfginit($usrdirini);
copy_defusr(0, $usrdirini);
//旧設定がない
if ($ini_usrdir == "" && $ini_tmpdir == "") {
    if (file_exists($fl2)) {
        $iniusrdir = @parse_ini_file($fl2);
        if ($iniusrdir === false) {
            echo "\n";
            echo "録音ディレクトリ設定が間違っています。: $fl2 \n";
            echo "設定を無視します。\n";
            $iniusrdir = array();
            rf_error_sleep();
        }
        $ini_usrdir2 = "";
        $ini_tmpdir2 = "";
        $ini_pcastdir2 = "";

        if (array_key_exists("usrdir", $iniusrdir)) {
            $ini_usrdir2   = $iniusrdir["usrdir"];
        }
        if (array_key_exists("tmpdir", $iniusrdir)) {
            $ini_tmpdir2   = $iniusrdir["tmpdir"];
        }
//        if (array_key_exists("pcastdir", $iniusrdir)) {
//            $ini_pcastdir2   = $iniusrdir["pcastdir"];
//        }
	    $ini_cpath = "yes";
        if (array_key_exists("convertpath", $iniusrdir)) {
            $ini_cpath   = strtolower($iniusrdir["convertpath"]);
	        if ($ini_cpath != "no") $ini_cpath = "yes";
        }
        $usrdir   = $base."usr".$DS;
        $tmpdir   = $base."tmp".$DS;

        $pcastdir = $usrdir."podcast".$DS;
        $tmpusrdir = $tmpdir."usr".$DS;

        $ret = custom_dir($usrdef, $usrdir, $ini_usrdir2, $ini_cpath);
        if ($ret !== false) {
            if (file_exists($ret)) {
                $usrdir = $ret;
                $pcastdir = $usrdir."podcast".$DS;
            }
        }

        $ret = custom_dir($tmpdef, $tmpdir, $ini_tmpdir2, $ini_cpath);
        if ($ret !== false) {
            if (file_exists($ret)) {
                $tmpdir = $ret;
                $tmpusrdir = $tmpdir."usr".$DS;
            }
        }

// 2026/01/24
// 2026/02/26
        if (!is_writable($usrdir)) {
            $usrdir   = $base."usr".$DS;
            $pcastdir = $usrdir."podcast".$DS;
        }

        if (!is_writable($tmpdir)) {
            $tmpdir   = $base."tmp".$DS;
            $tmpusrdir = $tmpdir."usr".$DS;
        }
    }
//
// dir設定　20210829

    $dir_log           = "log";
    $dir_radiko        = "radiko";
    $dir_radiru        = "radiru";
    $dir_timefree      = "timefree";
    $dir_radiru_vod    = "radiru_vod";
    $dir_radiru_gogaku = "radiru_gogaku";
    $dir_kw            = "kw";
    $dir_kwbackup      = "kwbackup";
    $dir_podcast       = "podcast";

    $dir_change        = dir_check("dir_change","off");
    if ($dir_change == "on") {
        $dir_log           = dir_check("dir_log","log");
        $dir_radiko        = dir_check("dir_radiko","radiko");
        $dir_radiru        = dir_check("dir_radiru","radiru");
        $dir_timefree      = dir_check("dir_timefree","timefree");
        $dir_radiru_vod    = dir_check("dir_radiru_vod","radiru_vod");
        $dir_radiru_gogaku = dir_check("dir_radiru_gogaku","radiru_gogaku");
        $dir_kw            = dir_check("dir_kw","kw");
        $dir_kwbackup      = dir_check("dir_kwbackup","kwbackup");
        $dir_podcast       = dir_check("dir_podcast","podcast");
    }
}
// ================================================================= tag
$fl0 = $scrdir.$rfriendstag;
$fl1 = $defdir.$rfriendstag;
$fl2 = $cfgdir.$rfriendstag;
//rf_cfginit($rfriendstag);
copy_defusr(0, $rfriendstag);

$tagdata1 = @parse_ini_file($fl0);
if ($tagdata1 === false) {
    echo "\n";
    echo "システムタグ設定が間違っています。: $fl0 \n";
    exit(1);
}
$tagdata2 = @parse_ini_file($fl2);
if ($tagdata2 === false) {
    $tagdata2 = array();
    echo "\n";
    echo "ユーザタグ設定が間違っています。: $fl2 \n";
    echo "設定を無視します。\n";
    rf_error_sleep();
/*
    echo "\n";
    echo "$rfriendstag を初期化しますか? (y/N): ";
    $ans = trim(fgets(STDIN, 128));
    echo "\n";
    if ($ans != "y" && $ans != "Y") {
        exit(1);
    }
    copy($fl2, $fl2.".bak");
    copy($fl1, $fl2);
    $tagdata2 = parse_ini_file($fl2);
    if ($inidata2 === false) {
        echo "タグ設定（テンプレート）が間違っています。: $fl2 \n";
        exit(1);
    }
*/
}
// ================================================================= tag set
$tagdata = array_merge($tagdata1, $tagdata2);
$ret = set_tagdata($tagdata, $tagdata1);
// =================================================================
$radiko_pre = "K_";
$radiru_pre = "R_";

$sch_exrecord       = "ExRecord";
$schrfriends_head   = "\\$sch_head\\$sch_exrecord";
$schradiko_head     = "\\$sch_head\\radiko\\$radiko_pre";
$schradiru_head     = "\\$sch_head\\radiru\\$radiru_pre";
// ================================================================= ini dir
$auth_token_dat = $tmpdir."rfriends_auth_token";
//$rsvdir   = $tmpdir."rsv".$DS;
//$schdir       = $tmpdir."sch".$DS;
// ---------------------------------------------
// 20210829
$logdir               = $usrdir.$dir_log.$DS;
$radiko_recdir        = $usrdir.$dir_radiko.$DS;
$radiru_recdir        = $usrdir.$dir_radiru.$DS;
$timefree_recdir      = $usrdir.$dir_timefree.$DS;
$radiru_vod_recdir    = $usrdir.$dir_radiru_vod.$DS;
$radiru_gogaku_recdir = $usrdir.$dir_radiru_gogaku.$DS;
$kwdir                = $usrdir.$dir_kw.$DS;
$kwbackupdir          = $usrdir.$dir_kwbackup.$DS;
$podcast_recdir       = $usrdir.$dir_podcast.$DS;
// ================================================================= kw
$common_keyword_dat   = $kwdir.$common_kw ;
$radiko_keyword_dat   = $kwdir.$radiko_kw;
$radiru_keyword_dat   = $kwdir.$radiru_kw;
$radiru_other_keyword_dat   = $kwdir.$radiru_other_kw;
$timefree_keyword_dat = $kwdir.$timefree_kw;
$station_keyword_dat  = $kwdir.$station_kw;
$double_keyword_dat  = $kwdir.$program_kw;
$premium_keyword_dat  = $kwdir.$premium_kw;

$radiru_vod_keyword_dat   = $kwdir.$radiru_vod_kw;
$radiru_gogaku_keyword_dat= $kwdir.$radiru_gogaku_kw;
// ================================================================= edit
$edit_fn = array(
    $rfriendsini    => array(21,$cfgdir),
    $rfriendstag    => array(22,$cfgdir),
    $rfriendstxt    => array(23,$base),
    $common_kw      => array(24,$kwdir),
    $radiko_kw      => array(25,$kwdir),
    $radiru_kw      => array(26,$kwdir),
    $radiru_other_kw=> array(27,$kwdir),
    $timefree_kw    => array(28,$kwdir),
    $station_kw     => array(29,$kwdir),
    $premiumini     => array(30,$cfgdir),
    $premium_kw     => array(31,$kwdir),
    $crontabtxt     => array(32,$cfgdir),
    $sendmailini    => array(33,$cfgdir),
    $usrdirini    => array(34,$cfgdir),

    $radiru_vod_kw=> array(35,$kwdir),
    $radiru_gogaku_kw=> array(36,$kwdir),
    $program_kw     => array(37,$kwdir),
    $radiko_callsigndat     => array(38,$cfgdir),
);
$edit_fnam = "";
// ================================================================= radiru area
$radiruareafile = $tmpdir."rfriends_radiruarea";
// ================================================================= premium
premium_initialize();
// ================================================================= service mode
$fl2 = $usrdir.$serviceini;
$svcmode = rf_service_mode($fl2);
// ================================================================= sendmail
$fl0 = $scrdir.$sendmailini;
$fl1 = $defdir.$sendmailini;
$fl2 = $cfgdir.$sendmailini;
//rf_cfginit($sendmailini);
copy_defusr(0, $sendmailini);
//旧設定
//if ($send_mail_mode == 0) {
    $send_mail_mode = 0;
    $send_mail_remain = 0;

    $send_mail_host = "";
    $send_mail_port = 0;
    $send_mail_user = "";
    $send_mail_pass = "";

    $send_mail_from = "";
    $send_mail_from_nm = "";
    $send_mail_to   = "";
    $send_mail_to_nm = "";

    if (file_exists($fl2)) {
        $inisendmail = @parse_ini_file($fl2);
        if ($inisendmail === false) {
            echo "\n";
            echo "sendmail設定が間違っています。: $fl2 \n";
            echo "設定を無視します。\n";
            rf_error_sleep();
        } else {

        if (array_key_exists("send_mail_mode", $inisendmail)) {
            $send_mail_mode     = $inisendmail["send_mail_mode"];
        }
        if (array_key_exists("send_mail_remain", $inisendmail)) {
            $send_mail_remain   = $inisendmail["send_mail_remain"];
        }
        if (array_key_exists("send_mail_host", $inisendmail)) {
            $send_mail_host     = $inisendmail["send_mail_host"];
        }
        if (array_key_exists("send_mail_port", $inisendmail)) {
            $send_mail_port     = $inisendmail["send_mail_port"];
        }
        if (array_key_exists("send_mail_user", $inisendmail)) {
            $send_mail_user     = $inisendmail["send_mail_user"];
        }
        if (array_key_exists("send_mail_pass", $inisendmail)) {
            $send_mail_pass     = $inisendmail["send_mail_pass"];
        }
        if (array_key_exists("send_mail_from", $inisendmail)) {
            $send_mail_from     = $inisendmail["send_mail_from"];
        }
        if (array_key_exists("send_mail_from_nm", $inisendmail)) {
            $send_mail_from_nm  = $inisendmail["send_mail_from_nm"];
        }
        if (array_key_exists("send_mail_to", $inisendmail)) {
            $send_mail_to       = $inisendmail["send_mail_to"];
        }
        if (array_key_exists("send_mail_to_nm", $inisendmail)) {
            $send_mail_to_nm    = $inisendmail["send_mail_to_nm"];
        }

        if ($send_mail_mode < 0) {
            $send_mail_mode = 0;
        }
        if ($send_mail_mode > 4) {
            $send_mail_mode = 4;
        }
	// LINE
/*
        if (array_key_exists("send_mail_line_mode", $inisendmail)) {
            $send_mail_line_mode     = $inisendmail["send_mail_line_mode"];
	}
        if (array_key_exists("send_mail_line_token", $inisendmail)) {
            $send_mail_line_token     = $inisendmail["send_mail_line_token"];
	}

        if ($send_mail_line_mode < 0) {
            $send_mail_line_mode = 0;
        }
        if ($send_mail_line_mode > 3) {
            $send_mail_line_mode = 3;
        }
*/
// 2021/03/19 line 機能中止
// 2021/05/10 line 解除
// 2025/03/31 line サービス終了
        $send_mail_line_mode = 0;
//
        }
    }
//}
// ================================================================= callsign
$radiko_callsign_db = array();
//rf_cfginit($radiko_callsigndat);
copy_defusr(0, $radiko_callsigndat);

if ($radiko_callsign == 1) {

$fl = $cfgdir.$radiko_callsigndat;

//echo "$fl\n";

$radiko_callsign_db = rf_get_csv($fl);
}
// ---------------------------------------------------------
$radiru_callsign_db = array();
//rf_cfginit($radiru_callsigndat);
copy_defusr(0, $radiru_callsigndat);

if ($radiru_callsign == 1) {

$fl = $cfgdir.$radiru_callsigndat;

//echo "$fl\n";

$radiru_callsign_db = rf_get_csv($fl);
}
// ================================================================= genre
$fl = $scrdir.$radiru_genredat;
$radiru_genre_db = rf_get_csv($fl);
// ================================================================= podcast
copy_defusr(0, $podcastdat);
// ================================================================= webradio
copy_defusr(0, $webradiodat);
copy_defusr(0, $listenradiodat);
// ================================================================= dirindex.css
copy_defusr(0, $dirindexdat);
//copy_defusr_sub(0,$dirindexdat,$cfgdir,$htmldir);
rf_copy_newonly($defdir.$dirindexdat,$htmldir.$dirindexdat);
// ================================================================= user_process
//rf_cfginit("user_process.bat");
//rf_cfginit("user_process.sh");
copy_defusr(0, "user_process.bat");
copy_defusr(0, "user_process.sh");
copy_defusr(0, "user_process2.bat");
copy_defusr(0, "user_process2.sh");
// =================================================================
