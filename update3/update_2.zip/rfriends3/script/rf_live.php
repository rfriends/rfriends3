<?php
function rfriends_auth_audio($ex_type,$area,$channel) { global $ex_radiko; global $ex_timefree; global $premium; global $radiko_auth_mode; if ($ex_type == $ex_radiko || $ex_type == 3 || $ex_type == $ex_timefree) { $mode = rf_premium_mode($ex_type,$area,$channel); $authtoken = rfriends_auth_radiko($mode,$area,0); if (is_null($authtoken)) { echo_msg(2, "認証モード:$radiko_auth_mode  プレミアム:$mode  録音エリア:$area  CH:$channel"); echo_msg(2, "authtoken が取得できませんでした。"); return false; } } return $authtoken; } function rfriends_live($ex_type,$para,$flg) { global $ui_mode; if ($ui_mode == 2) { if ($para[9] != ";") { msgx('<p><img src='.$para[9].' id="sndimg"></p>'); } else if($ex_type == $ex_radiru || $ex_type == $ex_radiru_vod) { $ch_cs = callsign2($para[6]); if ($ch_cs != "UNKNOWN") { $img = sprintf($station_logo_url, $ch_cs); msgx('<p><img src='.$img.' id="sndimg"></p>'); } } } $ret = rfriends_live_sub($ex_type,$para,$flg,1,1); return $ret; } function rfriends_audio($ex_type,$para,$flg) { global $tmpdir; global $htmldir; global $ui_mode; if ($ui_mode == 2) { if ($para[9] != ";") { msgx('<p><img src='.$para[9].' id="sndimg"></p>'); } } $piddata = rfmenu_play_abort_all(); $files = $htmldir."/temp/playtf_*.m3u8"; foreach (glob($files) as $val ) { unlink($val); } $snd = $para[11]; msgx("<audio controls src=$snd> </audio>"); return true; } function rfriends_live_sub($ex_type,$para,$flg,$auto,$tf7) { global $station_logo_url; global $ex_radiko; global $ex_radiru; global $ex_timefree; global $ex_radiru_vod; global $ex_radiru_gogaku; global $ex_podcast; global $ex_webradio; global $ex_webradio_cors; global $ex_misc; global $nowarea; global $auth_token; global $ui_mode; global $scrdir; global $tmpdir; global $htmldir; $piddata = rfmenu_play_abort_all(); $files = $htmldir."/temp/playtf_*.m3u8"; foreach (glob($files) as $val ) { unlink($val); } $org = 0; switch($ex_type) { case $ex_radiko: $opt = rfriends_live_radiko($ex_type,$para,$flg); break; case $ex_timefree: $opt = rfriends_live_timefree($ex_type,$para,$flg,$org,$tf7); break; case $ex_radiru: $opt = rfriends_live_radiru($ex_type,$para,$flg); break; case $ex_radiru_vod: case $ex_radiru_gogaku: $opt = rfriends_live_radiru_vod($ex_type,$para,$flg); break; case $ex_podcast: $opt = rfriends_live_podcast($ex_type,$para,$flg); break; case $ex_webradio: $channel = $para[6]; $ch_type = rf_webradio_type($ex_type,$channel); $opt = rfriends_live_webradio($ex_type,$para,$flg); break; case $ex_webradio_cors: $targetM3u8Url = $para[11]; if ($targetM3u8Url == null) { return false; } $proxyScript = "ht_cors_radiko.php"; $targetOrigin = "https://listenradio.jp"; ht_exaudio_cors2($proxyScript, $targetM3u8Url, $targetOrigin, $token = ""); return true; break; case $ex_misc: default: $opt = rfriends_live_misc($ex_type,$para,$flg); break; } if ($opt === false) return false; if ($auto == 1 && $ui_mode == 2) { $tmp = explode(",",base64_decode($opt)); $url = $tmp[4]; if ($ex_type == $ex_radiko) { $tmp = explode(",",base64_decode($opt)); $targetM3u8Url = str_replace('"','',$tmp[4]); if ($targetM3u8Url == null) { return false; } $proxyScript = "ht_cors_radiko.php"; $targetOrigin = "https://radiko.jp"; $nw = explode(",",$nowarea); $area = $nw[0]; $channel = $para[6]; $authtoken = rfriends_auth_audio($ex_type,$area,$channel); ht_exaudio_cors2($proxyScript, $targetM3u8Url, $targetOrigin, $authtoken); } else if ($ex_type == $ex_timefree){ $url2 = str_replace($htmldir,"",$url); ht_exaudio($url2,"",""); } else if ($ex_type == $ex_webradio && $ch_type == "JCBA") { ht_exaudio_jcba($channel); } else if ($ex_type == $ex_webradio && $ch_type == "FMPP") { ht_exaudio_fmpp($channel); } else { ht_exaudio($url,"",""); } return true; } if ($auto == 1) { echo_msg(2,$para[6]); echo_msg(2,$para[7]); echo_msg(2,$para[8]); } $nam = "rfriends_exec_live"; $ex = "ex_rfriends"; rfgw_batsh_sub($scrdir, $ex, "14 ".$opt, 1, 1); return true; } function rfriends_live_radiko($ex_type,$para,$flg) { global $area_code; global $tmpdir; global $premium; global $user_auth; $channel = $para[6]; $mode = rf_premium_mode($ex_type,$area_code,$channel); $authtoken = rfriends_auth_radiko($mode,$area_code,0); if (is_null($authtoken)) { echo_prn(1, "radiko_auth error (プレミアム : $mode)"); return false; } $mode2 = $mode; if ($premium == 2) $mode2 = 0; $hlsurl = get_radiko_streamurlhls($authtoken,$channel,$mode2,0); if ($hlsurl == "") { echo_msg(2, "stream_url not found (not delivered)"); return false; } $opt = base64_encode("$ex_type,$channel,$flg,$authtoken,$hlsurl"); return $opt; } function rfriends_live_radiko_exaudio($authtoken,$channel) { global $ex_radiko; global $area_code; global $tmpdir; global $premium; $mode = rf_premium_mode($ex_radiko,$area_code,$channel); $mode2 = $mode; if ($premium == 2) $mode2 = 0; $hlsurl = get_radiko_streamurlhls($authtoken,$channel,$mode2,0); if ($hlsurl == "") { echo_msg(2, "stream_url not found (not delivered)"); return false; } return $hlsurl; } function rfriends_live_timefree($ex_type,$para,$flg,$org,$tf7) { global $area_code; global $tmpdir; global $htmldir; global $premium; global $user_auth; $opt_fn = make_fn("playtf"); $recfiletmp = $htmldir."temp/".$opt_fn; $fromtime = $para[0]; $totime = $para[1]; $channel = $para[6]; $mode = rf_premium_mode($ex_type,$area_code,$channel); $authtoken = rfriends_auth_radiko($mode,$area_code,0); if (is_null($authtoken)) { echo_prn(1, "radiko_auth error (プレミアム : $mode)"); return false; } $tf30 = 0; if (rf_tf30_check() === true) { $n = rf_diff_timefree($fromtime); if ($n < -7) { $tf30 = 1; } } $tf30 = 1; if ($tf30 == 1 || $tf7 == 1) { $hlsurl = get_timefree_stream_url_tf30($area_code, $channel, $fromtime, $totime, $recfiletmp, $authtoken,$org); } else { $hlsurl = get_timefree_stream_url($area_code, $channel, $fromtime, $totime, $recfiletmp, $authtoken,$org); } if ($hlsurl == "") { echo_msg(2, "stream_url not found (not delivered)"); return false; } $opt = base64_encode("$ex_type,$channel,$flg,$authtoken,$hlsurl"); return $opt; } function rfriends_live_radiru($ex_type,$para,$flg) { global $scrdir; $channel = $para[6]; $hlsurl = radiru_hls_url($channel); if ($hlsurl == null) { return false; } $opt = base64_encode("$ex_type,$channel,$flg,,$hlsurl"); return $opt; } function rfriends_live_radiru_vod($ex_type,$para,$flg) { global $scrdir; $channel = $para[6]; $hlsurl = $para[11]; if ($hlsurl == null) { return false; } $channel = "radiru_vod[$channel]"; $opt = base64_encode("$ex_type,$channel,$flg,,$hlsurl"); return $opt; } function rfriends_live_podcast($ex_type,$para,$flg) { global $scrdir; $channel = $para[6]; $hlsurl = $para[11]; if ($hlsurl == null) { return false; } $channel = "podcast[$channel]"; $opt = base64_encode("\"$ex_type,$channel,$flg,,$hlsurl"); return $opt; } function rfriends_live_webradio($ex_type,$para,$flg) { global $scrdir; $channel = $para[6]; $hlsurl = $para[11]; if ($hlsurl == null) { return false; } $opt = base64_encode("$ex_type,$channel,$flg,,$hlsurl"); return $opt; } function rfriends_live_misc($ex_type,$para,$flg) { global $scrdir; $channel = $para[6]; $hlsurl = $para[11]; if ($hlsurl == null) { return false; } $opt = base64_encode("$ex_type,$channel,$flg,,$hlsurl"); return $opt; } function rf_getafnmenbers() { $lists = array(); $lists[] = ['title' => '--- Paciffic' , 'val' => '']; $lists[] = ['title' => '岩国 Iwakuni' , 'val' => 'AFNP_IWA']; $lists[] = ['title' => '三沢 Misawa' , 'val' => 'AFNP_MSW']; $lists[] = ['title' => '沖縄 Okinawa' , 'val' => 'AFNP_OKN']; $lists[] = ['title' => '佐世保 Sasebo' ,'val' => 'AFNP_SBO']; $lists[] = ['title' => '東京 Tokyo' , 'val' => 'AFNP_TKO']; $lists[] = ['title' => '大邱 Daegu' , 'val' => 'AFNP_DGU']; $lists[] = ['title' => 'Humphreys' , 'val' => 'AFNP_OSN']; $lists[] = ['title' => '群山 Kunsan' , 'val' => 'AFNP_KSN']; $lists[] = ['title' => '--- Europe' , 'val' => '']; $lists[] = ['title' => 'Aviano' , 'val' => 'AFNE_AVN']; $lists[] = ['title' => 'Bahrain' , 'val' => 'AFNE_BHN']; $lists[] = ['title' => 'Bavaria' , 'val' => 'AFNE_BAV']; $lists[] = ['title' => 'Benelux' , 'val' => 'AFNE_BLX']; $lists[] = ['title' => 'Guantanamo Bay' ,'val' => 'AFNE_GMO']; $lists[] = ['title' => 'Incirlik' , 'val' => 'AFNE_ICK']; $lists[] = ['title' => 'Kaiserslautern' ,'val' => 'AFNE_KTN']; $lists[] = ['title' => 'Naples' , 'val' => 'AFNE_NAP']; $lists[] = ['title' => 'Rota' , 'val' => 'AFNE_RTA']; $lists[] = ['title' => 'Sigonella' , 'val' => 'AFNE_SIG']; $lists[] = ['title' => 'Souda Bay' , 'val' => 'AFNE_SDB']; $lists[] = ['title' => 'Spangdahlem' ,'val' => 'AFNE_SPG']; $lists[] = ['title' => 'Stuttgart' , 'val' => 'AFNE_STU']; $lists[] = ['title' => 'Vicenza' , 'val' => 'AFNE_VIC']; $lists[] = ['title' => 'Wiesbaden' , 'val' => 'AFNE_WBN']; return $lists; } function rf_getafnurl($sta) { global $htmldir; $urls = rf_getafnurl_sub($sta,"http,hls",""); $urlcnt = count_73($urls); if ($urlcnt <= 0) { echo_msg(2,"url not found"); return false; } $urlcnt2 = $urlcnt; if ($urlcnt2 > 5) $urlcnt2 = 5; for($i=0;$i<$urlcnt2;$i++) { $dat = explode(',',$urls[$i]); $url = $dat[0]; $headers = @get_headers($url); if (!$headers) continue; if (strpos($headers[0], '200')) break; } $codec = $dat[1]; $bitrate = $dat[2]; $ver = $dat[3]; return $url; } function rf_getafnurl_sub($area,$transports,$codec) { $ips = array(); $ver = '1.10'; $stamp = rand(1, 1000000); $url = "https://playerservices.streamtheworld.com/api/livestream?station=$area&transports=$transports&version=$ver&request.preventCache=$stamp"; $xmlString = @file_get_contents($url); if ($xmlString === false) { echo_msg(2,'AFN_GO file_get_contents error'); return $ips; } $cleanXmlString = preg_replace('/xmlns[^=]*="[^"]*"/i', '', $xmlString); $xml = simplexml_load_string($cleanXmlString); $result = $xml->xpath('//mountpoint'); foreach($result as $r) { $statuscode = (string)$r->status->{'status-code'}; $statusmessage = (string)$r->status->{'status-message'}; if ($statuscode != '200' || $statusmessage != 'OK') { continue; } $mount = (string)$r->mount; $arealen = strlen($area); $area2 = substr($mount."     ",0,$arealen); if ($area2 != $area) { continue; } $audiocodec = (string)$r->{'media-format'}->audio['codec']; if ($codec != "") { if ($audiocodec != $codec) continue; } $bitrate = (string)$r->{'media-format'}->audio['bitrate']; $suffix1 = (string)$r->metadata->{'shoutcast-v1'}['mountSuffix']; $suffix1_e = (string)$r->metadata->{'shoutcast-v1'}['enabled']; $suffix2 = (string)$r->metadata->{'shoutcast-v2'}['mountSuffix']; $suffix2_e = (string)$r->metadata->{'shoutcast-v2'}['enabled']; if ($suffix1_e != 'true') { if ($suffix2 != 'true') continue; $suffix1 = $suffix2; } $servers = $r->servers[0]; foreach($servers as $server) { $ip = (string)$server->ip; $ports = $server->ports; $porttype = $ports->port[0]['type']; $port = $ports->port[0]; $url = $porttype.'://'.$ip.'/'.$area.$suffix1.",$audiocodec,$bitrate,$ver"; $ips[] = $url; } } return $ips; } function rf_get_ottava_para($url,$mode) { global $htmldir; $para = array(); for($i=0;$i<19;$i++) $para[$i] = ""; $para[6] = "OTTAVA"; $para[7] = "OTTAVA"; if ($mode == 0) { $para[8] = "日本で唯一のクラシック音楽専門インターネットラジオ局"; } else { $para[8] = "OTTAVA"; } $para[9] = "images/ottava.png"; $para[11] = $url; $para[15] = "OTTAVA"; return $para; } function rf_get_afngo_para($ch,$mode) { global $htmldir; $para = array(); for($i=0;$i<19;$i++) $para[$i] = ""; $img = "images/afn/$ch.png"; if (!file_exists($htmldir.$img)) { $img = "images/afn/AFN_EAGLE.png"; } $para[6] = "$ch"; $para[7] = "$ch"; if ($mode == 0) { $para[8] = "アメリカ軍放送網 (AFN) が海外に駐留する軍人やその家族向けに提供する放送サービス"; } else { $para[8] = "AFNGO"; } $para[9] = $img; $para[15] = "AFNGO"; return $para; } function rf_get_lisradi_para($areaid,$id,$mode) { global $htmldir; $ids = rf_lisradi_get_ids(0); if (!array_key_exists($id,$ids)) return false; $info = $ids[$id]; $para = array(); for($i=0;$i<19;$i++) $para[$i] = ""; $para[6] = $id; $chname = $info['ChannelName'];; $para[7] = str_replace(' ','_',$chname); if ($mode == 0) { $para[8] = $info['ChannelDetail'];; } else { $para[8] = "ListenRadio"; } $para[9] = $info['ChannelLogo']; $para[11] = "https://mtist.as.smartstream.ne.jp/$id/livestream/chunklist.m3u8"; $para[15] = "ListenRadio"; return $para; } function rf_get_jcba_para($areaid,$id,$mode) { global $htmldir; $ids = rf_jcba_get_ids(0); if (!array_key_exists($id,$ids)) return false; $info = $ids[$id]; $para = array(); for($i=0;$i<19;$i++) $para[$i] = ""; $para[6] = $id; $chname = $info['name'];; $para[7] = str_replace(' ','_',$chname); if ($mode == 0) { $para[8] = $info['description'];; } else { $para[8] = "jcba"; } $para[9] = $info['logoUrl']; $para[11] = "https://www.jcbasimul.com/"; $para[15] = "jcba"; return $para; } function rf_get_fmpp_para($areaid,$id,$mode) { global $htmldir; $ids = rf_fmpp_get_ids(0); if (!array_key_exists($id,$ids)) return false; $info = $ids[$id]; $para = array(); for($i=0;$i<19;$i++) $para[$i] = ""; $para[6] = $id; $chname = $info['name'];; $para[7] = str_replace(' ','_',$chname); if ($mode == 0) { $para[8] = $info['city'].'&nbsp;&nbsp;'.$info['stat'].'('.$info['player'].')'; } else { $para[8] = "fmpp"; } $para[9] = $info['artwork']; $para[11] = "https://fmplapla.com/"; $para[15] = "fmpp"; return $para; } function rf_webradio_type($ex_type,$ch) { global $ex_webradio; if ($ex_type != $ex_webradio) return ''; $ch = trim($ch); $ch = strtolower($ch); $ch2 = strtoupper($ch); if ($ch2 == 'OTTAVA') return 'OTTAVA'; if (substr($ch2,0,3) == 'AFN') return 'AFNGO'; if (is_numeric($ch2)) return 'LISTENRADIO'; $ids = rf_fmpp_get_ids(0); if (isset($ids[$ch])) return 'FMPP'; $ids = rf_jcba_get_ids(0); if (isset($ids[$ch])) return 'JCBA'; return ''; } function rf_webradio_subdir($ex_type,$ch) { global $ex_webradio; $ch_type = rf_webradio_type($ex_type,$ch); if ($ch_type == '') return ''; switch($ch_type) { case 'OTTAVA': $subdir = 'ottava/'; break; case 'AFNGO': $subdir = 'afngo/'; break; case 'LISTENRADIO': $subdir = 'lradio/'; break; case 'JCBA': $subdir = 'jcba/'; break; case 'FMPP': $subdir = 'fmpp/'; break; default: $subdir = ''; break; } return $subdir; } function rf_webradio_ext($ex_type,$ch) { global $ex_webradio; $ch_type = rf_webradio_type($ex_type,$ch); if ($ch_type == '') return 'm4a'; switch($ch_type) { case 'OTTAVA': $ext = "mp3"; break; case 'AFNGO': $subdir = 'afngo/'; $ext = "mp3"; break; case 'LISTENRADIO': $subdir = 'lradio/'; $ext = "m4a"; break; case 'JCBA': $subdir = 'jcba/'; $ext = "m4a"; break; case 'FMPP': $subdir = 'fmpp/'; $ext = "m4a"; break; default: $ext = "m4a"; break; } return $ext; } function ht_jcba_start($ch,$xdg,$en_phpdir,$en_nl) { echo <<<EOF
<button id="audioBtn" class="btn_ex" onclick="toggleAudio()">再生</button>
<script>
const audio = new Audio();
audio.preload = "none";
// --- ios
let iosAudioCtx = null;
let iosMediaStream = null;
// --- ios

function toggleAudio() {
const btn = document.getElementById('audioBtn');

if (audio.src === "" || audio.paused) {
audio.src = "ht_jcba_play.php?mode=live&ch={$ch}&xdg={$xdg}&phpdir={$en_phpdir}&nl={$en_nl}";

// --- ios
if (!audio.canPlayType('audio/ogg') || !audio.canPlayType('audio/ogg; codecs=opus')) {
    try {
        if (!iosAudioCtx) {
            iosAudioCtx = new (window.AudioContext || window.webkitAudioContext)();
        }
        const response = await fetch(audio.src);
        iosMediaStream = iosAudioCtx.createMediaStreamDestination();
        const responseNode = iosAudioCtx.createMediaElementSource(audio);
        responseNode.connect(iosAudioCtx.destination);
        if (iosAudioCtx.state === 'suspended') {
            await iosAudioCtx.resume();
        }
    } catch (e) {
        console.log("iOS Web Audio init error", e);
    }
}
audio.play();
btn.textContent = "停止";
// --- ios

} else {
audio.pause();
audio.src = ""; 
fetch('ht_jcba_stop.php', { keepalive: true });
btn.textContent = "再生";

// --- ios
if (iosAudioCtx) {
    iosAudioCtx.close();
    iosAudioCtx = null;
}
iosMediaStream = null;
// --- ios

}
}

window.addEventListener('beforeunload', function(event) {
if (audio.src !== "") {
audio.pause();
audio.src = "";
fetch('ht_jcba_stop.php', { keepalive: true });

// --- ios
if (iosAudioCtx) {
    iosAudioCtx.close();
}
// --- ios

}
});
</script>
EOF;
} function rf_jcba_get_data($flg) { global $scrdir; $json = @file_get_contents($scrdir.'jcba.json'); if ($json === false) { return false; } $data = json_decode($json,true); if ($data == null) { return false; } return $data; } function rf_jcba_get_stations($flg) { $data = rf_jcba_get_data($flg); if ($data === false) return []; $raw_stations = $data['props']['pageProps']['stations']; $stations = @array_combine( array_column($raw_stations, 'region'), array_map(function($s) { return array_column($s['list'], null, 'id'); }, $raw_stations) ); if ($stations === false) return []; return $stations; } function rf_jcba_get_ids($flg) { $data = rf_jcba_get_data($flg); if ($data === false) return []; $raw_stations = $data['props']['pageProps']['stations']; $ids = @array_column(array_merge(...array_column($raw_stations, 'list')), null, 'id'); if ($ids === false) return []; return $ids; } function ht_fmpp_start($ch,$xdg,$en_phpdir,$en_nl) { echo <<<EOF
<button id="audioBtn" class="btn_ex" onclick="toggleAudio()">再生</button>
<script>
const audio = new Audio();
audio.preload = "none";

function toggleAudio() {
const btn = document.getElementById('audioBtn');

if (audio.src === "" || audio.paused) {
audio.src = "ht_fmpp_play.php?mode=live&ch={$ch}&xdg={$xdg}&phpdir={$en_phpdir}&nl={$en_nl}";
audio.play();
btn.textContent = "停止";
} else {
audio.pause();
audio.src = ""; 
fetch('ht_fmpp_stop.php', { keepalive: true });
btn.textContent = "再生";
}
}

window.addEventListener('beforeunload', function(event) {
if (audio.src !== "") {
audio.pause();
audio.src = "";
fetch('ht_fmpp_stop.php', { keepalive: true });
}
});
</script>
EOF;
} function rf_fmpp_get_data($flg) { global $scrdir; $json = @file_get_contents($scrdir.'fmpp.json'); if ($json === false) { return false; } $data = json_decode($json,true); if ($data == null) { return false; } return $data; } function rf_fmpp_get_stations($flg) { $data = rf_fmpp_get_data($flg); if ($data === false) return []; $raw_stations = $data['props']['pageProps']['stations']; $stations = @array_combine( array_column($raw_stations, 'region'), array_map(function($s) { return array_column($s['list'], null, 'id'); }, $raw_stations) ); if ($stations === false) return []; return $stations; } function rf_fmpp_get_ids($flg) { $data = rf_fmpp_get_data($flg); if ($data === false) return []; $raw_stations = $data['props']['pageProps']['stations']; $ids = @array_column(array_merge(...array_column($raw_stations, 'list')), null, 'id'); if ($ids === false) return []; return $ids; } function rf_lisradi_get_data($flg) { global $scrdir; $local_file = $scrdir."listenradio.json"; $json_data = @file_get_contents($local_file); if ($json_data === false) { return false; } $data = json_decode($json_data,true); if ($data == null) return false; return $data; } function rf_lisradi_get_stations($flg) { $data = rf_lisradi_get_data($flg); if ($data === false || !isset($data['Area'])) return []; $stations = []; foreach ($data['Area'] as $area) { $area_name = $area['AreaName'] ?? 'Unknown'; $stations[$area_name] = []; if (isset($area['Channel']) && is_array($area['Channel'])) { $stations[$area_name] = array_column($area['Channel'], null, 'ChannelId'); } } return $stations; } function rf_lisradi_get_ids($flg) { $data = rf_lisradi_get_data($flg); if ($data === false || !isset($data['Area'])) return []; $ids = []; if (!isset($data['Area']) || !is_array($data['Area'])) return $ids; foreach($data['Area'] as $ar) { if (!isset($ar['Channel']) || !is_array($ar['Channel'])) continue; foreach($ar['Channel'] as $ch) { if (!isset($ch['ChannelId'])) continue; $chid = $ch['ChannelId']; $ids[$chid] = $ch; } } return $ids; } 