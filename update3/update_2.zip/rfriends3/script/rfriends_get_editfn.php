<?php
 require_once("rf_inc.php"); $no = $argv[1]; $fn = rf_get_editfn($no); echo $fn; 