<?php
 $filePath = "/images/sample.m4a"; $command = "ffplay -autoexit " . escapeshellarg($filePath); echo "<h2>ffplayを起動しています...</h2>"; passthru($command, $return_var); if ($return_var !== 0) { echo "<p>エラーが発生しました (コード: $return_var)。パスやファイルが正しいか確認してください。</p>"; } else { echo "<p>再生が終了しました。</p>"; } ?>
