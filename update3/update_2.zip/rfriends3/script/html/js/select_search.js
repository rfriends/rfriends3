document.addEventListener('DOMContentLoaded', () => {
  const searchBoxes = document.querySelectorAll('.searchable-select-box');

  searchBoxes.forEach(box => {
    const searchInput = box.querySelector('.select-search');
    const selectBox = box.querySelector('.target-select');

    if (!selectBox) return;
    if (!searchInput) return;

    const originalOptions = Array.from(selectBox.options);

    searchInput.addEventListener('input', () => {
      const keyword = searchInput.value.toLowerCase().trim();
      selectBox.innerHTML = '';

      originalOptions.forEach(option => {
        const text = option.text.toLowerCase();
        if (option.value === "" || text.includes(keyword)) {
          selectBox.appendChild(option);
        }
      });
    });
  });
});
