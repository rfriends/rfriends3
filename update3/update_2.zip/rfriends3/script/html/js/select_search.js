document.addEventListener('DOMContentLoaded', () => {
  const searchBoxes = document.querySelectorAll('.searchable-select-box');

  searchBoxes.forEach(box => {
    const searchInput = box.querySelector('.select-search');
    const selectBox = box.querySelector('.target-select');
    
    if (!selectBox) return;
    if (!searchInput) return;

    let originalOptions = [];

    searchInput.addEventListener('input', () => {
      if (originalOptions.length === 0 && selectBox.options.length > 0) {
        originalOptions = Array.from(selectBox.options);
      }

      if (originalOptions.length === 0) return;

      const keyword = searchInput.value.toLowerCase().trim();
      selectBox.innerHTML = '';

      originalOptions.forEach(option => {
        const text = option.text.toLowerCase();
        if (option.value === "" || text.includes(keyword)) {
          selectBox.appendChild(option);
        }
      });
    });
  });
});

// 非同期
document.addEventListener('DOMContentLoaded', () => {
  const searchBoxes = document.querySelectorAll('.new-searchable-box');

  searchBoxes.forEach(box => {
    const selectBox = box.querySelector('.target-select');
    const searchInput = box.querySelector('.select-search');
    const countDisplay = box.querySelector('.count-display');
    const messegeDisplay = box.querySelector('.messege-display'); // メッセージ表示用
    const endpoint = box.dataset.endpoint;

    if (!selectBox || !endpoint) return;

    // 初期読み込み中の表示
    selectBox.innerHTML = '<option value="" disabled selected>読み込み中...</option>';
    if (searchInput) {
      searchInput.disabled = true;
      searchInput.placeholder = '読み込み中...';
    }
    if (messegeDisplay) {
      messegeDisplay.textContent = '';
    }

    fetch(endpoint)
      .then(response => {
        if (!response.ok) throw new Error('bad response');
        return response.json();
      })
      .then(data => {
        selectBox.innerHTML = '';
        if (searchInput) {
          searchInput.disabled = false;
          searchInput.placeholder = '検 索...';
        }

        // 件数は常にそのまま表示
        if (countDisplay) {
          countDisplay.textContent = `${data.length}`;
        }

        // データが最初から0件の場合
        if (data.length === 0) {
          if (messegeDisplay) {
            messegeDisplay.textContent = '見つかりませんでした';
          }
          return;
        }

        // データがある場合は通常通りオプションを生成
        data.forEach(item => {
          const option = document.createElement('option');
          option.value = item.val !== undefined ? item.val : '';
          option.innerHTML = item.title !== undefined ? item.title : '';
          selectBox.appendChild(option);
        });

        const allOptions = Array.from(selectBox.options);

        // 検索時の絞り込み処理
        if (searchInput) {
          searchInput.addEventListener('input', (e) => {
            const keyword = e.target.value.toLowerCase();
            selectBox.innerHTML = '';

            const matchedOptions = allOptions.filter(option => {
              const text = option.textContent.toLowerCase();
              return text.includes(keyword);
            });

            // 件数を更新
            if (countDisplay) {
              countDisplay.textContent = `${matchedOptions.length}`;
            }

            // 絞り込み結果が0件の場合
            if (matchedOptions.length === 0) {
              if (messegeDisplay) {
                messegeDisplay.textContent = '見つかりませんでした';
              }
            } else {
              if (messegeDisplay) {
                messegeDisplay.textContent = ''; // メッセージをクリア
              }
              matchedOptions.forEach(option => {
                selectBox.appendChild(option);
              });
            }
          });
        }
      })
      .catch(error => {
        console.error('Failed select options:', error);
        selectBox.innerHTML = '';
        if (countDisplay) {
          countDisplay.textContent = '0';
        }
        if (messegeDisplay) {
          messegeDisplay.textContent = '読み込み失敗';
        }
        if (searchInput) {
          searchInput.disabled = false;
          searchInput.placeholder = '検索...';
        }
      });
  });
});
