<?php
 function ht_jcba_start($ch,$xdg) { echo <<<EOF
<button id="audioBtn" class="btn_ex" onclick="toggleAudio()">再生</button>
<script>
const audio = new Audio();
audio.preload = "none";

function toggleAudio() {
const btn = document.getElementById('audioBtn');

if (audio.src === "" || audio.paused) {
audio.src = "ht_jcba_play.php?ch={$ch}&xdg={$xdg}";
audio.play();
btn.textContent = "停止";
} else {
audio.pause();
audio.src = ""; 
fetch('ht_jcba_stop.php', { keepalive: true });
btn.textContent = "再生";
}
}

window.addEventListener('beforeunload', function(event) {
if (audio.src !== "") {
audio.pause();
audio.src = "";
fetch('ht_jcba_stop.php', { keepalive: true });
}
});
</script>
EOF;
} 