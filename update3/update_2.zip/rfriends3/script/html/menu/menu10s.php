<?php
 function enquete($cur_ver,$latest_ver) { $data = <<<EOF
    <p>使用中 : <?php echo htmlspecialchars($cur_ver); ?></p>
    <p>最新   : <?php echo htmlspecialchars($latest_ver); ?></p>

    <p>現在のrfriends3について</p>

    <form action="" method="post">
        <p>
            <label><input type="radio" name="answer" value="1" checked> 1. 満足している</label><br>
            <label><input type="radio" name="answer" value="2"> 2. 満足していない</label><br>
            <label><input type="radio" name="answer" value="3"> 3. その他</label>
        </p>

        <p>
            <input type="submit" value="回答">
        </p>
    </form>

    <p>以下のような内容が作者宛に送信されます。</p>
    <pre style="background: #f0f0f0; padding: 10px; width: fit-content;">
---------------------------------------------------------
from : rfriends2017_yahoo.co.jp
to   : rfriends2017_yahoo.co.jp
subj : rfriends3アンケート,[<?php echo htmlspecialchars($cur_ver); ?>],[1 or 2 or 3]
body : rfriends3アンケートメール
--
author
---------------------------------------------------------
    </pre>

    <p>お気軽に、送信してください。何度でも構いません。</p>
EOF;
return $data; } $ex_type = ""; ht_subtitle($subno,""); switch ($subno) { case "1001": echo_msg(2,"システムの更新を行います。"); echo_msg(2,""); rf_clear(); if ($val == 0) { echo_msg(2,"更新停止中です。"); break; } $rst = 1; $ret = ht_update("systemupdate",0,$rst,$val,""); break; case "1002": $rpath = $val; $ty = $val2; echo_msg(2,"rpath : $rpath   ty : $ty"); $ret = rfgw_update_bin($rpath, $ty); if ($ret == 0) { echo_msg(2, "更新成功"); } else { echo_msg(2, "更新失敗"); } rf_update_fin_tool(); ht_restart(); break; case "1003": rf_factory_reset(0); ht_restart(); break; case "1006": echo '<pre>'; print_r($_POST); echo '</pre>'; default: ht_development($subno,$val,2); break; } 