<?php
 ht_subtitle($subno,""); $ex_type = $ex_webradio; switch ($subno) { case "110101": ht_delrsv($val,$ex_type); echo_msg(2, ""); echo_msg(2, "番組を削除しました。"); break; case "110102": ht_writefl($val); break; case "110103": $p = []; if ($sel == 1) { $p[0] = 0; $p[1] = 0; $p[2] = 0; $p[3] = 7; $p[4] = ""; $p[5] = ""; $rsvdata = rf_webradio_reserve($p); $cnt = count_73($rsvdata); echo_msg(2, ""); echo_msg(2, "{$cnt}件の番組予約を行いました。"); echo_msg(2, ""); foreach($rsvdata as $dat) { $para = get_para($dat, $ex_type); $fnm = get_fnam($para, $ex_type); $title = $para[7]; echo_msg(2,"$fnm $title"); } echo_msg(2,""); $ht_jump_btn1_label = "予約確認"; $ht_jump_addr = "menu.html"; $mno = "11"; $sno = "s01a"; echo <<<EOF
        <form method="POST" action="$ht_jump_addr"">
            <div class="button-area">
                <input class=btn_ex type="submit" value="$ht_jump_btn1_label">
                <INPUT type='hidden' name='mno'   value='$mno'>
                <INPUT type='hidden' name='sno'   value='$sno'>
            </div>
        </form>
EOF;
} if ($sel == 2) { rf_batsh_rec($ex_type, 1, 0, 0, ""); echo_msg(2, ""); echo_msg(2, "予約リストを作成しました。"); echo_msg(2, ""); echo_msg(2, "log/YYYYMMDD_HHMMSS_rfriends_exec_webradio_XXXXXXX.log"); } break; case "1102": $ex_type = "$ex_webradio"; $para = rf_get_ottava_para($val,0); if ($sel == 1) { $wdat = put_para($para,$ex_type); ht_wdat_pgm_disp($wdat,$ex_type,1); rfriends_audio($ex_type,$para,0); } else if ($sel == 2) { $wdat = put_para($para,$ex_type); ht_live_server($wdat,$ex_type); echo_msg(2,"再生開始まで少々時間がかかります。"); } else if ($sel == 3) { echo_msg(2,"予約入力フォーム"); $ht_jump_btn1_label = "実行"; $station = $para[6]; $title = $para[7]; $artist = "OTTAVA"; echo ht_webradio_input($station, $title, $artist); } break; case "1103": if ($val == ';') { echo_msg(2,"unknown"); break; } $ex_type = "$ex_webradio"; $para = rf_get_afngo_para($val,0); if ($sel != 3) { $url = rf_getafnurl($val); if ($url === false ) { echo_msg(2,"$url : url get error"); break; } $para[11] = $url; $wdat = put_para($para,$ex_type); } if ($sel == 1) { ht_wdat_pgm_disp($wdat,$ex_type,1); rfriends_audio($ex_type,$para,0); } else if ($sel == 2) { ht_live_server($wdat,$ex_type); } else if ($sel == 3) { echo_msg(2,"予約入力フォーム"); $ex_type = "$ex_webradio"; $ht_jump_btn1_label = "実行"; $station = $para[6]; $title = $para[7]; $artist = "AFNGO"; echo ht_webradio_input($station, $title, $artist); } break; case "1104": $region = $val; $stations = rf_lisradi_get_stations(0); if ($stations == []) { break; } if ($val == '全国') { $lists = []; foreach($stations as $key1 => $sta_s1) { foreach($sta_s1 as $info) { $id = $info['ChannelId']; $name = $info['ChannelName']; $name = mb_convert_kana(trim($name), 'a'); $para[6] = $id; $para[7] = $name; $para[15] = 'ListenRadio'; $site = ht_wdat_pgm_disp_webradio($para); $lists[] = array('title' => "{$id} {$name} ( {$key1} )" , 'val' => $id); } } sort($lists); } else { if (array_key_exists($val,$stations) === false) break; $sta = $stations[$val]; $region_ids = array_keys(isset($sta) ? $sta : []); $lists = []; foreach($region_ids as $region_id) { $info = isset($stations[$region][$region_id]) ? $stations[$region][$region_id] : null; $name = $info['ChannelName']; $lists[] = array('title' => "{$region_id} {$name}" , 'val' => $region_id); } } $ht_jump_btn2 = 1; $ht_jump_btn3 = 1; $ht_jump_btn4 = 1; $ht_jump_btn1_label = "聴取"; $ht_jump_btn2_label = "聴取(サーバ)"; $ht_jump_btn3_label = "予約入力"; $ht_jump_btn4_label = "プリセット"; $cnt = count_73($lists); $opt = array( "title" => "リスラジ 放送局選択 ( $val $cnt )", "mode" => 1, "multi" => 0, "confirm" => 0, "ht_selid" => "", ); ht_ask_list($lists,$opt); break; case "1105": $region = $val; $stations = rf_jcba_get_stations(0); if ($stations == []) { break; } if ($val == '全国') { $lists = []; foreach($stations as $key1 => $sta_s1) { foreach($sta_s1 as $info) { $id = $info['id']; $name = $info['name']; $name = mb_convert_kana(trim($name), 'a'); $lists[] = array('title' => "{$name} ( {$key1} )" , 'val' => $id); } } sort($lists); } else { if (array_key_exists($val,$stations) === false) break; $sta = $stations[$val]; $region_ids = isset($sta) ? array_keys($sta) : []; $lists = []; foreach($region_ids as $region_id) { $info = isset($stations[$region][$region_id]) ? $stations[$region][$region_id] : null; $name = $info['name']; $lists[] = array('title' => "{$name}" , 'val' => $region_id); } } $ht_jump_btn2 = 1; $ht_jump_btn3 = 1; $ht_jump_btn4 = 1; $ht_jump_btn1_label = "聴取"; $ht_jump_btn2_label = "聴取(サーバ)"; $ht_jump_btn3_label = "予約入力"; $ht_jump_btn4_label = "プリセット"; $cnt = count_73($lists); $opt = array( "title" => "JCBA 放送局選択 ( $val $cnt )", "mode" => 1, "multi" => 0, "confirm" => 0, "ht_selid" => "", ); ht_ask_list($lists,$opt); break; case "1106": $region = $val; $stations = rf_fmpp_get_stations(0); if ($stations == []) { break; } if ($val == '全国') { $lists = []; foreach($stations as $key1 => $sta_s1) { foreach($sta_s1 as $info) { $id = $info['id']; $name = $info['name']; $name = mb_convert_kana(trim($name), 'a'); $para[6] = $id; $para[7] = $name; $para[15] = 'fmpp'; $site = ht_wdat_pgm_disp_webradio($para); $play = $info['player']; if ($play != 1) $name .= ' [休止中]'; $lists[] = array('title' => {$name} ( {$key1} )" , 'val' => $id);
                    }
                }
                sort($lists);
            } else {
                if (array_key_exists($val,$stations) === false) break;
                $sta = $stations[$val];
                //$region_ids = array_keys($sta ?? []);
                $region_ids = isset($sta) ? array_keys($sta) : [];

                $lists = [];
                foreach($region_ids as $region_id) {
                    //echo_msg(2,"$region $region_id");
                    //$info = $stations[$region][$region_id] ?? null;
                    $info = isset($stations[$region][$region_id]) ? $stations[$region][$region_id] : null;
                    $name = $info['name'];
                    $play = $info['player'];
                    if ($play != 1) $name .= ' [休止中]';
                    $lists[] = array('title' => "{$name}" , 'val' => $region_id);
                }
            }

            $ht_jump_btn2 = 1;
            $ht_jump_btn3 = 1;
            $ht_jump_btn4 = 1;
            $ht_jump_btn1_label = "聴取";
            $ht_jump_btn2_label = "聴取(サーバ)";
            $ht_jump_btn3_label = "予約入力";
            $ht_jump_btn4_label = "プリセット";

            //ht_print_r($lists,"lists");
            $cnt = count_73($lists);
            $opt = array(
                "title"     => "FM++ 放送局選択 ( $val $cnt )",
                "mode"       => 1,
                "multi"      => 0,
                "confirm"    => 0,
               "ht_selid"   => "",
               //"ht_selfilter"   => "検索"
            );
            ht_ask_list($lists,$opt);
            break;
/*
        // 検索
        case "1107":
            $sta = $val;
            //echo_msg(2,"station : $sta");
            $data = ht_search_webradio_station($sta);
            if ($data == []) {
                echo_msg(2,"station : $sta");
                echo_msg(2,"ヒットしませんでした。");
                break;
            }
            $lists = [];
            foreach($data as $d) {
                $d2 = explode(',',$d);
                if (count_73($d2) != 3) continue;
                $lists[] = ['title' => "{$d2[0]} ({$d2[1]})", 'val' => "$d"];
            }

            $ht_jump_btn2 = 1;
            $ht_jump_btn3 = 1;
            $ht_jump_btn4 = 1;
            $ht_jump_btn1_label = "聴取";
            $ht_jump_btn2_label = "聴取(サーバ)";
            $ht_jump_btn3_label = "予約入力";
            $ht_jump_btn4_label = "プリセット";

            //ht_print_r($lists,"lists");
            $cnt = count_73($lists);
            $opt = array(
                "title"     => "コミュニティFM 放送局選択 ( $sta {$cnt}件 )",
                "mode"       => 1,
                "multi"      => 0,
                "confirm"    => 0,
               "ht_selid"   => ""
            );
            ht_ask_list($lists,$opt);
            break;
*/
        case "1107":
            //echo_msg(2,"$sel");
            $dat = explode(',',$val);
            if (count_73($dat) != 3) {
                echo_msg(2,"$val");
                echo_msg(2,"サイトがみつかりません。");
                break;
            }
            switch($dat[1]) {
                case 'LRAD':
                    $id = $dat[2];
                    if ($id == 0) {
                        echo_msg(2,"$val");
                        echo_msg(2,"サイトがみつかりません。");
                        break;
                    }
                    $subno = '1104';
                    $sno = 's04';
                    break;
                case 'JCBA':
                    $id = $dat[2];
                    $subno = '1105';
                    $sno = 's05';
                    break;
                case 'FM++':
                    $id = $dat[2];
                    $subno = '1106';
                    $sno = 's06';
                    break;
                case 'UNIQ':
                    if ($sel != 1) {
                        echo_msg(2,"独自配信は独自配信サイトへのリンクのみサポートしています。({$sel})");
                    }
                    echo_msg(2,"");
                    echo_msg(2,"独自配信サイトにアクセスするには、以下のリンクをクリックしてください。");
                    echo_msg(2,"");
                    $site = $dat[2];
                    msgx("$dat[0] : <a href='$site' target='_blank'>$site</a>");
                    break 2;
                default:
                    echo_msg(2,"$val");
                    echo_msg(2,"サイトがみつかりません。");
                    break 2;
            }
            $site = "menu_ss.html?val={$id}&sel={$sel}&val2=&subno={$subno}&exname=menu_ss.html&sno={$sno}";
            //echo_msg(2,"");
            //echo_msg(2,"$site");
echo <<<EOM
<script>
window.location.href = "$site";
</script>
EOM;
            break;
        case "110801":
            $p = explode(',',$val);
            $id = strtolower(trim($p[0]));
            $title = trim($p[1]);
            $areaid = '';
            $ch_type = rf_webradio_type($ex_type,trim($id));
            //echo_msg(2,"$subno val : $val val2 : $val2 sel : $sel type : $ch_type");
            $ex_type = "$ex_webradio";
            switch($ch_type) {
                case 'LISTENRADIO':
                    if ($sel == 1) $ex_type = "$ex_webradio_cors";
                    $para = rf_get_lisradi_para($areaid,$id,0);
                    break;
                case 'JCBA':
                    $para = rf_get_jcba_para($areaid,$id,0);
                    break;
                case 'FMPP':
                    $para = rf_get_fmpp_para($areaid,$id,0);
                    break;
                default:
                    echo_msg(2,"error type : $ch_type id : $id title : $title");
                    $para = false;
                    break;
            }
            if ($para === false) {
                break;
            }
            //ht_print_r($result,"result");

            if ($sel == 1) {
                $wdat = put_para($para,$ex_type);
                ht_wdat_pgm_disp($wdat,$ex_type,1);
                rfriends_live($ex_type,$para,0);
            } else if ($sel == 2) {
                $wdat = put_para($para,$ex_type);
                ht_live_server($wdat,$ex_type);
            } else if ($sel == 3) {
                echo_msg(2,"予約入力フォーム");
                //ht_rsv_aid($para,$ex_type);
                $ht_jump_btn1_label = "実行";
                $station = $para[6];
                $title   = $para[7];
                $artist  = strtolower($ch_type);
                echo ht_webradio_input($station, $title, $artist);
            }
            break;
        case "110802":
            //echo_msg(2,"$subno val : $val val2 : $val2 sel : $sel");
            ht_writefl($val);
            break;
/*
        case "1105":
            $para = array();
            for($i=0;$i<19;$i++) $para[$i] = "";
            //echo_msg(2,"$val");
            $dat = explode(',',$val);
            $id  = $dat[0];
            $ttl = $dat[1];
            $para[6]  = $id;
            $para[7]  = $ttl;
            $para[8]  = "onsen";
            $para[9]  = "";


            $url = "https: $html = rf_curl($url,60); if ($html === false) { echo_msg(2,"error get $url"); break; } $pat_s = '.contents\s*=\s*( \[ (?> [^\[\]]+ | (?1) )* \] )'; $pat = '/'.$id.$pat_s.'/x'; $ret = preg_match($pat, $html, $matches); if ($ret === false) { echo_msg(2,"番組が見つかりません。(1) $id,$ttl"); break; } $json = $matches[1]; $json = str_replace("\\u002F","/",$json); $pat = '/https?:\/\/[^\s"]+?\.m3u8/'; $ret = preg_match_all($pat, $json, $matches); if ($ret === false) { echo_msg(2,"番組が見つかりません。(2)"); break; } $urls = $matches[0]; $urlcnt = count_73($urls); if ($urlcnt <= 0) { echo_msg(2,"番組がありません。(3)"); break; } $waudiodir = $usrdir."webaudio/"; $para[8] = "program : $urlcnt"; $para[11] = $urls[0]; $para[12] = $waudiodir."onsen"; $ex_type = $ex_webradio; $wdat = put_para($para,$ex_type); if ($sel == 1) { $opt_fn = make_fn("webaudio"); if (!is_array($wdat)) { $wdat0 = array(); $wdat0[] = $wdat; } else { $wdat0 = $wdat; } rf_put_wdat_all_tmpdir($opt_fn, $wdat0); $nn = count_73($wdat0); $nam = "rfriends_exec_webaudio_down"; $opt = "18 \"$opt_fn\" "; $ex = "ex_rfriends"; rfgw_batsh_sub($scrdir, $ex, $opt, 1, 1); echo_msg(2, ""); echo_msg(2, "$nn 件のダウンロード処理を開始しました"); echo_msg(2, "処理はバックグラウンドで行われます"); } else if ($sel == 2) { ht_live_server($wdat,$ex_type); } break; */ case "1109": $ht_jump_btn2 = 1; $ht_jump_btn3 = 1; $ht_jump_btn1_label = "再生"; $ht_jump_btn2_label = "再生(サーバ)"; $ht_jump_btn3_label = "download"; $mes = "ウェブラジオ ファイル一覧"; $dir = get_recdir($ex_type); ht_sel_usrdir($mes,$dir,$val,0,0,1); break; } 