<?php
 $ex_type = $ex_timefree; ht_subtitle($subno,""); switch ($subno) { case "010702": $url = "https://listenradio.jp/"; $r = explode(',",$val);
            $area = $r[0];
            $chid = $r[1];
            $result = ht_listenradio_chinfo($url,$area,$chid);
            if ($result == null || $result === false) {
                break;
            }
            ht_print_r($result,"result");
            break;
       default:
            ht_development($subno,$val,2);
            break;
    }
