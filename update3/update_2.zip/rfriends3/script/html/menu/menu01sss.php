<?php
 $ex_type = $ex_timefree; ht_subtitle($subno,""); switch ($subno) { default: ht_development($subno,$val,2); break; } 