<?php
 ht_subtitle($subno,""); switch ($subno) { case "090101": case "090102": case "090103": ht_config_ex($subno); break; default: ht_development($subno,$val,2); break; } 