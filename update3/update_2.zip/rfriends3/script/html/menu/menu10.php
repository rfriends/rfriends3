<?php
 function rf_enquete($cur_ver,$latest_ver) { $data = <<<EOF
    <p>使用中 : <?php echo htmlspecialchars($cur_ver); ?></p>
    <p>最新   : <?php echo htmlspecialchars($latest_ver); ?></p>

    <p>現在のrfriends3について</p>

    <form action="" method="post">
        <p>
            <label><input type="radio" name="answer" value="1" checked> 1. 満足している</label><br>
            <label><input type="radio" name="answer" value="2"> 2. 満足していない</label><br>
            <label><input type="radio" name="answer" value="3"> 3. その他</label>
        </p>

        <p>
            <input type="submit" value="回答">
        </p>
    </form>

    <p>以下のような内容が作者宛に送信されます。</p>
    <pre style="background: #f0f0f0; padding: 10px; width: fit-content;">
---------------------------------------------------------
from : rfriends2017_yahoo.co.jp
to   : rfriends2017_yahoo.co.jp
subj : rfriends3アンケート,[<?php echo htmlspecialchars($cur_ver); ?>],[1 or 2 or 3]
body : rfriends3アンケートメール
--
author
---------------------------------------------------------
    </pre>

    <p>お気軽に、送信してください。何度でも構いません。</p>
EOF;
return $data; } switch ($sno) { case "s01": ht_subtitle("1001",""); $ht_jump_btn1_label = "選択"; $ret = rfmenu_update(0); if ($ret == 0) { } break; case "s02": ht_subtitle("1002",""); $ret = rfmenu_update_tool(0); if ($ret == 0) { } break; case "s03": ht_subtitle("1003",""); rfmenu_about_mes(); ht_yesno("本当に実行しますか？"); break; case "s04": ht_subtitle("1004",""); $txts = rfmenu_info(); echo_text($txts,0,0); break; case "s05": ht_subtitle("1005",""); $txts = rfmenu_info_apps(); echo_text($txts,0,0); break; case "s06": rfmenu_subtitle("rfriends3に関するアンケート"); $cur_ver = "v1.2.3"; $latest_ver = "v1.5.0"; echo rf_enquete($cur_ver,$latest_ver); break; case -1: $ret = rfmenu_update(1); if ($ret == 0) { rf_pause(); } break; default: break; } 