<?php
 function rf_enquete($cur_ver,$latest_ver) { global $ht_jump_addr; global $ht_jump_no; global $ht_jump_val; global $ht_jump_val2; global $ht_jump_confirm; global $ht_jump_selid; global $ht_jump_ret; global $ht_jump_btn1; global $ht_jump_btn1_label; $data = <<<EOF
    <p>rfriends3についてのアンケート</p>
    <p></p>
    <p>使用中 : $cur_ver</p>
    <p>最新版 : $latest_ver/p>
    <p></p>

  　 <form class=asklist method=get action='$ht_jump_addr'
        <p>
            <label><input type="radio" name="val1" value="1" checked> 1. 満足している</label><br>
            <label><input type="radio" name="val1" value="2"> 2. 満足していない</label><br>
            <label><input type="radio" name="val1" value="3"> 3. その他</label>
        </p>

        <p>
            <p align=left><button class='btn_ex' type='submit'>回答</button></p>
            <input type='hidden' name=val2 value=$cur_ver>
        </p>
    </form>
    <p></p>
    <p>以下のような内容が作者宛に送信されます。</p>
    <pre style="background: #f0f0f0; padding: 10px; width: fit-content;">
-------------------------------------
[rfriends_{$cur_ver}],[1 or 2 or 3]
-------------------------------------
    </pre>
    <p></p>
    <p>お気軽に、回答してください。何度でも構いません。</p>
EOF;
return $data; } switch ($sno) { case "s01": ht_subtitle("1001",""); $ht_jump_btn1_label = "選択"; $ret = rfmenu_update(0); if ($ret == 0) { } break; case "s02": ht_subtitle("1002",""); $ret = rfmenu_update_tool(0); if ($ret == 0) { } break; case "s03": ht_subtitle("1003",""); rfmenu_about_mes(); ht_yesno("本当に実行しますか？"); break; case "s04": ht_subtitle("1004",""); $txts = rfmenu_info(); echo_text($txts,0,0); break; case "s05": ht_subtitle("1005",""); $txts = rfmenu_info_apps(); echo_text($txts,0,0); break; case "s06": rfmenu_subtitle("rfriends3に関するアンケート"); $rfriends_ver = trim(file_get_contents($base.$rfriends)); $ver = explode(" ", $rfriends_ver); $cur_ver = $ver[3]; $latest_ver = $ver[3]; $ht_jump_btn1_label = "録音"; echo rf_enquete($cur_ver,$latest_ver); break; case -1: $ret = rfmenu_update(1); if ($ret == 0) { rf_pause(); } break; default: break; } 