<?php
 ht_subtitle($subno,""); $ex_type = $ex_webradio; switch ($subno) { case "1104": ht_webradio_input_txt($_POST); break; } switch ($subno) { case "1105": ht_webradio_input_txt($_POST); break; } 