<?php
 ht_subtitle($subno,""); $ex_type = $ex_webradio; switch ($subno) { case "1104": ht_webradio_input_txt($_POST); break; } 