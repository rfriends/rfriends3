<?php
 $ex_type = $ex_radiko; switch ($sno) { case "s01": ht_subtitle("0201",""); $ht_jump_btn1_label = "削除"; $now_que_no = ""; if (get_rfriends_exeos() == "LNX") { $now_que_no = "($at_que_no)"; } rfmenu_subtitle("予約済一覧を表示します。$now_que_no"); rfmenu_rec_dsp($ex_type,0); break; case "s02": ht_subtitle("0202",""); $ht_jump_btn2 = 1; $ht_jump_btn1_label = "録音予約"; $ht_jump_btn2_label = "KW登録"; $ht_jump_btn3 = 1; $ht_jump_btn4 = 1; $ht_jump_btn3_label = "聴取"; $ht_jump_btn4_label = "聴取(サーバ)"; $ttl = "放送番組一覧 [{$area_code}&nbsp;&nbsp;{$radiko_reserve_now2}日]"; echo <<<EOM
<div class="new-searchable-box" data-endpoint="/ht_get_options.php?pgm=selpgm1">
<li>&nbsp;&nbsp;{$ttl}&nbsp;(<span class="count-display"></span>件)</li>
<div style='height: 0.5em;'></div>
<form method=post class=asklist action='menu_s.html'>
<input type="text" class="select-search" placeholder="検索...">
<div style='height: 0.5em;'></div>
<select class="target-select" name='val[]' id="selpgm" size="11" multiple required></select>
</div>
<div style='height: 1.0em;'></div>
<table><tr>
<td><button class=btn_ex type=submit name=sel value=1 onclick='selvalue=1'>
<img src="/images/multi.png" height ="16" width="16" align=top alt="複数選択可能" title="複数選択可能" />&nbsp;録音予約</button></td>
<td>&nbsp;</td>
<td><button class=btn_ex type=submit name=sel value=2 onclick='selvalue=2'>
<img src="/images/multi.png" height ="16" width="16" align=top alt="複数選択可能" title="複数選択可能" />&nbsp;KW登録</button></td>
<td>&nbsp;</td>
<td><button class=btn_ex type=submit name=sel value=3 onclick='selvalue=3'>聴取</button></td>
<td>&nbsp;</td>
<td><button class=btn_ex type=submit name=sel value=4 onclick='selvalue=4'>聴取(サーバ)</button></td>
</tr></table>
<input type='hidden' name=val2 value=><input type='hidden' name=subno  value=0202>
<input type='hidden' name=exname value=menu_s.html>
<INPUT type='hidden' name='mno'  value='02'>
<INPUT type='hidden' name='sno'  value='s02'>
</form>
</div>
EOM;
break; case "s03": ht_subtitle("0203",""); $ht_jump_btn1_label = "選択"; $ch = rfmenu_rec_ch($ex_type); if ($ch == "") { break; } if ($ch !== false) { rfmenu_rec_ch_ex($ex_type, $ch); } break; case "s04": ht_subtitle("0204",""); rfmenu_rec_kwsrc($ex_type); break; case "s05": ht_subtitle("0205",""); echo_msg(2, "キーワードを元に番組予約を行います。"); echo_msg(2, ""); echo_msg(2, "予約リストはリスト作成のみで実際の予約は行いません。"); echo_msg(2, "リストはlogディレクトリに作成します。"); echo_msg(2, ""); rfmenu_rec_pgm($ex_radiko); break; case "s07": ht_subtitle("0207",""); if(($premium == 1 || $premium == 2) && ($premium_areafree == 1)) { rfmenu_subtitle("ラジコプレミアムの地区(現在:$premium_area )を変更します。"); rfmenu_set_premium_area(); break; } echo_msg(2,"地域情報更新"); echo_msg(2,""); echo_msg(2,"auth_mode : $radiko_auth_mode"); echo_msg(2,""); if ($radiko_auth_mode == 0) { rf_reflesh_auth(); break; } if ($radiko_auth_mode == 2) { echo_msg(2,"url : $radiko_auth_mode2_url"); echo_msg(2,"url2 : $radiko_auth_mode2_url2"); echo_msg(2,"pref : $radiko_auth_mode2_pref"); echo_msg(2,""); rf_reflesh_auth(); break; } if ($radiko_auth_mode == 3) { rf_reflesh_auth(); break; } echo_msg(2,"このモードでは変更できません。"); rf_pause(); break; case "s08": ht_subtitle("0208",""); $ht_jump_btn2 = 1; $ht_jump_btn1_label = "聴取"; $ht_jump_btn2_label = "聴取(サーバ)"; rfmenu_onair($ex_type); break; case "s09": ht_subtitle("0209",""); $ht_jump_btn2 = 1; $ht_jump_btn3 = 1; $ht_jump_btn1_label = "再生"; $ht_jump_btn2_label = "再生(サーバ)"; $ht_jump_btn3_label = "download"; ht_menu_play($ex_type,$mno,$sno); break; default: break; } 