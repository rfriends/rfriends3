let hls = null;
let currentStationId = null;

window.addEventListener('DOMContentLoaded', () => {
    fetchStations();
});

function showRawLog(obj) {
    //const box = document.getElementById('rawLogBox');
    //box.innerText = JSON.stringify(obj, null, 2);
}

function onServiceChange() {
    const service = document.querySelector('input[name="service"]:checked').value;
    const radikoSection = document.getElementById('radikoAreaSection');
    const radiruSection = document.getElementById('radiruRegionSection');
    
    if (service === 'radiru') {
        radikoSection.classList.add('hidden');
        radiruSection.classList.remove('hidden');
    } else {
        radikoSection.classList.remove('hidden');
        radiruSection.classList.add('hidden');
    }
    fetchStations();
}

function onAreaModeChange() {
    const areaMode = document.querySelector('input[name="areaMode"]:checked').value;
    const container = document.getElementById('areaSelectContainer');
    if (areaMode === 'premium') {
        container.classList.remove('hidden');
    } else {
        container.classList.add('hidden');
    }
    fetchStations();
}

async function fetchStations() {
    const service = document.querySelector('input[name="service"]:checked').value;
    let area = '';
    let areaLabel = '';

    if (service === 'radiko') {
        const areaMode = document.querySelector('input[name="areaMode"]:checked').value;
        if (areaMode === 'premium') {
            area = document.getElementById('areaSelect').value;
            areaLabel = `Radiko (指定: ${area})`;
        } else {
            area = 'auto';
            areaLabel = 'Radiko (自動検出中...)';
        }
    } else {
        area = document.getElementById('radiruRegionSelect').value;
        const selectEl = document.getElementById('radiruRegionSelect');
        areaLabel = `らじる★らじる: ${selectEl.options[selectEl.selectedIndex].text}`;
    }

    document.getElementById('stationListTitle').innerText = `放送局一覧 (${areaLabel})`;

    const grid = document.getElementById('stationGrid');
    grid.innerHTML = '<div style="color: #99a1af; text-align: center; padding: 20px; grid-column: 1 / -1;">読み込み中...</div>';

    try {
        const res = await fetch(`ht_r_api.php?action=get_stations&service=${service}&area=${area}`);
        const data = await res.json();

        showRawLog(data);

        if (data.success && data.stations) {
            if (service === 'radiko' && data.detected_area) {
                const areaNames = {};
                const detectedName = areaNames[data.detected_area] || data.detected_area;
                const modeText = (area === 'auto') ? '自動' : '指定';
                areaLabel = `Radiko: ${detectedName} (${data.detected_area} / ${modeText})`;
                document.getElementById('stationListTitle').innerText = `放送局一覧 (${areaLabel})`;
            }

            renderStations(data.stations);
        } else {
            grid.innerHTML = '<div style="color: #ef4444; text-align: center; padding: 20px; grid-column: 1 / -1;">放送局の取得に失敗しました</div>';
        }
    } catch (e) {
        console.error(e);
        showRawLog({ error: e.toString() });
        grid.innerHTML = '<div style="color: #ef4444; text-align: center; padding: 20px; grid-column: 1 / -1;">通信エラーが発生しました</div>';
    }
}

function renderStations(stations) {
    const grid = document.getElementById('stationGrid');
    grid.innerHTML = '';

    if (Array.isArray(stations)) {
        stations.forEach(item => {
            let id = item;
            let name = item;

            const match = item.match(/^(.*?)\s*\(([^)]+)\)$/);
            if (match) {
                name = match[1].trim(); 
                id = match[2].trim();   
            }

            createStationCard(grid, id, name);
        });
    } else {
        for (const [id, name] of Object.entries(stations)) {
            createStationCard(grid, id, name);
        }
    }
}

function createStationCard(container, id, name) {
    const btn = document.createElement('div');
    btn.className = "station-card";
    btn.innerText = name;
    btn.dataset.id = id;
    btn.onclick = () => selectStation(id, name, btn);
    container.appendChild(btn);
}

function selectStation(id, name, element) {
    document.querySelectorAll('.station-card').forEach(el => el.classList.remove('selected'));
    element.classList.add('selected');
    currentStationId = id;
    document.getElementById('selectedStationName').innerText = name;
}

async function startPlayback() {
    if (!currentStationId) {
        alert('再生する放送局を選択してください。');
        return;
    }

    const service = document.querySelector('input[name="service"]:checked').value;
    const playMode = document.querySelector('input[name="playMode"]:checked').value;
    const statusEl = document.getElementById('systemStatus');
    
    let area = '';
    if (service === 'radiko') {
        area = (document.querySelector('input[name="areaMode"]:checked').value === 'premium') ? document.getElementById('areaSelect').value : 'auto';
    } else {
        area = document.getElementById('radiruRegionSelect').value;
    }

    if (playMode === 'browser') {
        statusEl.innerText = '接続中...';
        try {
            const res = await fetch(`ht_r_api.php?action=get_stream_url&service=${service}&station=${currentStationId}&area=${area}`);
            const data = await res.json();
            
            showRawLog(data);

            if (data.success && data.url) {
                const audio = document.getElementById('audioPlayer');

                if (Hls.isSupported()) {
                    if (hls) { hls.destroy(); }

                    if (service === 'radiko') {
                        const targetM3u8Url = data.url;
                        const authToken = data.authtoken || '';
                        const proxyScript = "../ht_cors_radiko.php";
                        const targetOrigin = "https://radiko.jp";

                        hls = new Hls({
                            xhrSetup: function (xhr, url) {
                                if (url.includes(proxyScript)) {
                                    if (!authToken || url.includes('authtoken=')) {
                                        return;
                                    }
                                }

                                let resolvedUrl = url;

                                if (url.startsWith(window.location.origin) || !url.startsWith('http')) {
                                    const urlObj = new URL(url, window.location.origin);
                                    const pathAndQuery = urlObj.pathname + urlObj.search;

                                    const baseObj = new URL(targetM3u8Url);
                                    const baseDir = baseObj.pathname.substring(0, baseObj.pathname.lastIndexOf('/') + 1);
                                    
                                    if (pathAndQuery.startsWith('/')) {
                                        resolvedUrl = baseObj.origin + baseDir + pathAndQuery.substring(1);
                                    } else {
                                        resolvedUrl = baseObj.origin + baseDir + pathAndQuery;
                                    }
                                }
                                
                                if (resolvedUrl.startsWith('http') && !resolvedUrl.startsWith(window.location.origin)) {
                                    let queryParam = "?url=" + encodeURIComponent(resolvedUrl) + "&org=" + encodeURIComponent(targetOrigin);
                                    if (authToken) {
                                        queryParam += "&authtoken=" + encodeURIComponent(authToken);
                                    }
                                    resolvedUrl = proxyScript + queryParam;
                                }
                                xhr.open('GET', resolvedUrl, true);
                            }
                        });

                        let initialUrl = proxyScript + "?url=" + encodeURIComponent(targetM3u8Url) + "&org=" + encodeURIComponent(targetOrigin);
                        if (authToken) {
                            initialUrl += "&authtoken=" + encodeURIComponent(authToken);
                        }
                        hls.loadSource(initialUrl);

                    } else {
                        hls = new Hls();
                        hls.loadSource(data.url);
                    }

                    hls.attachMedia(audio);
                    hls.on(Hls.Events.MANIFEST_PARSED, () => {
                        audio.play().catch(err => {
                            console.log("自動再生がブロックされました。", err);
                        });
                        statusEl.innerText = `再生中 (${service === 'radiko' ? 'Radiko' : 'らじる★らじる'})`;
                    });

                    hls.on(Hls.Events.ERROR, (event, errData) => {
                        if (errData.fatal) {
                            console.error("致命的なエラーが発生しました:", errData);
                            statusEl.innerText = '再生エラー';
                        }
                    });

                } else if (audio.canPlayType('application/vnd.apple.mpegurl')) {
                    if (service === 'radiko') {
                        let fallbackUrl = "ht_cors_radiko.php?url=" + encodeURIComponent(data.url) + "&org=https://radiko.jp";
                        if (data.authtoken) fallbackUrl += "&authtoken=" + encodeURIComponent(data.authtoken);
                        audio.src = fallbackUrl;
                    } else {
                        audio.src = data.url;
                    }
                    audio.addEventListener('loadedmetadata', () => {
                        audio.play();
                        statusEl.innerText = '再生中 (ネイティブ)';
                    });
                }
            } else {
                alert('ストリームURLの取得に失敗しました。');
                statusEl.innerText = 'エラー';
            }
        } catch (e) {
            console.error(e);
            showRawLog({ error: e.toString() });
            statusEl.innerText = '通信エラー';
        }
    } else {
        statusEl.innerText = 'サーバー起動中...';
        try {
            const formData = new FormData();
            formData.append('action', 'start_ffmpeg');
            formData.append('service', service);
            formData.append('station', currentStationId);
            formData.append('area', area);

            const res = await fetch('ht_r_api.php', { method: 'POST', body: formData });
            const data = await res.json();
            
            showRawLog(data);

            if (data.success) {
                statusEl.innerText = 'サーバー出力中 (ffmpeg)';
            } else {
                alert('ffmpegの起動に失敗しました。');
                statusEl.innerText = '起動エラー';
            }
        } catch (e) {
            console.error(e);
            showRawLog({ error: e.toString() });
            statusEl.innerText = '通信エラー';
        }
    }
}

async function stopPlayback() {
    const statusEl = document.getElementById('systemStatus');
    const audio = document.getElementById('audioPlayer');
    audio.pause();
    audio.currentTime = 0;
    if (hls) { hls.stopLoad(); }

    try {
        const res = await fetch('ht_r_api.php?action=stop_ffmpeg', { method: 'POST' });
        const data = await res.json();
        showRawLog(data);
    } catch (e) {
        console.error(e);
    }
    statusEl.innerText = '停止中';
}

function changeVolume(val) {
    document.getElementById('audioPlayer').volume = val;
}
