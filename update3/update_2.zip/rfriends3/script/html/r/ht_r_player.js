let hls = null;
let currentStationId = null;

window.addEventListener('DOMContentLoaded', () => {
    fetchStations();
});

function showRawLog(obj) {
    //const box = document.getElementById('rawLogBox');
    //box.innerText = JSON.stringify(obj, null, 2);
}

function onServiceChange() {
    const service = document.querySelector('input[name="service"]:checked').value;
    const radikoSection = document.getElementById('radikoAreaSection');
    const radiruSection = document.getElementById('radiruRegionSection');
    
    if (service === 'radiru') {
        radikoSection.classList.add('hidden');
        radiruSection.classList.remove('hidden');
    } else {
        radikoSection.classList.remove('hidden');
        radiruSection.classList.add('hidden');
    }
    fetchStations();
}

function onAreaModeChange() {
    const areaMode = document.querySelector('input[name="areaMode"]:checked').value;
    const container = document.getElementById('areaSelectContainer');
    if (areaMode === 'premium') {
        container.classList.remove('hidden');
    } else {
        container.classList.add('hidden');
    }
    fetchStations();
}

async function fetchStations() {
    const service = document.querySelector('input[name="service"]:checked').value;
    let area = '';
    let areaLabel = '';

    if (service === 'radiko') {
        const areaMode = document.querySelector('input[name="areaMode"]:checked').value;
        if (areaMode === 'premium') {
            area = document.getElementById('areaSelect').value;
            areaLabel = `Radiko (指定: ${area})`;
        } else {
            area = 'auto';
            areaLabel = 'Radiko (自動検出中...)';
        }
    } else {
        area = document.getElementById('radiruRegionSelect').value;
        const selectEl = document.getElementById('radiruRegionSelect');
        areaLabel = `らじる★らじる: ${selectEl.options[selectEl.selectedIndex].text}`;
    }

    document.getElementById('stationListTitle').innerText = `放送局一覧 (${areaLabel})`;

    const grid = document.getElementById('stationGrid');
    grid.innerHTML = '<div style="color: #99a1af; text-align: center; padding: 20px; grid-column: 1 / -1;">読み込み中...</div>';

    try {
        const res = await fetch(`ht_r_api.php?action=get_stations&service=${service}&area=${area}`);
        const data = await res.json();

        showRawLog(data);

        if (data.success && data.stations) {
            if (service === 'radiko' && data.detected_area) {
                const areaNames = {};
                const detectedName = areaNames[data.detected_area] || data.detected_area;
                const modeText = (area === 'auto') ? '自動' : '指定';
                areaLabel = `Radiko: ${detectedName} (${data.detected_area} / ${modeText})`;
                document.getElementById('stationListTitle').innerText = `放送局一覧 (${areaLabel})`;
            }

            renderStations(data.stations);
        } else {
            grid.innerHTML = '<div style="color: #ef4444; text-align: center; padding: 20px; grid-column: 1 / -1;">放送局の取得に失敗しました</div>';
        }
    } catch (e) {
        console.error(e);
        showRawLog({ error: e.toString() });
        grid.innerHTML = '<div style="color: #ef4444; text-align: center; padding: 20px; grid-column: 1 / -1;">通信エラーが発生しました</div>';
    }
}

function renderStations(stations) {
    const grid = document.getElementById('stationGrid');
    grid.innerHTML = '';

    if (Array.isArray(stations)) {
        stations.forEach(item => {
            let id = item;
            let name = item;

            const match = item.match(/^(.*?)\s*\(([^)]+)\)$/);
            if (match) {
                name = match[1].trim(); 
                id = match[2].trim();   
            }

            createStationCard(grid, id, name);
        });
    } else {
        for (const [id, name] of Object.entries(stations)) {
            createStationCard(grid, id, name);
        }
    }
}

function createStationCard(container, id, name) {
    const btn = document.createElement('div');
    btn.className = "station-card";
    btn.innerText = name;
    btn.dataset.id = id;
    btn.onclick = () => selectStation(id, name, btn);
    container.appendChild(btn);
}

function selectStation(id, name, element) {
    document.querySelectorAll('.station-card').forEach(el => el.classList.remove('selected'));
    element.classList.add('selected');
    currentStationId = id;
    document.getElementById('selectedStationName').innerText = name;
}

function changeVolume(val) {
    document.getElementById('audioPlayer').volume = val;
}
