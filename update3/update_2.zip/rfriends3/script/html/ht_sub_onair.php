<?php
 function rfmenu01() { global $ht_jump_btn2; global $ht_jump_btn1_label; global $ht_jump_btn2_label; global $ht_jump_addr; global $ht_jump_no; global $sno; $nw = time(); rfmenu_title($nw,2); $piddata = rfgw_ffplay_pid(); if ($piddata !== false) { $n = count_73($piddata); if ($n > 0) { echo_scr(2, ""); foreach($piddata as $pd) { $p = explode(",",$pd); $pid = $p[0]; $ch = $p[1]; $pn = $p[2]; $fmt = sprintf("%6s On air : %s", $pid,$ch); msgx("<div>"); msgx("<a href=menu.html?mno=01&sno=s01b>$fmt</a>　"); msgx("<a href=menu.html?mno=01&sno=s01c><img src=images/speaker.png width=20 height=20 align=top alt='音量調整' title='音量調整' > vol.</a>"); msgx("</div>"); } } } echo_msg(2,""); $ht_jump_btn2 = 1; $ht_jump_btn1_label = "聴取"; $ht_jump_btn2_label = "聴取(サーバ)"; $ht_jump_addr = "menu_s.html"; $ht_jump_no = "0001"; $sno = "02"; rfmenu_onair_all2(); } function rfmenu_onair_all2() { global $ex_radiko; global $ex_radiru; $wdat1 = rfmenu_get_onair($ex_radiko); if ($wdat1 === false) { echo_msg(2,"リストが空です。"); return false; } $wdat2 = rfmenu_get_onair($ex_radiru); if ($wdat2 === false) { echo_msg(2,"リストが空です。"); return false; } $wdat = array_merge($wdat1,$wdat2); $ttl = "放送中番組"; $onairch = rfmenu_play_piddata(); $flist = rfmenu_program_list($ex_radiko, $wdat,1,1,1); $canno = count_73($flist); $opt = array( "title" => $ttl."（$canno 件）", "input_type" => 0, "page_control" => 1, "return_mes" => "終了", "input_mes" => "どれを聴取しますか", "mode" => 1, "multi" => 0, "confirm" => 0, "ht_selid" => "selpgm" ); $ans = ht_ask_list($flist,$opt); } function rfmenu_onair_all3() { global $ex_radiko; global $ex_radiru; $wdat1 = rfmenu_get_onair($ex_radiko); if ($wdat1 === false) { $wdat1 = array(); } $wdat2 = rfmenu_get_onair($ex_radiru); if ($wdat2 === false) { $wdat2 = array(); } $wdat = array_merge($wdat1,$wdat2); $ttl = ""; $onairch = rfmenu_play_piddata(); $flist = rfmenu_program_list($ex_radiko, $wdat,1,1,1); return $flist; } function rfmenu_nowonair($para0) { global $ex_radiko; global $ex_radiru; $ch = $para0[6]; $wdat = rfmenu_get_onair($ex_radiko); if ($wdat !== false) { foreach($wdat as $w) { $para = get_para($w, $ex_radiko); if ($para[6] == $ch) return $para; } } $wdat = rfmenu_get_onair($ex_radiru); if ($wdat !== false) { foreach($wdat as $w) { $para = get_para($w, $ex_radiru); if ($para[6] == $ch) return $para; } } return $para0; } function ht_live_server_vol($getpost) { global $bindir; global $ht_jump_addr; global $ht_jump_no; global $ht_jump_val; global $ht_jump_val2; $dev = rf_amixer_get_dev(); if ($dev == '') { echo_msg(2," ht_live_server_vol : sound device not found"); return; } $dev_name = ""; $card = rf_get_alsa(); $dev_name = $card[0].":".$card[2]." ".$card[1]; $btn = $getpost['btn']; $type = $getpost['type']; $subno = $getpost['subno']; $sno = $getpost['sno']; $val2 = $getpost['val2']; $sel = $getpost['sel']; $val = $getpost['val']; $exname = $getpost['exname']; switch($btn) { case 'volbtn': $val3 = $getpost['val3']; $mute = 'unmute'; break; case 'mutebtn': $val3 = $getpost['val3']; $mute = $getpost['mute']; if ($mute == 'mute') $mute = 'unmute'; else $mute = 'mute'; break; default: $v = rf_alsa_get_volume(); $val3 = $v[0]; $mute = 'mute'; break; } if ($mute == 'mute') { $muteimg = 'mute解除'; $muteimg_now = '<img src="/images/mute.png" width=40 height=25  align=center alt="mute" title="mute" />'; } else { $muteimg = 'mute'; $muteimg_now = '<img src="/images/unmute.png" width=40 height=25  align=center alt="unmute" title="unmute" />'; } $xdg = rfgw_set_xdg().$bindir; $opt = "sset $dev $val3"."% $mute"; $ots = array(); $ot = exec($xdg."amixer $opt",$ots,$ret); if ($ot === false) { echo_msg(2,"sound device not found (2)"); return; } echo <<<EOM1
<table><tr>
<form method='$type' action=$exname val=$val>
    <button class=btn_vol type='submit' name='btn' value='mutebtn'>$muteimg_now</button>
    <input type='range' class='range-input' id='volume' min='0' max='100' step='5' value="$val3" name='val3'>
    <div id='volume-value'></div>
    <input type='hidden' name='subno'   value='$subno'>
    <INPUT type='hidden' name='sno'     value='$sno'>
    <INPUT type='hidden' name='val2'    value='$val2'>
    <INPUT type='hidden' name='sel'     value='$sel'>
    <INPUT type='hidden' name='exname'  value='$exname'>
    <INPUT type='hidden' name='mute'  value='$mute'>

    <p>&nbsp;</p>
    <td>
    <button class='btn_ex' type='submit' name='btn' value='volbtn'>音量設定</button>
    </td>
EOM1;
if ($type == "get") { echo <<<EOM2
<INPUT type='hidden' name='val'     value='$val'>
EOM2;
} else { echo <<<EOM2
<INPUT type='hidden' name='val[0]'     value='$val'>
EOM2;
} echo <<<EOM3
</form>
<td>&nbsp;&nbsp;</td>
<form method='get' action='$ht_jump_addr'>
<td>
<button class='btn_ex' type='submit'>中止</button>
</td>
<INPUT type='hidden' name='subno' value='$ht_jump_no'>
<INPUT type='hidden' name='val'   value='$ht_jump_val'>
<INPUT type='hidden' name='val2'  value='$ht_jump_val2'>
<INPUT type='hidden' name='sno'   value='$sno'>
</form>
</tr></table>

<script>

function rangeOnChange(e) {
  setCurrentValue(e.target.value);
}

function setCurrentValue(val) {
  currentValueElem.innerText = '音量 ' + val + "　($dev_name $val3 %)";
}

window.onload = function () {
  inputElem.addEventListener('input', rangeOnChange); // スライダー変化時
  setCurrentValue(inputElem.value); // ページ読み込み時
}

const inputElem        = document.getElementById('volume');
const currentValueElem = document.getElementById('volume-value');

</script>
EOM3;
} function ht_live_server_vol2($getpost) { global $bindir; global $ht_jump_addr; global $ht_jump_no; global $ht_jump_val; global $ht_jump_val2; global $sound_mode; $dev = ""; $dev_name = ""; switch($sound_mode) { case 0: break; case 1: $dev = rf_amixer_get_dev(); if ($dev == '') { return;k; } $card = rf_get_alsa(); if ($card === false) break; $c1 = $card[1]; $c2 = $card[2]; $dev_name = $card[0].":".$c2." ".$c1; break; case 2: $dev = rf_amixer_get_dev(); if ($dev == '') { return; } $cdat = rf_pulseaudio_now(); if ($cdat !== false) { $dev_name = mb_strimwidth($cdat[1], 0, 40, "..."); } break; default: break; } $btn = $getpost['btn']; $type = $getpost['type']; $subno = $getpost['subno']; $sno = $getpost['sno']; $val2 = $getpost['val2']; $sel = $getpost['sel']; $val = $getpost['val']; $mute = $getpost['mute']; $exname = $getpost['exname']; switch($btn) { case 'volbtn': $val3 = $getpost['val3']; $mute = 'unmute'; break; case 'volminusbtn': $val3 = $getpost['val3'] - 5; if ($val3 < 0) $val3 = 0; $mute = 'unmute'; break; case 'volplusbtn': $val3 = $getpost['val3'] + 5; if ($val3 > 95) $val3 = 95; $mute = 'unmute'; break; case 'mutebtn': $val3 = $getpost['val3']; if ($mute == 'mute') $mute = 'unmute'; else $mute = 'mute'; break; case 'stopbtn': $piddata = rfmenu_play_abort_all(); $v = rf_alsa_get_volume(); $val3 = $v[0]; $mute = 'mute'; break; default: $v = rf_alsa_get_volume(); $val3 = $v[0]; $mute = 'unmute'; if ($val3 == 100) $mute = 'mute'; break; } $ot = rf_alsa_set_volume($dev,$val3,$mute); if ($ot === false) { echo_msg(2,"sound device not found (2)"); return; } msgx("<form method='$type' action=$exname val=$val>"); if ($dev == '') { echo_msg(2,"出力先、音量はOS付属のサウンド設定を使用してください。"); } else { if ($mute == 'mute') { $muteimg = 'mute解除'; $muteimg_now = '<img src="/images/mute.png" width=40 height=25  align=center alt="mute" title="mute" />'; } else { $muteimg = 'mute'; $muteimg_now = '<img src="/images/unmute.png" width=40 height=25  align=center alt="unmute" title="unmute" />'; } $volimg = '音量設定'; $volimg_now = '<img src="/images/reload2.png" width=40 height=25  align=center alt="更新" title="更新" />'; $volplusimg = 'volplus'; $volplusimg_now = '<img src="/images/volplus.png" width=40 height=25  align=center alt="plus" title="plus" />'; $volminusimg = 'volminus'; $volminusimg_now = '<img src="/images/volminus.png" width=40 height=25  align=center alt="minus" title="minus" />'; msgx("<input type='range' class='range-input' id='volume' min='0' max='100' step='5' value='$val3' name='val3'>"); echo <<<EOM1b
    <table>
    <tr>
    <td>
    <button class='btn_vol' type='submit' name='btn' value='mutebtn'>$muteimg_now</button>
    </td>
    <td>
    <button class='btn_vol' type='submit' name='btn' value='volbtn'>$volimg_now</button>
    </td>
    <td>
    <button class='btn_vol' type='submit' name='btn' value='volminusbtn'>$volminusimg_now</button>
    </td>
    <td>
    <button class='btn_vol' type='submit' name='btn' value='volplusbtn'>$volplusimg_now</button>
    </td>
    </tr>
    </table>
EOM1b;
} echo <<<EOM1
    <div id='volume-value'></div>
    <input type='hidden' name='subno'   value='$subno'>
    <INPUT type='hidden' name='sno'     value='$sno'>
    <INPUT type='hidden' name='val2'    value='$val2'>
    <INPUT type='hidden' name='sel'     value='$sel'>
    <INPUT type='hidden' name='exname'  value='$exname'>
    <INPUT type='hidden' name='mute'  value='$mute'>

EOM1;
if ($type == "get") { echo <<<EOM2
<INPUT type='hidden' name='val'     value='$val'>
EOM2;
} else { echo <<<EOM2
<INPUT type='hidden' name='val[0]'     value='$val'>
EOM2;
} echo <<<EOM3
</form>
<form method='get' action='$ht_jump_addr'>
<INPUT type='hidden' name='subno' value='$ht_jump_no'>
<INPUT type='hidden' name='val'   value='$ht_jump_val'>
<INPUT type='hidden' name='val2'  value='$ht_jump_val2'>
<INPUT type='hidden' name='sno'   value='$sno'>
</form>

<script>

function rangeOnChange(e) {
  setCurrentValue(e.target.value);
}

function setCurrentValue(val) {
  currentValueElem.innerText = '音量 ' + val + "　($dev_name $val3 %)";
}

window.onload = function () {
  inputElem.addEventListener('input', rangeOnChange); // スライダー変化時
  setCurrentValue(inputElem.value); // ページ読み込み時
}

const inputElem        = document.getElementById('volume');
const currentValueElem = document.getElementById('volume-value');

</script>
EOM3;
} function ht_wdat_pgm_disp($wdat,$ex_type,$ty) { global $ex_webradio; global $ex_webradio_cors; $para = get_para($wdat, $ex_type); $fr = date("Y/m/d H:i",strtotime($para[0])); $to = date("H:i",strtotime($para[1])); if ($ty == 2) { echo_msg(2,$para[7]); return; } if ($para[0] == ";") { echo_msg(2,$para[6]); } else { echo_msg(2,"$fr - $to ".$para[6]); } echo_msg(2,$para[7]); if ($para[8] != ";") { echo_msg(2,$para[8]); } if ($ex_type == $ex_webradio || $ex_type == $ex_webradio_cors) { $site = ht_wdat_pgm_disp_webradio($para); if ($site != '') { $ref = "<li><a href={$site} target=_blank>{$site}</a></li>"; msgx("$ref"); } } } function ht_wdat_pgm_disp_webradio($para) { $site = ''; $name = str_replace('_',' ',$para[7]); switch($para[15]) { case 'jcba': $url = rf_get_jcba_site($para[6]); if ($url !== false) $site = $url; break; case 'fmpp': $site = ht_get_webradio_site($name); break; case 'ListenRadio': $site = ht_get_webradio_site($name); break; case 'OTTAVA': $site = 'https://ottava.jp/'; break; case 'AFNGO': break; default: break; } return $site; } function ht_get_webradio_site($name) { global $scrdir; $file = $scrdir.'webradio_site.json'; $data = json_decode(file_get_contents($file), true); if ($data === false) return ''; if (isset($data[$name]['公式サイト']) === true) { $site = $data[$name]['公式サイト']; return $site; } return ''; } function ht_pgm_disp($pgm) { echo_msg(2, "$pgm"); echo_msg(2, ""); } function ht_webaudio($fn,$ex_type,$cue) { global $htmldir; global $usrdir; global $usrdir_link; global $link_flg; global $ex_timefree; global $ex_podcast; global $audio_chapter_sec; $piddata = rfmenu_play_abort_all(); $lflg = ""; if ($link_flg == 1) { $p = strpos($fn,$usrdir); if ($p !== false && $p == 0) { $fn = str_replace($usrdir,$usrdir_link,$fn); $lflg = " ,"; } } $ext = pathinfo($fn,PATHINFO_EXTENSION); $fn2 = pathinfo($fn,PATHINFO_BASENAME); $p = strpos($fn,$htmldir); if ($p === false) { $fnx = "$sndfile.$ext"; $temp_fn = $htmldir.$fnx; $ret = copy($fn,$temp_fn); if ($ret === false) { echo_msg(2,"再生に失敗しました。"); return; } $r = rand(10000,99999); $fnx = $fnx.'?'.$r; } else { $pn = strlen($htmldir); $fnx = substr($fn,$pn); } $fnximg = ht_get_pic($fn); ht_pgm_disp($fn2.$lflg); echo <<<EOM1
<p><img id='sndimg'   src='$fnximg'></p>
EOM1;
$chapters = []; if ($cue != "") { if ($ex_type == $ex_timefree) { $chapters = rf_make_chapters($cue); } else if ($ex_type == $ex_podcast) { $chapters = rf_disp_cue_chapters_track($fn); } } if ($chapters == []) { $maxsec = rf_get_duration($fn); $step = $audio_chapter_sec; $chapters = rf_make_step_chapters($maxsec,$step); } $audio_src = $fnx; rf_chapter_player($audio_src, $chapters, $ext); } function ht_webaudio2($fn,$pic) { $piddata = rfmenu_play_abort_all(); $ext = pathinfo($fn,PATHINFO_EXTENSION); echo <<<EOM
<p>
<img id='sndimg' src="$pic">
</p>
<br clear=left>

EOM;
if ($fn != "") { echo <<<EOM2
<audio src="$fn" id='audioimg' type="audio/$ext" controls></audio>
EOM2;
} else { echo_msg(2,"音声の配信がありません。"); } } function ht_webaudio3($val,$dir) { global $htmldir; global $usrdir; global $usrdir_link; global $link_flg; $piddata = rfmenu_play_abort_all(); $fn0 = $dir.$val; $fn = $fn0; $lflg = ""; if ($link_flg == 1) { $p = strpos($fn,$usrdir); if ($p !== false && $p == 0) { $fn = str_replace($usrdir,$usrdir_link,$fn); $lflg = " ,"; } } $ext = pathinfo($fn,PATHINFO_EXTENSION); $p = strpos($fn,$htmldir); if ($p === false) { $fnx = "$sndfile.$ext"; $temp_fn = $htmldir.$fnx; $ret = copy($fn,$temp_fn); if ($ret === false) { echo_msg(2,"再生に失敗しました。"); return; } $r = rand(10000,99999); $fnx = $fnx.'?'.$r; } else { $pn = strlen($htmldir); $fnx = substr($fn,$pn); } $fnximg = ht_get_pic($fn0); ht_pgm_disp($val.$lflg); echo <<<EOM1
<p><img id='sndimg'   src='$fnximg'></p>
<audio  id='audioimg' src='$fnx' type='audio/$ext' controls>
</audio>
EOM1;
} function ht_live($wdat,$ex_type) { global $ex_radiko; global $ex_radiru; $para = get_para($wdat, $ex_type); ht_wdat_pgm_disp($wdat,$ex_type,1); rfriends_live($ex_type,$para,0); echo_msg(2," 時間により次の番組の可能性があります。"); echo_msg(2,""); } function ht_live_server($wdat,$ex_type) { global $ex_podcast; global $ex_radiru; global $ex_radiru_vod; global $ex_webradio; if ($ex_type != $ex_podcast) { ht_wdat_pgm_disp($wdat,$ex_type,1); echo_msg(2,""); } $para = get_para($wdat, $ex_type); if ($para[9] != ";") { msgx('<p><img src='.$para[9].' id="sndimg"></p>'); } else if($ex_type == $ex_radiru || $ex_type == $ex_radiru_vod) { $ch_cs = callsign2($para[6]); if ($ch_cs != "UNKNOWN") { $img = sprintf($station_logo_url, $ch_cs); msgx('<p><img src='.$img.' id="sndimg"></p>'); } } $getpost = ht_getpost(); $ret = ht_live_server_vol2($getpost); $btn = $getpost['btn']; if ($btn == "") { $flg = 0; $auto = 0; rfriends_live_sub($ex_type,$para,$flg,$auto,0); } ht_button_cansnd("中止."); } function ht_getpost() { $getpost = array(); $getpost['btn'] = ''; $getpost['mute'] = 'mute'; if (isset($_GET['subno'])) { $getpost['type'] = 'get'; $getpost['subno'] = $_GET['subno']; $getpost['val'] = $_GET['val']; $getpost['sel'] = $_GET['sel']; $getpost['val2'] = $_GET['val2']; $getpost['sno'] = $_GET['sno']; $getpost['exname'] = $_GET['exname']; if (isset($_GET['mute'])) { $getpost['mute'] = $_GET['mute']; } if (isset($_GET['btn'])) { $getpost['btn'] = $_GET['btn']; $getpost['val3'] = $_GET['val3']; } } else if (isset($_POST['subno'])) { $getpost['type'] = 'post'; $getpost['subno'] = $_POST['subno']; $v = $_POST['val']; $getpost['val'] = $v[0]; $getpost['sel'] = $_POST['sel']; $getpost['val2'] = $_POST['val2']; $getpost['sno'] = $_POST['sno']; $getpost['exname'] = $_POST['exname']; if (isset($_POST['mute'])) { $getpost['mute'] = $_POST['mute']; } if (isset($_POST['btn'])) { $getpost['btn'] = $_POST['btn']; $getpost['val3'] = $_POST['val3']; } } return $getpost; } function ht_live_timefree($wdat,$ex_type) { ht_wdat_pgm_disp($wdat,$ex_type,1); $para = get_para($wdat, $ex_type); rfriends_live($ex_type,$para,0); } function ht_live_radiru_vod($wdat,$ex_type) { ht_wdat_pgm_disp($wdat,$ex_type,1); $para = get_para($wdat, $ex_type); rfriends_live($ex_type,$para,0); } function rf_chapter_player($audio_src, $chapters, $ext) { global $audio_chapter_sec; global $audio_skip_back_sec; global $audio_skip_fwd_sec; $back = $audio_skip_back_sec; $fwd = $audio_skip_fwd_sec; $player_id = "audioimg"; $audio_src2 = htmlspecialchars($audio_src, ENT_QUOTES, 'UTF-8'); $json_chapters = json_encode($chapters); $chap_left = '<img src="/images/chap_left.png"  width=40 height=25  align=center />'; $skip_back = '<img src="/images/skip_back.png"  width=40 height=25  align=center />'; $skip_fwd = '<img src="/images/skip_fwd.png"   width=40 height=25  align=center />'; $chap_right = '<img src="/images/chap_right.png" width=40 height=25  align=center />'; echo <<<EOM
    <div class="audio-player-module">
        <audio  id="$player_id" src="$audio_src2" type="audio/$ext" controls></audio>
        <div class="controls" style="margin-top: 10px;">
            <button id="{$player_id}-prev" class="btn_vol" alt="prev. chapter" title="prev. chapter">$chap_left</button>
            <button id="{$player_id}-back" class="btn_vol" alt="- {$back}s"    title="- {$back}s">$skip_back</button>
            <button id="{$player_id}-fwd"  class="btn_vol" alt="+ {$fwd}s"     title="+ {$fwd}s">$skip_fwd</button>
            <button id="{$player_id}-next" class="btn_vol" alt="next chapter"  title="next chapter">$chap_right</button>
        </div>
    </div>

    <script>
        (function() {
            const chapters = {$json_chapters}.map(Number);
            
            const audio = document.getElementById('$player_id');
            const prevBtn = document.getElementById('{$player_id}-prev');
            const backBtn = document.getElementById('{$player_id}-back');
            const fwdBtn = document.getElementById('{$player_id}-fwd');
            const nextBtn = document.getElementById('{$player_id}-next');

            function getCurrentChapterIndex() {
                const currentTime = audio.currentTime;
                let currentIndex = 0;
                for (let i = 0; i < chapters.length; i++) {
                    if (chapters[i] <= currentTime + 0.5) {
                        currentIndex = i;
                    } else {
                        break;
                    }
                }
                return currentIndex;
            }

            fwdBtn.addEventListener('click', () => {
                audio.currentTime = Math.min(audio.currentTime + {$fwd}, audio.duration);
            });

            backBtn.addEventListener('click', () => {
                audio.currentTime = Math.max(audio.currentTime - {$back}, 0);
            });

            nextBtn.addEventListener('click', () => {
                const currentIndex = getCurrentChapterIndex();
                const nextIndex = currentIndex + 1;
                if (nextIndex < chapters.length) {
                    audio.currentTime = chapters[nextIndex];
                } else {
                    audio.currentTime = audio.duration || chapters[chapters.length - 1];
                }
            });

            prevBtn.addEventListener('click', () => {
                const currentTime = audio.currentTime;
                const currentIndex = getCurrentChapterIndex();
                if (currentTime - chapters[currentIndex] < 1.5 && currentIndex > 0) {
                    audio.currentTime = chapters[currentIndex - 1];
                } else {
                    audio.currentTime = chapters[currentIndex];
                }
            });
        })();
    </script>
EOM;
} function rf_chapter_player_hls($audio_src, $chapters) { $player_id = "audioimg"; $audio_src2 = htmlspecialchars($audio_src, ENT_QUOTES, 'UTF-8'); $json_chapters = json_encode($chapters); $chap_left = '<img src="/images/chap_left.png"  width=40 height=25  align=center alt="chap_left" title="chap_left" />'; $chap_right = '<img src="/images/chap_right.png" width=40 height=25  align=center alt="chap_right" title="chap_right" />'; echo <<<EOM
    <div class="audio-player-module">
        <video id="{$player_id}" type="audio/$ext" controls></video>

        <div class="controls" style="margin-top: 10px;">
            <button id="{$player_id}-prev" class="btn_vol">$chap_left</button>
            <button id="{$player_id}-next" class="btn_vol">$chap_right</button>
        </div>
    </div>

    <script>
        (function() {
            const videoSrc = {$audio_src2};
            const chapters = {$json_chapters}.map(Number);
            
            const video = document.getElementById('{$player_id}');
            const prevBtn = document.getElementById('{$player_id}-prev');
            const nextBtn = document.getElementById('{$player_id}-next');

            if (Hls.isSupported()) {
                const hls = new Hls();
                hls.loadSource(videoSrc);
                hls.attachMedia(video);
            } 
            else if (video.canPlayType('application/vnd.apple.mpegurl')) {
                video.src = videoSrc;
            }

            function getCurrentChapterIndex() {
                const currentTime = video.currentTime;
                let currentIndex = 0;
                for (let i = 0; i < chapters.length; i++) {
                    if (chapters[i] <= currentTime + 0.05) {
                        currentIndex = i;
                    } else {
                        break;
                    }
                }
                return currentIndex;
            }

            nextBtn.addEventListener('click', () => {
                const currentIndex = getCurrentChapterIndex();
                const nextIndex = currentIndex + 1;
                if (nextIndex < chapters.length) {
                    video.currentTime = chapters[nextIndex];
                } else {
                    video.currentTime = video.duration || chapters[chapters.length - 1];
                }
            });

            prevBtn.addEventListener('click', () => {
                const currentTime = video.currentTime;
                const currentIndex = getCurrentChapterIndex();
                if (currentTime - chapters[currentIndex] < 0.8 && currentIndex > 0) {
                    video.currentTime = chapters[currentIndex - 1];
                } else {
                    video.currentTime = chapters[currentIndex];
                }
            });
        })();
    </script>
EOM;
} function rf_make_step_chapters($maxsec,$step) { $chapters = []; $sec = 0; while ($sec < $maxsec) { $chapters[] = $sec; $sec += $step; } $chapters[] = $maxsec; return $chapters; } function ht_sort_recdata($files,$mno,$sno) { $sort_options = [ 'title_desc' => [ 'label' => 'ファイル名（降順）', 'required_key' => 'title', 'func' => function($a, $b) { $valA = isset($a['title']) ? $a['title'] : ''; $valB = isset($b['title']) ? $b['title'] : ''; return strcmp($valB, $valA); } ], 'title_asc' => [ 'label' => 'ファイル名（昇順）', 'required_key' => 'title', 'func' => function($a, $b) { $valA = isset($a['title']) ? $a['title'] : ''; $valB = isset($b['title']) ? $b['title'] : ''; return strcmp($valA, $valB); } ], 'program_desc' => [ 'label' => '番組名（降順）', 'required_key' => 'program', 'func' => function($a, $b) { $valA = isset($a['program']) ? $a['program'] : ''; $valB = isset($b['program']) ? $b['program'] : ''; return strcmp($valB, $valA); } ], 'program_asc' => [ 'label' => '番組名（昇順）', 'required_key' => 'program', 'func' => function($a, $b) { $valA = isset($a['program']) ? $a['program'] : ''; $valB = isset($b['program']) ? $b['program'] : ''; return strcmp($valA, $valB); } ], 'recdate_desc' => [ 'label' => '録音日付（降順）', 'required_key' => 'recdate', 'func' => function($a, $b) { $valA = isset($a['recdate']) ? $a['recdate'] : ''; $valB = isset($b['recdate']) ? $b['recdate'] : ''; return strcmp($valB, $valA); } ], 'recdate_asc' => [ 'label' => '録音日付（昇順）', 'required_key' => 'recdate', 'func' => function($a, $b) { $valA = isset($a['recdate']) ? $a['recdate'] : ''; $valB = isset($b['recdate']) ? $b['recdate'] : ''; return strcmp($valA, $valB); } ], ]; if (!empty($files)) { $first_file = current($files); foreach ($sort_options as $key => $option) { $req_key = $option['required_key']; if (!array_key_exists($req_key, $first_file)) { unset($sort_options[$key]); } } } $current_sort = isset($_POST['sort_order']) && isset($sort_options[$_POST['sort_order']]) ? $_POST['sort_order'] : 'title_asc'; msgx('<form method="POST" action="">'); msgx('<label for="sort_order">&nbsp;&nbsp;ソート：</label>'); msgx('<select name="sort_order" id="sort_order" onchange="this.form.submit()">'); foreach ($sort_options as $key => $option) { if($current_sort === $key) $sel = 'selected'; else $sel = ''; msgx("<option value='{$key}' {$sel}>"); msgx(htmlspecialchars($option['label'], ENT_QUOTES, 'UTF-8')); msgx('</option>'); } msgx('</select>'); msgx("<INPUT type='hidden' name='mno' value='$mno'>"); msgx("<INPUT type='hidden' name='sno' value='$sno'>"); msgx('</form>'); echo_msg(2,""); usort($files, $sort_options[$current_sort]['func']); return $files; } function ht_menu_play($ex_type,$mno,$sno) { global $ex_radiko; global $ex_radiru; global $ex_timefree; global $ex_radiru_vod; global $ex_radiru_gogaku; global $ex_podcast; global $ex_webradio; global $ex_misc; global $radiko_recdir; global $radiru_recdir; global $timefree_recdir; global $radiru_vod_recdir; global $radiru_gogaku_recdir; global $podcast_recdir; global $webradio_recdir; global $dir_radiko; global $dir_radiru; global $dir_timefree; global $dir_radiru_vod; global $dir_radiru_gogaku; global $dir_podcast; global $dir_webradio; global $dir_misc; global $rec_extension; global $ui_mode; global $htmldir; switch ($ex_type) { case $ex_radiko: $mes = "ラジコ録音データ"; $dir = $radiko_recdir; $subdir = $dir_radiko; $extm4a = 1; $extmp3 = 0; break; case $ex_radiru: $mes = "らじるらじる録音データ"; $dir = $radiru_recdir; $subdir = $dir_radiru; $extm4a = 1; $extmp3 = 0; break; case $ex_timefree: $mes = "タイムフリー録音データ"; $dir = $timefree_recdir; $subdir = $dir_timefree; $extm4a = 1; $extmp3 = 0; break; case $ex_radiru_vod: $mes = "らじるらじる聞き逃し録音データ"; $dir = $radiru_vod_recdir; $subdir = $dir_radiru_vod; $extm4a = 1; $extmp3 = 0; break; case $ex_radiru_gogaku: $mes = "らじるらじるゴガク録音データ"; $dir = $radiru_gogaku_recdir; $subdir = $dir_radiru_gogaku; $extm4a = 1; $extmp3 = 0; break; case $ex_podcast: $mes = "ポッドキャスト録音データ"; $dir = $podcast_recdir; $subdir = $dir_podcast; $extm4a = 0; $extmp3 = 1; break; case $ex_webradio: $mes = "ウェブラジオ録音データ"; $dir = $webradio_recdir; $subdir = $dir_webradio; $extm4a = 1; $extmp3 = 1; break; case $ex_misc: $mes = "ラジオ録音データ"; $dir = ""; $subdir = ""; $extm4a = 0; $extmp3 = 0; break; default: return; break; } $flist1 = []; $flist2 = []; if ($extm4a == 1) { $typ1 = "*."."m4a"; $flist1 = ht_get_flists($dir, $typ1); } if ($extmp3 == 1) { $typ2 = "*."."mp3"; $flist2 = ht_get_flists($dir, $typ2); } $flist = array_merge($flist1,$flist2); $cnt = count_73($flist); if ($cnt < 1) { echo_msg(2,"$mes 一覧"); echo_msg(2,""); echo_msg(2, "ファイルがありません。"); return; } $flist = ht_sort_recdata($flist,$mno,$sno); $opt = array( "title" => "$mes 一覧（$cnt 件）", "input_type" => 0, "page_control" => 1, "return_mes" => "終了", "input_mes" => "どれを再生しますか", "mode" => 1, "multi" => 0, "confirm" => 0, "ht_selid" => "selpgm", "kind1" => $subdir ); ht_ask_list($flist,$opt); } function ht_get_flists($dir, $typ) { $pat = $dir.$typ; if ($pat == "") { return array(); } $str = glob($pat); if ($str === false) { return array(); } $flist = array(); foreach ($str as $f) { $path_parts = pathinfo($f); $f2 = $path_parts['basename']; $ext = $path_parts['extension']; $fn = $path_parts['filename']; $parts = explode('_',$fn); $cnt = count_73($parts); if ($cnt == 5 || $cnt == 6) { $station = $parts[0]; $program = $parts[1]; $recdate = $parts[2].$parts[4]; $flist[] = array('title' => $f2, 'val' => $f2, 'station' => $station, 'program' => $program, 'recdate' => $recdate); } else { $flist[] = array('title' => $f2, 'val' => $f2); } } return $flist; } 