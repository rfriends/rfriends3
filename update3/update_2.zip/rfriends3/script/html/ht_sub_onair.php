<?php
 function rfmenu01() { global $ht_jump_btn2; global $ht_jump_btn1_label; global $ht_jump_btn2_label; global $ht_jump_addr; global $ht_jump_no; global $sno; $nw = time(); rfmenu_title($nw,2); $piddata = rfgw_ffplay_pid(); if ($piddata !== false) { $n = count_73($piddata); if ($n > 0) { echo_scr(2, ""); foreach($piddata as $pd) { $p = explode(",",$pd); $pid = $p[0]; $ch = $p[1]; $pn = $p[2]; $fmt = sprintf("%6s On air : %s", $pid,$ch); msgx("<div>"); msgx("<a href=menu.html?mno=01&sno=s01b>$fmt</a>　"); msgx("<a href=menu.html?mno=01&sno=s01c><img src=images/speaker.png width=20 height=20 align=top alt='音量調整' title='音量調整' > vol.</a>"); msgx("</div>"); } } } echo_msg(2,""); $ht_jump_btn2 = 1; $ht_jump_btn1_label = "聴取"; $ht_jump_btn2_label = "聴取(サーバ)"; $ht_jump_addr = "menu_s.html"; $ht_jump_no = "0001"; $sno = "02"; rfmenu_onair_all2(); } function rfmenu_onair_all2() { global $ex_radiko; global $ex_radiru; $wdat1 = rfmenu_get_onair($ex_radiko); if ($wdat1 === false) { echo_msg(2,"リストが空です。"); return false; } $wdat2 = rfmenu_get_onair($ex_radiru); if ($wdat2 === false) { echo_msg(2,"リストが空です。"); return false; } $wdat = array_merge($wdat1,$wdat2); $ttl = "放送中番組"; $onairch = rfmenu_play_piddata(); $flist = rfmenu_program_list($ex_radiko, $wdat,1,1,1); $canno = count_73($flist); $opt = array( "title" => $ttl."（$canno 件）", "input_type" => 0, "page_control" => 1, "return_mes" => "終了", "input_mes" => "どれを聴取しますか", "mode" => 1, "multi" => 0, "confirm" => 0, "ht_selid" => "selpgm" ); $ans = ht_ask_list($flist,$opt); } function rfmenu_onair_all3() { global $ex_radiko; global $ex_radiru; $wdat1 = rfmenu_get_onair($ex_radiko); if ($wdat1 === false) { $wdat1 = array(); } $wdat2 = rfmenu_get_onair($ex_radiru); if ($wdat2 === false) { $wdat2 = array(); } $wdat = array_merge($wdat1,$wdat2); $ttl = ""; $onairch = rfmenu_play_piddata(); $flist = rfmenu_program_list($ex_radiko, $wdat,1,1,1); return $flist; } function rfmenu_nowonair($para0) { global $ex_radiko; global $ex_radiru; $ch = $para0[6]; $wdat = rfmenu_get_onair($ex_radiko); if ($wdat !== false) { foreach($wdat as $w) { $para = get_para($w, $ex_radiko); if ($para[6] == $ch) return $para; } } $wdat = rfmenu_get_onair($ex_radiru); if ($wdat !== false) { foreach($wdat as $w) { $para = get_para($w, $ex_radiru); if ($para[6] == $ch) return $para; } } return $para0; } function ht_live_server_vol($getpost) { global $bindir; global $ht_jump_addr; global $ht_jump_no; global $ht_jump_val; global $ht_jump_val2; $dev = rf_amixer_get_dev(); if ($dev == '') { echo_msg(2," ht_live_server_vol : sound device not found"); return; } $dev_name = ""; $card = rf_get_alsa(); $dev_name = $card[0].":".$card[2]." ".$card[1]; $btn = $getpost['btn']; $type = $getpost['type']; $subno = $getpost['subno']; $sno = $getpost['sno']; $val2 = $getpost['val2']; $sel = $getpost['sel']; $val = $getpost['val']; $exname = $getpost['exname']; switch($btn) { case 'volbtn': $val3 = $getpost['val3']; $mute = 'unmute'; break; case 'mutebtn': $val3 = $getpost['val3']; $mute = $getpost['mute']; if ($mute == 'mute') $mute = 'unmute'; else $mute = 'mute'; break; default: $v = rf_alsa_get_volume(); $val3 = $v[0]; $mute = 'mute'; break; } if ($mute == 'mute') { $muteimg = 'mute解除'; $muteimg_now = '<img src="/images/mute.png" width=40 height=25  align=center alt="mute" title="mute" />'; } else { $muteimg = 'mute'; $muteimg_now = '<img src="/images/unmute.png" width=40 height=25  align=center alt="unmute" title="unmute" />'; } $xdg = rfgw_set_xdg().$bindir; $opt = "sset $dev $val3"."% $mute"; $ots = array(); $ot = exec($xdg."amixer $opt",$ots,$ret); if ($ot === false) { echo_msg(2,"sound device not found (2)"); return; } echo <<<EOM1
<table><tr>
<form method='$type' action=$exname val=$val>
    <button class=btn_vol type='submit' name='btn' value='mutebtn'>$muteimg_now</button>
    <input type='range' class='range-input' id='volume' min='0' max='100' step='5' value="$val3" name='val3'>
    <div id='volume-value'></div>
    <input type='hidden' name='subno'   value='$subno'>
    <INPUT type='hidden' name='sno'     value='$sno'>
    <INPUT type='hidden' name='val2'    value='$val2'>
    <INPUT type='hidden' name='sel'     value='$sel'>
    <INPUT type='hidden' name='exname'  value='$exname'>
    <INPUT type='hidden' name='mute'  value='$mute'>

    <p>&nbsp;</p>
    <td>
    <button class='btn_ex' type='submit' name='btn' value='volbtn'>音量設定</button>
    </td>
EOM1;
if ($type == "get") { echo <<<EOM2
<INPUT type='hidden' name='val'     value='$val'>
EOM2;
} else { echo <<<EOM2
<INPUT type='hidden' name='val[0]'     value='$val'>
EOM2;
} echo <<<EOM3
</form>
<td>&nbsp;&nbsp;</td>
<form method='get' action='$ht_jump_addr'>
<td>
<button class='btn_ex' type='submit'>中止</button>
</td>
<INPUT type='hidden' name='subno' value='$ht_jump_no'>
<INPUT type='hidden' name='val'   value='$ht_jump_val'>
<INPUT type='hidden' name='val2'  value='$ht_jump_val2'>
<INPUT type='hidden' name='sno'   value='$sno'>
</form>
</tr></table>

<script>

function rangeOnChange(e) {
  setCurrentValue(e.target.value);
}

function setCurrentValue(val) {
  currentValueElem.innerText = '音量 ' + val + "　($dev_name $val3 %)";
}

window.onload = function () {
  inputElem.addEventListener('input', rangeOnChange); // スライダー変化時
  setCurrentValue(inputElem.value); // ページ読み込み時
}

const inputElem        = document.getElementById('volume');
const currentValueElem = document.getElementById('volume-value');

</script>
EOM3;
} function ht_live_server_vol2($getpost) { global $bindir; global $ht_jump_addr; global $ht_jump_no; global $ht_jump_val; global $ht_jump_val2; global $sound_mode; $dev = ""; $dev_name = ""; switch($sound_mode) { case 0: break; case 1: $dev = rf_amixer_get_dev(); if ($dev == '') { return;k; } $card = rf_get_alsa(); if ($card === false) break; $c1 = $card[1]; $c2 = $card[2]; $dev_name = $card[0].":".$c2." ".$c1; break; case 2: $dev = rf_amixer_get_dev(); if ($dev == '') { return; } $cdat = rf_pulseaudio_now(); if ($cdat !== false) { $dev_name = mb_strimwidth($cdat[1], 0, 40, "..."); } break; default: break; } $btn = $getpost['btn']; $type = $getpost['type']; $subno = $getpost['subno']; $sno = $getpost['sno']; $val2 = $getpost['val2']; $sel = $getpost['sel']; $val = $getpost['val']; $mute = $getpost['mute']; $exname = $getpost['exname']; switch($btn) { case 'volbtn': $val3 = $getpost['val3']; $mute = 'unmute'; break; case 'volminusbtn': $val3 = $getpost['val3'] - 5; if ($val3 < 0) $val3 = 0; $mute = 'unmute'; break; case 'volplusbtn': $val3 = $getpost['val3'] + 5; if ($val3 > 95) $val3 = 95; $mute = 'unmute'; break; case 'mutebtn': $val3 = $getpost['val3']; if ($mute == 'mute') $mute = 'unmute'; else $mute = 'mute'; break; case 'stopbtn': $piddata = rfmenu_play_abort_all(); $v = rf_alsa_get_volume(); $val3 = $v[0]; $mute = 'mute'; break; default: $v = rf_alsa_get_volume(); $val3 = $v[0]; $mute = 'unmute'; if ($val3 == 100) $mute = 'mute'; break; } $ot = rf_alsa_set_volume($dev,$val3,$mute); if ($ot === false) { echo_msg(2,"sound device not found (2)"); return; } msgx("<form method='$type' action=$exname val=$val>"); if ($dev == '') { echo_msg(2,"出力先、音量はOS付属のサウンド設定を使用してください。"); } else { if ($mute == 'mute') { $muteimg = 'mute解除'; $muteimg_now = '<img src="/images/mute.png" width=40 height=25  align=center alt="mute" title="mute" />'; } else { $muteimg = 'mute'; $muteimg_now = '<img src="/images/unmute.png" width=40 height=25  align=center alt="unmute" title="unmute" />'; } $volimg = '音量設定'; $volimg_now = '<img src="/images/vol.png" width=40 height=25  align=center alt="音量設定" title="音量設定" />'; $volplusimg = 'volplus'; $volplusimg_now = '<img src="/images/volplus.png" width=40 height=25  align=center alt="plus" title="plus" />'; $volminusimg = 'volminus'; $volminusimg_now = '<img src="/images/volminus.png" width=40 height=25  align=center alt="minus" title="minus" />'; msgx("<input type='range' class='range-input' id='volume' min='0' max='100' step='5' value='$val3' name='val3'>"); echo <<<EOM1b
    <table>
    <tr>
    <td>
    <button class='btn_vol' type='submit' name='btn' value='mutebtn'>$muteimg_now</button>
    </td>
    <td>
    <button class='btn_vol' type='submit' name='btn' value='volbtn'>$volimg_now</button>
    </td>
    <td>
    <button class='btn_vol' type='submit' name='btn' value='volminusbtn'>$volminusimg_now</button>
    </td>
    <td>
    <button class='btn_vol' type='submit' name='btn' value='volplusbtn'>$volplusimg_now</button>
    </td>
    </tr>
    </table>
EOM1b;
} echo <<<EOM1
    <div id='volume-value'></div>
    <input type='hidden' name='subno'   value='$subno'>
    <INPUT type='hidden' name='sno'     value='$sno'>
    <INPUT type='hidden' name='val2'    value='$val2'>
    <INPUT type='hidden' name='sel'     value='$sel'>
    <INPUT type='hidden' name='exname'  value='$exname'>
    <INPUT type='hidden' name='mute'  value='$mute'>

EOM1;
if ($type == "get") { echo <<<EOM2
<INPUT type='hidden' name='val'     value='$val'>
EOM2;
} else { echo <<<EOM2
<INPUT type='hidden' name='val[0]'     value='$val'>
EOM2;
} echo <<<EOM3
</form>
<form method='get' action='$ht_jump_addr'>
<INPUT type='hidden' name='subno' value='$ht_jump_no'>
<INPUT type='hidden' name='val'   value='$ht_jump_val'>
<INPUT type='hidden' name='val2'  value='$ht_jump_val2'>
<INPUT type='hidden' name='sno'   value='$sno'>
</form>

<script>

function rangeOnChange(e) {
  setCurrentValue(e.target.value);
}

function setCurrentValue(val) {
  currentValueElem.innerText = '音量 ' + val + "　($dev_name $val3 %)";
}

window.onload = function () {
  inputElem.addEventListener('input', rangeOnChange); // スライダー変化時
  setCurrentValue(inputElem.value); // ページ読み込み時
}

const inputElem        = document.getElementById('volume');
const currentValueElem = document.getElementById('volume-value');

</script>
EOM3;
} function ht_wdat_pgm_disp($wdat,$ex_type,$ty) { $para = get_para($wdat, $ex_type); $fr = date("Y/m/d H:i",strtotime($para[0])); $to = date("H:i",strtotime($para[1])); switch($ty) { case 2: echo_msg(2,$para[7]); break; case 1: default: if ($para[0] == ";") { echo_msg(2,$para[6]); } else { echo_msg(2,"$fr - $to ".$para[6]); } echo_msg(2,$para[7]); if ($para[8] != ";") { echo_msg(2,$para[8]); } break; } } function ht_pgm_disp($pgm) { echo_msg(2, "$pgm"); echo_msg(2, ""); } function ht_webaudio($fn,$ex_type,$cue) { global $htmldir; global $usrdir; global $usrdir_link; global $link_flg; $piddata = rfmenu_play_abort_all(); $lflg = ""; if ($link_flg == 1) { $p = strpos($fn,$usrdir); if ($p !== false && $p == 0) { $fn = str_replace($usrdir,$usrdir_link,$fn); $lflg = " ,"; } } $ext = pathinfo($fn,PATHINFO_EXTENSION); $p = strpos($fn,$htmldir); if ($p === false) { $fnx = "$sndfile.$ext"; $temp_fn = $htmldir.$fnx; $ret = copy($fn,$temp_fn); if ($ret === false) { echo_msg(2,"再生に失敗しました。"); return; } $r = rand(10000,99999); $fnx = $fnx.'?'.$r; } else { $pn = strlen($htmldir); $fnx = substr($fn,$pn); } $fnximg = ht_get_pic($fn0); ht_pgm_disp($val.$lflg); echo <<<EOM1
<p><img id='sndimg'   src='$fnximg'></p>
EOM1;
if ($cue == "") { $maxsec = rf_get_duration($fn); $step = 300; $chapters = rf_make_step_chapters($maxsec,$step); } else { $chapters = rf_make_chapters($cue); } $audio_src = $fnx; rf_chapter_player($audio_src, $chapters,$ext); } function ht_webaudio2($fn,$pic) { $piddata = rfmenu_play_abort_all(); $ext = pathinfo($fn,PATHINFO_EXTENSION); echo <<<EOM
<p>
<img id='sndimg' src="$pic">
</p>
<br clear=left>

EOM;
if ($fn != "") { echo <<<EOM2
<audio src="$fn" id='audioimg' type="audio/$ext" controls></audio>
EOM2;
} else { echo_msg(2,"音声の配信がありません。"); } } function ht_webaudio3($val,$dir) { global $htmldir; global $usrdir; global $usrdir_link; global $link_flg; $piddata = rfmenu_play_abort_all(); $fn0 = $dir.$val; $fn = $fn0; $lflg = ""; if ($link_flg == 1) { $p = strpos($fn,$usrdir); if ($p !== false && $p == 0) { $fn = str_replace($usrdir,$usrdir_link,$fn); $lflg = " ,"; } } $ext = pathinfo($fn,PATHINFO_EXTENSION); $p = strpos($fn,$htmldir); if ($p === false) { $fnx = "$sndfile.$ext"; $temp_fn = $htmldir.$fnx; $ret = copy($fn,$temp_fn); if ($ret === false) { echo_msg(2,"再生に失敗しました。"); return; } $r = rand(10000,99999); $fnx = $fnx.'?'.$r; } else { $pn = strlen($htmldir); $fnx = substr($fn,$pn); } $fnximg = ht_get_pic($fn0); ht_pgm_disp($val.$lflg); echo <<<EOM1
<p><img id='sndimg'   src='$fnximg'></p>
<audio  id='audioimg' src='$fnx' type='audio/$ext' controls>
</audio>
EOM1;
} function ht_live($wdat,$ex_type) { global $ex_radiko; global $ex_radiru; $para = get_para($wdat, $ex_type); ht_wdat_pgm_disp($wdat,$ex_type,1); rfriends_live($ex_type,$para,0); echo_msg(2," 時間により次の番組の可能性があります。"); echo_msg(2,""); } function ht_play_server($fn,$dir,$ex_type) { global $scrdir; global $tmpdir; global $htmldir; $fl = $dir.$fn; $ret = ht_filer($fl,2,$ex_type); if ($ret === false) { echo_msg(2, $fl); echo_msg(2, ""); echo_msg(2, "サポート外のファイルです。"); } return; $opt_fn = make_fn("playsvr"); $tfn = $tmpdir.$opt_fn.".dat"; $img = "temp/".$opt_fn.".jpg"; rf_unlink_glob($tmpdir,"playsvr*"); rf_unlink_glob($htmldir,"temp/playsvr*"); file_put_contents($tfn, $fn2,LOCK_EX); get_artwork($fn2,$htmldir.$img); msgx("<p><img src=\"$img\" id=\"sndimg\"></p>"); $nam = "rfriends_exec_play"; $opt = "13 \"$opt_fn\""; $ex = "ex_rfriends"; $getpost = ht_getpost(); $ret = ht_live_server_vol2($getpost); $btn = $getpost['btn']; if ($btn == "") { $piddata = rfmenu_play_abort_all(); rfgw_batsh_sub($scrdir, $ex, $opt, 1, 1); } ht_button_cansnd("中止."); } function ht_live_server($wdat,$ex_type) { global $ex_podcast; global $ex_radiru; global $ex_radiru_vod; global $ex_webradio; if ($ex_type != $ex_podcast) { ht_wdat_pgm_disp($wdat,$ex_type,1); echo_msg(2,""); } $para = get_para($wdat, $ex_type); if ($para[9] != ";") { msgx('<p><img src='.$para[9].' id="sndimg"></p>'); } else if($ex_type == $ex_radiru || $ex_type == $ex_radiru_vod) { $ch_cs = callsign2($para[6]); if ($ch_cs != "UNKNOWN") { $img = sprintf($station_logo_url, $ch_cs); msgx('<p><img src='.$img.' id="sndimg"></p>'); } } $getpost = ht_getpost(); $ret = ht_live_server_vol2($getpost); $btn = $getpost['btn']; if ($btn == "") { $flg = 0; $auto = 0; rfriends_live_sub($ex_type,$para,$flg,$auto,0); } ht_button_cansnd("中止."); } function ht_getpost() { $getpost = array(); $getpost['btn'] = ''; $getpost['mute'] = 'mute'; if (isset($_GET['subno'])) { $getpost['type'] = 'get'; $getpost['subno'] = $_GET['subno']; $getpost['val'] = $_GET['val']; $getpost['sel'] = $_GET['sel']; $getpost['val2'] = $_GET['val2']; $getpost['sno'] = $_GET['sno']; $getpost['exname'] = $_GET['exname']; if (isset($_GET['mute'])) { $getpost['mute'] = $_GET['mute']; } if (isset($_GET['btn'])) { $getpost['btn'] = $_GET['btn']; $getpost['val3'] = $_GET['val3']; } } else if (isset($_POST['subno'])) { $getpost['type'] = 'post'; $getpost['subno'] = $_POST['subno']; $v = $_POST['val']; $getpost['val'] = $v[0]; $getpost['sel'] = $_POST['sel']; $getpost['val2'] = $_POST['val2']; $getpost['sno'] = $_POST['sno']; $getpost['exname'] = $_POST['exname']; if (isset($_POST['mute'])) { $getpost['mute'] = $_POST['mute']; } if (isset($_POST['btn'])) { $getpost['btn'] = $_POST['btn']; $getpost['val3'] = $_POST['val3']; } } return $getpost; } function ht_live_timefree($wdat,$ex_type) { ht_wdat_pgm_disp($wdat,$ex_type,1); $para = get_para($wdat, $ex_type); rfriends_live($ex_type,$para,0); } function ht_live_radiru_vod($wdat,$ex_type) { ht_wdat_pgm_disp($wdat,$ex_type,1); $para = get_para($wdat, $ex_type); rfriends_live($ex_type,$para,0); } function rf_chapter_player($audio_src, $chapters, $ext) { $player_id = "audioimg"; $audio_src2 = htmlspecialchars($audio_src, ENT_QUOTES, 'UTF-8'); $json_chapters = json_encode($chapters); $chap_left = '<img src="/images/chap_left.png"  width=40 height=25  align=center alt="chap_left" title="chap_left" />'; $chap_right = '<img src="/images/chap_right.png" width=40 height=25  align=center alt="chap_right" title="chap_right" />'; echo <<<EOM
    <div class="audio-player-module">
        <audio  id="$player_id" src="$audio_src2" type="audio/$ext" controls></audio>
        <div class="controls" style="margin-top: 10px;">
            <button id="{$player_id}-prev" class="btn_vol">$chap_left</button>
            <button id="{$player_id}-next" class="btn_vol">$chap_right</button>
        </div>
    </div>

    <script>
        (function() {
            const chapters = {$json_chapters}.map(Number);
            
            const audio = document.getElementById('$player_id');
            const prevBtn = document.getElementById('{$player_id}-prev');
            const nextBtn = document.getElementById('{$player_id}-next');

            function getCurrentChapterIndex() {
                const currentTime = audio.currentTime;
                let currentIndex = 0;
                for (let i = 0; i < chapters.length; i++) {
                    if (chapters[i] <= currentTime + 0.5) {
                        currentIndex = i;
                    } else {
                        break;
                    }
                }
                return currentIndex;
            }

            nextBtn.addEventListener('click', () => {
                const currentIndex = getCurrentChapterIndex();
                const nextIndex = currentIndex + 1;
                if (nextIndex < chapters.length) {
                    audio.currentTime = chapters[nextIndex];
                } else {
                    audio.currentTime = audio.duration || chapters[chapters.length - 1];
                }
            });

            prevBtn.addEventListener('click', () => {
                const currentTime = audio.currentTime;
                const currentIndex = getCurrentChapterIndex();
                if (currentTime - chapters[currentIndex] < 1.5 && currentIndex > 0) {
                    audio.currentTime = chapters[currentIndex - 1];
                } else {
                    audio.currentTime = chapters[currentIndex];
                }
            });
        })();
    </script>
EOM;
} function rf_make_step_chapters($maxsec,$step) { $chapters = []; $sec = 0; while ($sec < $maxsec) { $chapters[] = $sec; $sec += $step; } $chapters[] = $maxsec; return $chapters; } ?>
