<?php
 $product_name = "rfriends"; $rf_display_errors = 1; $rf_error_reporting = E_ALL; $rf_log_errors = 1; $link_flg = 1; $ds_retry_max = 10; $ds_debug = 0; $rf_textarea_width = 80; $rf_textarea_height = 20; $ext_const1 = "radiko"; $prog_retry = 5; $prog_wait = 10; $radiko_prog_retry = 5; $radiko_prog_wait = 2; $radiko_timeofbegin = 5; $prog_ext_mode = "rec"; $prog_ext_type = "with"; $radiko_today_disp_offset = 0; $radiko_today_disp_dur = 24 * 60 * 60; $auth_life_time = 3600; $auth_life_time2 = 3600; $auth_life_time3 = 3600; $radiko_delay_max = 110; $ext_const2 = "radiru"; $radiru_prog_retry = 5; $radiru_prog_wait = 2; $radiru_timeofbegin = 5; $radiru_today_disp_offset = 0; $radiru_today_disp_dur = 24 * 60 * 60; $radiru_delay_max = 70; $tout_rate = 4; $tout_allow = 120; $timefree_pre_margin = 0; $timefree_post_margin = 0; $timefree_wait = 5; $radiru_vod_wait = 5; $premium_lifetime = 4; $ext_const0 = "common"; $strip_tags_flag = 1; $strip_space_flag = 1; $stripos_flag = 1; $infotext_flag = 1; $add_tag = 1; $add_img = 1; $add_img_app_win = "AtomicParsley"; $add_img_app_osx = "AtomicParsley"; $add_img_app_lnx = "AtomicParsley"; $sort_flag = 1; $del_log = 1; $ok_head = ""; $ng_head = "_ng"; $tf_footer = ""; $convert_kana = 1; $convert_kana_para ="as"; $rec_sleep_pgm = "rfriends_rec_sleep.php"; $rec_pgm = "rfriends_rec.php"; $rec_fin_pgm = "rfriends_rec_fin.php"; $s_mkoffs = $standby_time*60 + 70; $s_mkdur = 3600*2; $standby_time_flu = 2; $f_rmargin = 1*60; $t_rmargin = 2*60; $log = 0; $debug = 1; $space_min = 50; $tmp_space_min = 50; $ex_limit = 5; $rsv_max = 800; $rsv_max_timefree = 1000; $radiko_delay = 0; $radiko_pre_margin = 0; $radiko_post_margin = 50; $radiru_delay = 0; $radiru_pre_margin = 0; $radiru_post_margin = 50; $premium_delay = 0; $premium_pre_margin = 0; $premium_post_margin = 100; $sec_name = array( 'unknown', 'common', 'timefree', 'radiko', 'radiko_timerec', 'radiru', 'radiru_vod', 'radiru_gogaku', 'common_ng', 'timefree_ng', 'radiko_ng', 'radiru_ng', 'radiru_vod_ng', 'radiru_gogaku_ng', 'radiru_main_station', 'radiru_station', 'radiru_timerec', 'radiru_other_timerec', 'radiru_tokyo', 'radiru_sendai', 'radiru_nagoya', 'radiru_osaka', 'radiru_sapporo', 'radiru_hiroshima', 'radiru_matsuyama', 'radiru_fukuoka', 'premium_main_station', 'premium_station', 'double_program_radiko', 'double_program_radiru', 'double_program_timefree', 'double_program_radiru_vod', 'double_program_radiru_gogaku', 'target_program', 'exception_program', 'radiko_delay_sw', 'radiru_delay_sw', 'default_delay', 'radiko_delay', 'radiru_delay', 'premium_delay', 'webradio_timerec' ); $update_dat_url = "https://raw.githubusercontent.com/rfriends/rfriends/main/"; $update_inf_url = "https://raw.githubusercontent.com/rfriends/rfriends/main/update3/inf.txt"; $auth_sleep = 15; $auth_retry = 5; $auth_type = 0; $msg_level = 1; $dlmt = ";"; $end_log = 0; $dontsleep_timer = 30; $dontsleep_timer_tf = 10; $fin_sleep = 5; $sch_life_time = 3600; $cfg_life_time = 3600; $cleanlog_fn = "rfriends_cleanlog"; $cleanlog_time = 3600 * 8; $rec_extension = "m4a"; $dwn_extension = "m4a"; $prohibit_mp3 = 0; $multi_sw = 1; $macos_launch_type = 0; $linux_systemd_type = 0; $linux_systemd_user = 0; $rec_normal_end = 0; $rec_already_exist = 1; $rec_not_deliver = 2; $rec_abnormal_end = 3; $rec_normal_end_plus = 11; $loghead_short = "[SHT]"; $loghead_bad = "[BAD]"; $loghead_cancel = "[CAN]"; $loghead_delay = "[DLY]"; $loghead_abnormal = "[ABN]"; $loghead_skip = "[SKP]"; $loghead_error = "[ERR]"; $pod_apple = '[APL]'; $pod_lfr = '[LFR]'; $pod_nhk = '[NHK]'; $pod_jfn = '[JFN]'; $pod_radiko = '[RDK]'; $hls_type = 0; $radiko_user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"; $radiko_host = "radiko.jp"; $radiko_base_img = "https://radiko.jp/res/program/DEFAULT_IMAGE/"; $prog_url = "https://radiko.jp/v3/program/date/"; $radiko_prog_url = "https://radiko.jp/v3/program/date/"; $radiko_prog_url4 = "https://api.radiko.jp/program/v4/date/"; $radiko_annex_prog_url = "https://api.annex-cf.radiko.jp/v1/programs/"; $radiko_annex_pod_url = "https://api.annex-cf.radiko.jp/v1/podcasts/episodes/"; $radiko_annex_prog_list = "list?broadcastDate=%s&lastStartAt=%s&limit=1&stationId=%s"; $playlisturl = "https://radiko.jp/v2/api/ts/playlist.m3u8"; $playlisturl2 = "https://tf-f-rpaa-radiko.smartstream.ne.jp/tf/playlist.m3u8"; $playlisturl3 = "https://tf-c-rpaa-radiko.smartstream.ne.jp/tf/playlist.m3u8"; $playerurl = "https://radiko.jp/apps/js/flash/myplayer-release.swf"; $m3u8header = " -q " . "--header=\"pragma: no-cache\" " . "--header=\"Content-Type: application/x-www-form-urlencoded\" " . "--header=\"Referer: $playerurl\" " . "--no-check-certificate " . "--post-data='flash=1' "; $c_livestreamurl = "https://c-radiko.smartstream.ne.jp/%s/_definst_/simul-stream.stream/playlist.m3u8"; $f_livestreamurl = "https://f-radiko.smartstream.ne.jp/%s/_definst_/simul-stream.stream/playlist.m3u8"; $streamurlhls2 = "https://radiko.jp/v2/station/stream_smh_multi/"; $fms1urlhls = "https://radiko.jp/v2/api/auth1"; $fms2urlhls = "https://radiko.jp/v2/api/auth2"; $streamurlhls3 = "https://radiko.jp/v3/station/stream/pc_html5/"; $hls_sw_0 = 2; $hls_no_0 = 1; $hls_ty_0 = 0; $hls_sw_1 = 2; $hls_no_1 = 1; $hls_ty_1 = 0; $playercommon = "https://radiko.jp/apps/js/playerCommon.js"; $playercommon_const = 'bcd151073c03b352e1ef2fd66c32209da9ca0afa'; $xheader = "X-Radiko"; $header1hls = "-q  " . "--header=\"pragma: no-cache\" " . "--header=\"X-Radiko-App: pc_html5\" " . "--header=\"X-Radiko-App-Version: 0.0.1\" " . "--header=\"X-Radiko-User: dummy_user\" " . "--header=\"X-Radiko-Device: pc\" " . "--no-check-certificate " . "--save-headers "; $header2hls = "-q " . "--header=\"pragma: no-cache\" " . "--header=\"X-Radiko-App: pc_html5\" " . "--header=\"X-Radiko-App-Version: 0.0.1\" " . "--header=\"X-Radiko-User: dummy_user\" " . "--header=\"X-Radiko-Device: pc\" " . "--header=\"X-Radiko-AuthToken: %s\" " . "--header=\"X-Radiko-PartialKey: %s\" " . "--no-check-certificate "; $header1hlsx = "-q  " . "--header=\"pragma: no-cache\" " . "--header=\"X-Radiko-App: %s\" " . "--header=\"X-Radiko-App-Version: %s\" " . "--header=\"X-Radiko-User: %s\" " . "--header=\"X-Radiko-Device: %s\" " . "--no-check-certificate " . "--save-headers "; $header2hlsx = "-q " . "--header=\"pragma: no-cache\" " . "--header=\"X-Radiko-App: %s\" " . "--header=\"X-Radiko-App-Version: %s\" " . "--header=\"X-Radiko-User: %s\" " . "--header=\"X-Radiko-Device: %s\" " . "--header=\"X-Radiko-AuthToken: %s\" " . "--header=\"X-Radiko-PartialKey: %s\" " . "--no-check-certificate "; $header1hlsg = "-q " . "--header=\"pragma: no-cache\" " . "--header=\"X-Radiko-App: %s\" " . "--header=\"X-Radiko-App-Version: %s\" " . "--header=\"X-Radiko-User: %s\" " . "--header=\"X-Radiko-Device: %s\" " . "--no-check-certificate " . "--save-headers "; $header2hlsg = "-q " . "--header=\"pragma: no-cache\" " . "--header=\"X-Radiko-App: %s\" " . "--header=\"X-Radiko-App-Version: %s\" " . "--header=\"X-Radiko-User: %s\" " . "--header=\"X-Radiko-Device: %s\" " . "--header=\"X-Radiko-Connection: %s\" " . "--header=\"X-Radiko-AuthToken: %s\" " . "--header=\"X-Radiko-Location: %s\" " . "--header=\"X-Radiko-PartialKey: %s\" " . "--no-check-certificate " . "--save-headers "; $login_url = "https://radiko.jp/v4/api/member/login"; $logout_url = "https://radiko.jp/v4/api/member/logout"; $logincheck_url = "https://radiko.jp/ap/member/webapi/member/login/check"; $opt_login = "-q " . " --keep-session-cookies"; $opt_logout = "-q " . " --header=\"pragma: no-cache\"" . " --header=\"Cache-Control: no-cache\"" . " --header=\"Expires: Thu, 01 Jan 1970 00:00:00 GMT\"" . " --header=\"Accept-Language: ja-jp\"" . " --header=\"Accept-Encoding: gzip, deflate\"" . " --header=\"Accept: application/json, text/javascript, */*; q=0.01\"" . " --header=\"X-Requested-With: XMLHttpRequest\"" . " --no-check-certificate"; $opt_logincheck = "-q " . " --no-check-certificate"; $radiko_nhk = array("JOAK","JOAB","JOAK-FM","JOHK","JOCK","JOBK","JOIK","JOFK","JOZK","JOLK"); $radiko_nhk_r1 = array("JOAK","JOHK","JOCK","JOBK","JOIK","JOFK","JOZK","JOLK"); $radiko_nhk_fm = "JOAK-FM"; $radiko_altch = array( "JP08" => "TBS,QRR,LFR,INT,FMT,FMJ,JORF,BAYFM78,NACK5,YFM,IBS", "JP09" => "TBS,QRR,LFR,INT,FMT,FMJ,JORF,BAYFM78,NACK5,YFM,IBS", "JP10" => "TBS,QRR,LFR,INT,FMT,FMJ,JORF,BAYFM78,NACK5,YFM,IBS", "JP11" => "TBS,QRR,LFR,INT,FMT,FMJ,JORF,BAYFM78,NACK5,YFM,IBS", "JP12" => "TBS,QRR,LFR,INT,FMT,FMJ,JORF,BAYFM78,NACK5,YFM,IBS", "JP13" => "TBS,QRR,LFR,INT,FMT,FMJ,JORF,BAYFM78,NACK5,YFM,IBS", "JP14" => "TBS,QRR,LFR,INT,FMT,FMJ,JORF,BAYFM78,NACK5,YFM,IBS", "JP23" => "CBC,TOKAIRADIO,GBS,ZIP-FM,FMAICHI", "JP21" => "CBC,TOKAIRADIO,GBS,ZIP-FM,FMAICHI", "JP24" => "CBC,TOKAIRADIO,GBS,ZIP-FM,FMAICHI", "JP27" => "ABC,MBS,OBC,CCL,802,FMO,KISSFMKOBE,CRK,KBS,ALPHA-STATION", "JP28" => "ABC,MBS,OBC,CCL,802,FMO,KISSFMKOBE,CRK", "JP26" => "ABC,MBS,OBC,CCL,802,FMO,KISSFMKOBE,CRK,KBS,ALPHA-STATION", "JP25" => "ABC,MBS,OBC,CCL,802,FMO,KISSFMKOBE,CRK,KBS,ALPHA-STATION", "JP29" => "ABC,MBS,OBC,CCL,802,FMO,KISSFMKOBE,CRK,ALPHA-STATION", "JP30" => "ABC,MBS,OBC,CCL,802,FMO,KISSFMKOBE,CRK" ); $radiru_host = "nhk.or.jp"; $radiru_callsign_r1 = array( "tokyo" => "JOAK", "sendai" => "JOHK", "nagoya" => "JOCK", "osaka" => "JOBK", "sapporo" => "JOIK", "hiroshima" => "JOFK", "matsuyama" => "JOZK", "fukuoka" => "JOLK" ); $radiru_callsign_r2 = "JOAB"; $radiru_callsign_fm = "-FM"; $radiru_region = array( "tokyo", "sendai", "nagoya", "osaka", "sapporo", "hiroshima", "matsuyama", "fukuoka" ); $radiru_r1 = "r1"; $radiru_r2 = "r2"; $radiru_r3 = "r3"; $radiru_fm = "fm"; $radiru_ch = array($radiru_r1,$radiru_r3); $radiru_ch_2 = array($radiru_r1,$radiru_r3); $radiru_base_img = "https://www.nhk.or.jp/prog/img/"; $station_logo_url = 'https://radiko.jp/v2/static/station/logo/%1$s/224x100.png'; $radiru_prog_url = "https://www.nhk.or.jp/hensei/api/sche.cgi?c=4&mode=xml"; $radiru_prog_url_json = 'https://api.nhk.jp/r7/pg/date/%2$s/%1$s/%3$s.json'; $radiru_now_url_json = "https://api.nhk.or.jp/r5/pg2/now/4/"; $radiru_configurl = "https://www.nhk.or.jp/radio/config/config_web.xml"; $radiru_vod_url = "https://www.nhk.or.jp/radio-api/app/v1/web/ondemand/corners/new_arrivals"; $radiru_vod_url_datelist = "https://www.nhk.or.jp/radio-api/app/v1/web/ondemand/corners/onair_dates"; $radiru_vod_url_date = "https://www.nhk.or.jp/radio-api/app/v1/web/ondemand/corners?onair_date="; $radiru_vod_url_series = "https://www.nhk.or.jp/radio-api/app/v1/web/ondemand/series?"; $radiru_gogaku_url = "https://www.nhk.jp/g/gogaku/"; $radiru_gogaku_url_s = "https://www.nhk.jp"; $nict_url = "https://ntp-a1.nict.go.jp/cgi-bin/json"; $crontab_template = array( "# rfriends crontab template (2025/12/30)".PHP_EOL, "#".PHP_EOL, "#SHELL=/bin/sh".PHP_EOL, "#PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin".PHP_EOL, "BASE_DIR=$base0".PHP_EOL, "# m h  dom mon dow   command".PHP_EOL, "#".PHP_EOL, ); $launchdir = $homedir."/Library/LaunchAgents/"; $launchuser = ""; $launch_at_head = "local.rfriends.at"; $launch_crontab_head = "local.rfriends.crontab"; $launch_crontab_template = <<<EOF1
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "https://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>%s</string>
    <key>StartCalendarInterval</key>
    <dict>
    <key>Hour</key>
    <integer>%s</integer>
    <key>Minute</key>
    <integer>%s</integer>
    </dict>
    <key>KeepAlive</key>
        <false/>
    <key>ProgramArguments</key>
    <array>
        <string>/bin/sh</string>
        <string>%s</string>
    </array>
EOF1;
if ($macos_debug > 0) { $launch_crontab_template .= <<<EOF2
    <key>StandardOutPath</key>
        <string>/tmp/rfriends3_stdout.log</string>
    <key>StandardErrorPath</key>
        <string>/tmp/rfriends3_stderr.log</string>
EOF2;
} if ($macos_debug > 1) { $launch_crontab_template .= <<<EOF3
    <key>Debug</key>
        <true/>
EOF3;
} $launch_crontab_template .= <<<EOF4
</dict>
</plist>
EOF4;
$launch_crontab_template2 = <<<EOF1
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "https://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>%s</string>
    <key>StartCalendarInterval</key>
    <array>
    <dict>
    <key>Hour</key>
    <integer>%s</integer>
    <key>Minute</key>
    <integer>%s</integer>
    </dict>
    <dict>
    <key>Hour</key>
    <integer>%s</integer>
    <key>Minute</key>
    <integer>%s</integer>
    </dict>
    </array>
    <key>KeepAlive</key>
        <false/>
    <key>ProgramArguments</key>
    <array>
        <string>/bin/bash</string>
        <string>%s</string>
    </array>
EOF1;
if ($macos_debug > 0) { $launch_crontab_template2 .= <<<EOF2
    <key>StandardOutPath</key>
        <string>/tmp/rfriends3_stdout.log</string>
    <key>StandardErrorPath</key>
        <string>/tmp/rfriends3_stderr.log</string>
EOF2;
} if ($macos_debug > 1) { $launch_crontab_template .= <<<EOF3
    <key>Debug</key>
        <true/>
EOF3;
} $launch_crontab_template2 .= <<<EOF4
</dict>
</plist>
EOF4;
$launch_at_template = <<<EOF1
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "https://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>%s</string>
    <key>StartCalendarInterval</key>
    <dict>
    <key>Month</key>
    <integer>%s</integer>
    <key>Day</key>
    <integer>%s</integer>
    <key>Hour</key>
    <integer>%s</integer>
    <key>Minute</key>
    <integer>%s</integer>
    </dict>
    <key>KeepAlive</key>
        <false/>
    <key>LaunchOnlyOnce</key>
        <true/>
    <key>ProgramArguments</key>
    <array>
        <string>%s</string>
        <string>%s</string>
        <string>%s</string>
        <string>%s</string>
    </array>
EOF1;
if ($macos_debug > 0) { $launch_at_template .= <<<EOF2
    <key>StandardOutPath</key>
        <string>/tmp/rfriends3_stdout.log</string>
    <key>StandardErrorPath</key>
        <string>/tmp/rfriends3_stderr.log</string>
EOF2;
} if ($macos_debug > 1) { $launch_crontab_template .= <<<EOF3
    <key>Debug</key>
        <true/>
EOF3;
} $launch_at_template .= <<<EOF4
</dict>
</plist>
EOF4;
$systemd_crontab_template = <<<EOF
[Unit]
Description=rfriends crontab service
After=network-online.target
[Service]
ExecStart=%s
[Install]
WantedBy=multi-user.target

EOF;
$systemd_crontab_template_top_timer = <<<EOF
[Unit]
Description=rfriends crontab timer
[Timer]
EOF;
$systemd_crontab_template_btm_timer = <<<EOF
Persistent=false     
[Install]
WantedBy=timers.target

EOF;
$systemd_oncalendar_template = "OnCalendar=*-*-* %s:%s:00"; $systemd_oncalendar_template_free = "OnCalendar=%s"; $systemd_at_service_template = <<<EOF
[Unit]
Description=rfriends at command service
After=network-online.target
[Service]
ExecStart=/bin/bash -c "%s"
[Install]
WantedBy=multi-user.target

EOF;
$systemd_at_timer_template = <<<EOF
[Unit]
Description=rfriends at command timer
[Timer]
OnCalendar=%s-%s-%s %s:%s:00
[Install]
WantedBy=timers.target

EOF;
$pid_dlm_win = ","; $pid_start_win = "Node"; $pid_cline_win = "CommandLine"; $pid_pid_win = "ProcessId"; $pid_cdate_win = "CreationDate"; $ps_pid_start_win = "Name"; $ps_pid_cline_win = "CommandLine"; $ps_pid_pid_win = "ProcessID"; $ps_pid_cdate_win = "CreationDate"; $pid_ex_linux = "ps -ef"; $pid_dlm_linux = " "; $pid_start_linux = "UID"; $pid_cline_linux = "CMD"; $pid_pid_linux = "PID"; $pid_cdate_linux = "STIME"; $pref_code = array( 1 => "北海道", 2 => "青森県", 3 => "岩手県", 4 => "宮城県", 5 => "秋田県", 6 => "山形県", 7 => "福島県", 8 => "茨城県", 9 => "栃木県", 10 => "群馬県", 11 => "埼玉県", 12 => "千葉県", 13 => "東京都", 14 => "神奈川県", 15 => "新潟県", 16 => "富山県", 17 => "石川県", 18 => "福井県", 19 => "山梨県", 20 => "長野県", 21 => "岐阜県", 22 => "静岡県", 23 => "愛知県", 24 => "三重県", 25 => "滋賀県", 26 => "京都府", 27 => "大阪府", 28 => "兵庫県", 29 => "奈良県", 30 => "和歌山県", 31 => "鳥取県", 32 => "島根県", 33 => "岡山県", 34 => "広島県", 35 => "山口県", 36 => "徳島県", 37 => "香川県", 38 => "愛媛県", 39 => "高知県", 40 => "福岡県", 41 => "佐賀県", 42 => "長崎県", 43 => "熊本県", 44 => "大分県", 45 => "宮崎県", 46 => "鹿児島県", 47 => "沖縄県"); $pref_url = "https://mreversegeocoder.gsi.go.jp/reverse-geocoder/LonLatToAddress"; $pref_url2 = "https://nominatim.openstreetmap.org/reverse"; $gdrive_url = "https://github.com/glotlabs/gdrive/releases/download/3.9.1/"; $line_url = "https://notify-api.line.me/api/notify"; $line_auth = "--header \"Authorization: Bearer $send_mail_line_token\""; $ffmpeg_buf_radiko = 0; $ffmpeg_buf_radiru = 0; $ffmpeg_buf_timefree = 0; $ffmpeg_buf_radiru_vod = 0; $ffmpeg_buf_radiru_gogaku = 0; $ffmpeg_buf_webradio = 0; $ffmpeg_loglevel = "info"; $ffmpeg_loglevel_timefree = "fatal"; $ffmpeg_tag_opt = "-loglevel error -movflags +faststart  -acodec copy -vcodec copy  -id3v2_version 3 "; $http_seekable = "-http_seekable 0"; $ffmpeg_re = "-re"; $ffmpeg_useropt_tf30 = " -nostdin"; $ffmpeg_useropt = " -reconnect 1  -reconnect_streamed 1 -reconnect_delay_max 120 -nostdin"; $whitelist = "-protocol_whitelist tcp,tls,https,file,crypto,data"; $whitelist2 = "-protocol_whitelist https"; $ffplay_useropt = " -nodisp -autoexit -loglevel warning"; $ffplay_analize = "-probesize 20M -analyzeduration 10M"; $ffplay_nodelay = "-max_delay 0 -max_probe_packets 1 -analyzeduration 0 -flags +low_delay -fflags +nobuffer"; $discardcorrupt = "-fflags +discardcorrupt"; $ffmpeg_radiko_opt_win = " $http_seekable" . " $ffmpeg_re" . " $discardcorrupt" . ' -headers "X-Radiko-AuthToken:%4$s"' . ' -vn' . ' -i "%1$s"' . ' -t %3$s' . ' -movflags +faststart' . ' -metadata encoder="radiko" ' . ' -bsf:a aac_adtstoasc' . ' -acodec copy' . ' -y'; $ffmpeg_radiru_opt_win = " $http_seekable" . " $ffmpeg_re" . " $discardcorrupt" . ' -vn' . ' -i "%1$s"' . ' -t %3$s' . ' -movflags +faststart' . ' -metadata encoder="radiru" ' . ' -bsf:a aac_adtstoasc' . ' -acodec copy' . ' -y'; $ffmpeg_radiru_vod_opt_win = " $http_seekable" . " $discardcorrupt" . ' -vn' . ' -i "%1$s"' . ' -movflags +faststart' . ' -metadata encoder="radiru_vod" ' . ' -bsf:a aac_adtstoasc' . ' -acodec copy' . ' -y'; $ffmpeg_radiru_gogaku_opt_win = " $http_seekable" . " $discardcorrupt" . ' -vn' . ' -i "%1$s"' . ' -movflags +faststart' . ' -metadata encoder="radiru_vod" ' . ' -bsf:a aac_adtstoasc' . ' -acodec copy' . ' -y'; $ffmpeg_timefree_opt_win = ' -headers "X-Radiko-AuthToken:%4$s"' . " $discardcorrupt" . ' -vn' . ' -i "%1$s"' . ' -t %3$s' . ' -movflags +faststart' . ' -metadata encoder="timefree" ' . ' -bsf:a aac_adtstoasc' . ' -acodec copy' . ' -y'; $ffmpeg_timefree_opt_win_tf30 = " $whitelist" . " $discardcorrupt" . ' -vn' . ' -i "%1$s"' . ' -t %3$s' . ' -movflags +faststart' . ' -metadata encoder="timefree" ' . ' -bsf:a aac_adtstoasc' . ' -acodec copy' . ' -y'; $ffmpeg_webradio_opt_win = ' -headers "Origin:%4$s"' . " $discardcorrupt" . ' -vn' . ' -i "%1$s"' . ' -t %3$s' . ' -movflags +faststart' . ' -metadata encoder="webradio" ' . ' -bsf:a aac_adtstoasc' . ' -acodec copy' . ' -y'; $ffmpeg_jcba_opt_win = ' -i pipe:0' . ' -t %3$s' . ' -movflags +faststart' . ' -metadata encoder="webradio" ' . ' -c:a aac -b:a 96k'; $ffmpeg_radiko_opt_lnx = " $http_seekable" . " $ffmpeg_re" . " $discardcorrupt" . ' -headers "X-Radiko-AuthToken:%4$s"' . ' -vn' . ' -i "%1$s"' . ' -t %3$s' . ' -movflags +faststart' . ' -metadata encoder="radiko" ' . ' -bsf:a aac_adtstoasc' . ' -acodec copy' . ' -y'; $ffmpeg_radiko_opt_lnx_a = " $http_seekable" . " $ffmpeg_re" . " $discardcorrupt" . ' -vn' . ' -i "%1$s"' . ' -t %3$s' . ' -movflags +faststart' . ' -metadata encoder="radiko" ' . ' -bsf:a aac_adtstoasc' . ' -acodec copy' . ' -y'; $ffmpeg_radiru_opt_lnx = " $http_seekable" . " $ffmpeg_re" . " $discardcorrupt" . ' -vn' . ' -i "%1$s"' . ' -t %3$s' . ' -movflags +faststart' . ' -metadata encoder="radiru" ' . ' -bsf:a aac_adtstoasc' . ' -acodec copy' . ' -y'; $ffmpeg_radiru_vod_opt_lnx = " $http_seekable" . " $discardcorrupt" . ' -vn' . ' -i "%1$s"' . ' -movflags +faststart' . ' -metadata encoder="radiru_vod" ' . ' -bsf:a aac_adtstoasc' . ' -acodec copy' . ' -y'; $ffmpeg_radiru_gogaku_opt_lnx = " $http_seekable" . " $discardcorrupt" . ' -vn' . ' -i "%1$s"' . ' -movflags +faststart' . ' -metadata encoder="radiru_vod" ' . ' -bsf:a aac_adtstoasc' . ' -acodec copy' . ' -y'; $ffmpeg_timefree_opt_lnx = ' -headers "X-Radiko-AuthToken:%4$s"' . " $discardcorrupt" . ' -vn' . ' -i "%1$s"' . ' -t %3$s' . ' -movflags +faststart' . ' -metadata encoder="timefree" ' . ' -bsf:a aac_adtstoasc' . ' -acodec copy' . ' -y'; $ffmpeg_timefree_opt_lnx_tf30 = " $whitelist" . " $discardcorrupt" . ' -vn' . ' -i "%1$s"' . ' -t %3$s' . ' -movflags +faststart' . ' -metadata encoder="timefree" ' . ' -bsf:a aac_adtstoasc' . ' -acodec copy' . ' -y'; $ffmpeg_webradio_opt_lnx = ' -headers "Origin:%4$s"' . " $discardcorrupt" . ' -vn' . ' -i "%1$s"' . ' -t %3$s' . ' -movflags +faststart' . ' -metadata encoder="webradio" ' . ' -bsf:a aac_adtstoasc' . ' -acodec copy' . ' -y'; $ffmpeg_jcba_opt_lnx = ' -i pipe:0' . ' -t %3$s' . ' -movflags +faststart' . ' -metadata encoder="webradio" ' . ' -c:a aac -b:a 96k'; $default_editor_cui_win = $bindir.'nano'; $default_editor_gui_win = $bindir.'terapad'; $default_snd_player_win = 'wmplayer'; $default_editor_cui_osx = 'nano'; $default_editor_gui_osx = 'TextEdit.app'; $default_snd_player_osx = 'quicktime player.app'; $default_editor_cui_lnx = 'nano'; $default_editor_gui_lnx = 'gedit'; $default_snd_player_lnx = 'totem'; $default_headless_browser_win_app = 'chrome.exe'; $default_headless_browser_osx_app = 'chromium'; $default_headless_browser_lnx_app = 'chromium-browser'; $default_headless_browser_lnx_app2 = 'chromium'; $default_headless_browser_win_opt = '--headless' . ' --no-sandbox --disable-gpu --disable-software-rasterizer --disable-dev-shm-usage' . ' --disable-extensions --window-size=640,480' . ' --dump-dom --virtual-time-budget=10000'; $default_headless_browser_osx_opt = '--headless' . ' --no-sandbox --disable-gpu --disable-software-rasterizer --disable-dev-shm-usage' . ' --disable-extensions --window-size=640,480' . ' --dump-dom --virtual-time-budget=10000'; $default_headless_browser_lnx_opt = '--headless' . ' --no-sandbox --disable-gpu --disable-software-rasterizer --disable-dev-shm-usage' . ' --disable-extensions --window-size=640,480' . ' --dump-dom --virtual-time-budget=10000'; $debug_fin = 0; 