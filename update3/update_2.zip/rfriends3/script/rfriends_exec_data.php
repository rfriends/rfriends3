<?php
 require_once("rf_inc.php"); require_once("html/ht_sub2.php"); $rfriends_mes = "ラジオ録音ツール"; $dir = $scrdir; echo_msg(2,"tmpdir : $dir"); $ret = ht_update_station($dir); if ($ret != 0) { echo_msg(2,"局データ更新に失敗しました。"); } else { echo_msg(2,"局データを更新しました。"); } exit; ?>
