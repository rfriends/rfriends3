@echo off
rem
rem rfriends (radiko radiru�^���c�[��)
rem
set scrdir=%~dp0
set base=%scrdir%..\
set php=%base%bin\php\php.exe
rem ------------------------------------ exec
set ex=rfriends_exec
set exno=10
set opt="10,2,-1,3,"
set exnam="radiru_gogaku"

echo %ex% %exno% %opt% Executing...
%php% %scrdir%%ex%.php %exno% %opt% %exnam%
rem pause
exit
