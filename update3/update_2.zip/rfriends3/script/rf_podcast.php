<?php
 function rf_podcast_user($pgm,$nmax) { global $cfgdir; global $scrdir; global $podcastdat; global $google_podcastsdat; global $podcast_days; $title = $pgm['title']; $tag = $pgm['tag']; $sdir = $pgm['dir']; $home = $pgm['home']; $page = $pgm['page']; $status = $pgm['status']; $pcastfile = $cfgdir.$podcastdat; $ans = rf_pcast_get_preset($pcastfile,1); if ($ans == array()) return false; $program_list = array(); $cnt = count_73($ans); if ($cnt > 1) { $lmt = rf_ndays_ago(8); $wdat = rf_pcast_user_auto($ans,$sdir,$nmax,$lmt,0); if ($wdat === false) return true; $en = count_73($wdat); if ($en == 0) { echo_msg(2, "エピソードがありません"); rf_pause(); return true; } echo_msg(2, ""); echo_msg(2, "エピソード（最新１週間分） : $en"); echo_msg(2, ""); $ans2 = echo_yesno(2,"ダウンロードを実行しますか？(y/N) "); if ($ans2 != "y" && $ans2 != "Y" ) { return true; } echo_msg(2, ""); $opt_fn = make_fn("podcast"); rf_put_wdat_all_tmpdir($opt_fn, $wdat); $nam = "rfriends_exec_podcast"; $opt = "12 \"$opt_fn\" "; $ex = "ex_rfriends"; rfgw_batsh_sub($scrdir, $ex, $opt, 1, 1); echo_msg(2, ""); echo_msg(2, "ダウンロード処理を開始しました"); echo_msg(2, "処理はバックグラウンドで行われます"); rf_pause(); return true; } $pub = $ans[0]['pub']; $kw = $ans[0]['kw']; $rss = $ans[0]['rss']; $ttl = $ans[0]['title']; if ($rss != "") { $program_list = rf_pcast_get_rss($rss,"",$ttl); } else { if ($kw == "" && $pub == "") { return false; } $lists = rf_pcast_get_google($home,$page,$pub,$kw); if ($lists === false) return false; $lang = ""; $program_list = rf_pcast_get_rss_list($lists,$lang); } if ($program_list === false) { echo_msg(2,"エピソードがありません。"); rf_pause(); return true; } $ret = rf_pcast_user($pgm,$program_list,$nmax,0,0); return true; } function rf_podcast_google_preset($pgm,$nmax) { global $cfgdir; global $scrdir; global $podcastdat; global $google_podcastsdat; $title = $pgm['title']; $tag = $pgm['tag']; $dir = $pgm['dir']; $home = $pgm['home']; $page = $pgm['page']; $status = $pgm['status']; $pcastfile= $scrdir.$google_podcastsdat; $ans = rf_pcast_get_preset($pcastfile,0); if ($ans == array()) return false; $pub = $ans[0]['pub']; $kw = $ans[0]['kw']; $rss = $ans[0]['rss']; if ($rss != "") { $lists = array(); $lists[] = $rss; } else { if ($kw == "" && $pub == "") { return false; } $lists = rf_pcast_get_google($home,$page,$pub,$kw); if ($lists === false) return false; } $lang = ""; $program_list = rf_pcast_get_rss_list($lists,$lang); if ($program_list === false) return false; $ret = rf_pcast_user($pgm,$program_list,$nmax,0,0); return $ret; } function rf_podcast_google($pgm,$nmax) { global $cfgdir; global $scrdir; global $podcastdat; global $google_podcastsdat; $title = $pgm['title']; $tag = $pgm['tag']; $dir = $pgm['dir']; $home = $pgm['home']; $page = $pgm['page']; $status = $pgm['status']; $inp = echo_input(2, "キーワードを入力してください : "); $parts = explode(",",trim($inp),2); $n = count_73($parts); if ($n < 2) { $pub = ""; $kw = $inp; } else { $pub = trim($parts[0]); $kw = trim($parts[1]); } if ($kw == "" && $pub == "") { return false; } $lists = rf_pcast_get_google($home,$page,$pub,$kw); if ($lists === false) return false; $lang = ""; $program_list = rf_pcast_get_rss_list($lists,$lang); if ($program_list === false) return false; $ret = rf_pcast_user($pgm,$program_list,$nmax,0,0); return $ret; } function rf_podcast_apple_preset($pgm,$nmax) { global $scrdir; $pcastfile= $scrdir.'apple_podcasts.dat'; $ans = rf_pcast_get_preset($pcastfile,0); if ($ans == array()) return false; $inp = $ans[0]['pub']; $ret = rf_podcast_apple_kw($pgm,$nmax,$inp); return $ret; } function rf_podcast_apple($pgm,$nmax) { $inp = echo_input(2, "キーワードを入力してください : "); $ret = rf_podcast_apple_kw($pgm,$nmax,$inp); return $ret; } function rf_podcast_apple_kw($pgm,$nmax,$inp) { $kw = trim($inp); if ($kw == "") { echo_msg(2,"キーワードが空なので終了します。"); return false; } $lists = rf_applepodcasts_search($kw,$nmax); if ($lists === false) { echo_msg(2,"番組を取得できません。"); return false; } $cnt = count_73($lists); if ($cnt < 1) { echo_msg(2,"番組がヒットしませんでした。(kw : $kw)"); return false; } $lang = ""; $lists2 = array(); foreach($lists as $list) { $lists2[] = $list['val']; } $program_list = rf_pcast_get_rss_list($lists2,$lang); if ($program_list === false) return false; $pgm['title'] = "$kw"; $ret = rf_pcast_user($pgm,$program_list,$nmax,0,0); return $ret; } function rf_podcast_audee_list($pgm,$nmax) { global $cfgdir; global $scrdir; global $podcastdat; global $google_podcastsdat; $title = $pgm['title']; $tag = $pgm['tag']; $dir = $pgm['dir']; $home = $pgm['home']; $page = $pgm['page']; $status = $pgm['status']; $program_list = rf_pcast_get_audee_list($page); if ($program_list === false) return false; $pgm2 = rf_pcast_get_pgm($program_list,$pgm); if ($pgm2 === false) return false; if ($pgm2 == 0) return true; $ret = rf_pcast_audee($pgm2,$nmax,0,0,"audee"); return $ret; } function rf_podcast_audee_page($url) { $xmlObject = url2xml_ex($url); if ($xmlObject === false) { return 1; } $q1 = '//section[(@id = "content_tab_voice") and (contains(@class,"is-active"))]//ul[@class="box-pagination"]'; $q2 = '//section[(@id = "content_tab_all"  ) and (contains(@class,"is-active"))]//ul[@class="box-pagination"]'; $result = $xmlObject->xpath($q1); if ($result == null || $result === false) { $result = @$xmlObject->xpath($q2); if ($result == null || $result === false) { return 1; } } if (is_array($result)) { $pg = $result[0]->li; } else { $pg = $result->li; } $cnt = count_73($pg); if ($cnt < 2) { $nmax = 1; } else { $nmax = $pg[$cnt-2]->a; } return $nmax; } function rf_podcast_audee_voice_url($url) { $xmlObject = url2xml($url); if ($xmlObject === false) return false; $q1 = '//section[(@id = "content_tab_voice")]//div[@class="box-article-item"]/a'; $result = @$xmlObject->xpath($q1); if ($result == null || $result === false) { return false; } $cnt = count_73($result); if ($cnt < 1) return false; foreach($result as $val) { if (empty($val->attributes()->href)) continue; $href = (string)$val->attributes()->href; if (strpos($href,'voice') === false) continue; return $href; } return false; } function rf_podcast_audee_latest($url) { $lists = array(); $xmlObject = url2xml($url); if ($xmlObject === false) return $lists; $q1 = '//section[(@id = "content_tab_voice")]//div[@class="box-article-item"]/a'; $result = $xmlObject->xpath($q1); if ($result == null || $result === false) { return $lists; } $cnt = count_73($result); if ($cnt < 1) return $lists; foreach($result as $val) { if (empty($val->attributes()->href)) continue; $href = (string)$val->attributes()->href; if (strpos($href,'voice') === false) continue; $p = (string)$val->p; $p = utf8mac2utf8($p); $ch = (string)$val->img->attributes()->alt; $list = rf_pcast_get_audee_info($href); if ($list === false){ $dt = 0; } else { $dt = $list['date']; } $lists[] = array('title'=>$p,'val'=>$href,'ch'=>$ch,'date'=>$dt); break; } return $lists; } function rf_podcast_audee($pgm,$nmax) { global $cfgdir; global $scrdir; global $podcastdat; global $google_podcastsdat; $title = $pgm['title']; $tag = $pgm['tag']; $dir = $pgm['dir']; $home = $pgm['home']; $page = $pgm['page']; $status = $pgm['status']; $program_list = rf_pcast_get_audee_list($page); if ($program_list === false) return false; $pgm2 = rf_pcast_src_pgm($program_list); if ($pgm2 === false) return false; if ($pgm2 == 0) return true; $ret = rf_pcast_audee($pgm2,$nmax,0,0,"audee"); return $ret; } function rf_podcast_lfrradio($pgm,$nmax) { global $cfgdir; global $scrdir; global $podcastdat; global $google_podcastsdat; $title = $pgm['title']; $tag = $pgm['tag']; $dir = $pgm['dir']; $home = $pgm['home']; $page = $pgm['page']; $status = $pgm['status']; $brand = @$pgm['brand']; $flist = array(); foreach($brand as $br) { $url = $br['url']; $flist[] = array('title' => $br['title'], 'val' => "$url,$home", 'url' => $url); } $count = count_73($flist); $opt = array( "title" => "ジャンル一覧 ($count 件)", "input_type" => 0, "page_control" => 1, "page_size" => 11, "return_mes" => "戻る", "input_mes" => "ジャンルを選択してください", "mode" => 1, "multi" => 0, "confirm" => 0, "ht_selid" => "" ); $no = rf_pctl_disp($flist, $opt); $ans0 = $no[0]; if ($ans0 == "r") { return false; } echo_msg(2,$flist[$ans0-1]['title']); $url = $flist[$ans0-1]['url']; $lists = rf_pcast_get_lfr($url,$home); if ($lists === false) return false; $lang = ""; $program_list = rf_pcast_get_rss_list($lists,$lang); if ($program_list === false) return false; $ret = rf_pcast_user($pgm,$program_list,$nmax,0,0); return $ret; } function rf_podcast_jfn_maxpage($obj) { $q = '//a[@class="button-pagination-link"]'; $result = $obj->xpath($q); $n = count_73($result); $max = 1; if ($n > 0) $max = $result[$n - 1]; return $max; } function rf_podcast_jfn_lastepisode($obj) { $q = '//section/div/article/a'; $result = $obj->xpath($q); if (empty($result)) { return false; } $r = $result[0]; $ttl = (string)$r->div->h3; $tim = (string)$r->div->p; $ttl = $tim.' '.$ttl; $ttl = utf8mac2utf8(trim($ttl)); $q2 = '//section/div/article/a//img/@src'; $result2 = $obj->xpath($q2); if (empty($result2)) { $jpg = ''; } else { $jpg = (string)$result2[0]; } return [$ttl,$jpg]; } function rf_podcast_radiko_maxpage($obj) { $q = '//a[@class="button-pagination-link"]'; $result = $obj->xpath($q); $n = count_73($result); $max = 1; if ($n > 0) $max = $result[$n - 1]; return $max; } function rf_podcast_radiko_program($obj) { $home = "https://radiko.jp"; $lists = array(); $q = '//section[@id="program"]//a'; $result = $obj->xpath($q); $n = count_73($result); foreach($result as $r) { $href = $r->attributes()->href; $href = (string)$home.$href."/voice"; $ttl = (string)$r->div->h3; $ttl = utf8mac2utf8(trim($ttl)); $lists[] = array('title' => $ttl, 'val' => $href); } return $lists; } function rf_podcast_radiko_contents($obj) { $home = "https://radiko.jp"; $lists = array(); $q = '//section/div/article/a'; $result = $obj->xpath($q); $n = count_73($result); foreach($result as $r) { $href = $r->attributes()->href; $href = $home.$href; $ttl = (string)$r->div->h3; $ttl = utf8mac2utf8(trim($ttl)); $lists[] = array('title' => $ttl, 'val' => $href); } return $lists; } function rf_pcast_rss_detail($rss,$ty) { $ns = 'http://www.itunes.com/dtds/podcast-1.0.dtd'; $str = rf_file_get_contents($rss); if ($str === false) return false; $obj = rf_simplexml_load_string($str); if ($obj === false) return false; $items = $obj->channel->item; $lists = array(); if ($ty == 1) { $ttl = (string)$obj->channel->title; $desc = (string)$obj->channel->description; $image = (string)$obj->channel->image->url; if ($image == '') { $images = $obj->xpath('//itunes:image'); if (!empty($images)) { $image = (string)$images[0]['href']; } } $lists[] = array('title'=>"$ttl", 'img'=>$image, 'desc'=>$desc); } $itemno = 1; foreach($items as $item) { $ttl = (string)$item->title; $enc = $item->enclosure; $url = (string)$enc['url']; $pubDate = (string)$item->pubDate; if ($ty == 0) { $dt = date("Ymd",strtotime($pubDate)); $ttl = $dt." ".$ttl; $lists[] = array('title'=>"$ttl", 'val'=>"$itemno,$url"); } else if ($ty == 1){ $imgs = ""; $lists[] = array('title'=>"$ttl", 'val'=>"$itemno,$url", 'date'=>$pubDate, 'img'=>$imgs); } $itemno++; } return $lists; } function rf_pcast_rss_download($pgm,$program_list,$nmax,$art,$opt) { global $pcastdir; global $DS; $mtitle = $pgm['title']; $mname = fn_edit($mtitle); $mtag = $pgm['tag']; $sdir = $pgm['dir']; $home = $pgm['home']; $page = $pgm['page']; $program_list_n = count_73($program_list); $rpt = 1; while(1==1) { if ($rpt == 0) return false; if ($program_list_n == 1) { $sel = 0; $rpt = 0; } else { $sel = rf_pcast_user_select_program($program_list,$mname); if ($sel === false) { return false; } } $pgm = $program_list[$sel]; if ($pgm['ver'] == "audee") { $ret = rf_pcast_audee($pgm,$nmax,0,0,"user"); continue; } $pname = $pgm['title']; $pname2 = rf_stradjust($pname,$nmax); $dir = $pcastdir.$sdir.$DS.$pname2.$DS; $rss = $pgm['rss']; $flist = rf_pcast_user_get_program($pgm,$nmax,0); if ($flist === false) { return false; } $mp3_list = rf_pcast_select_episode($flist,$pname,$rss); if ($mp3_list === false) { continue; } $cnt = count_73($mp3_list); if ($cnt <= 0) { echo_msg(2, "リストが空です"); rf_pause(); continue; } foreach($mp3_list as $list) { $no = $list['no']; $title = $list['title']; echo_msg(2,"$no $title"); } echo_msg(2, ""); $ans2 = echo_yesno(2,"ダウンロードを実行しますか？(y/N) "); if ($ans2 != "y" && $ans2 != "Y" ) { continue; } rf_pcast_mp3_download($cnt,$dir,$sdir,$pname2,$mp3_list,$nmax,$art,$opt); rf_pause(); } return true; } function rf_pcast_user($pgm,$program_list,$nmax,$art,$opt) { global $pcastdir; global $DS; $mtitle = $pgm['title']; $mname = fn_edit($mtitle); $mtag = $pgm['tag']; $sdir = $pgm['dir']; $home = $pgm['home']; $page = $pgm['page']; $program_list_n = count_73($program_list); $rpt = 1; while(1==1) { if ($rpt == 0) return false; if ($program_list_n == 1) { $sel = 0; $rpt = 0; } else { $sel = rf_pcast_user_select_program($program_list,$mname); if ($sel === false) { return false; } } $pgm = $program_list[$sel]; if ($pgm['ver'] == "audee") { $ret = rf_pcast_audee($pgm,$nmax,0,0,"user"); continue; } $pname = $pgm['title']; $pname2 = rf_stradjust($pname,$nmax); $dir = $pcastdir.$sdir.$DS.$pname2.$DS; $rss = $pgm['rss']; $flist = rf_pcast_user_get_program($pgm,$nmax,0); if ($flist === false) { return false; } $mp3_list = rf_pcast_select_episode($flist,$pname,$rss); if ($mp3_list === false) { continue; } $cnt = count_73($mp3_list); if ($cnt <= 0) { echo_msg(2, "リストが空です"); rf_pause(); continue; } foreach($mp3_list as $list) { $no = $list['no']; $title = $list['title']; echo_msg(2,"$no $title"); } echo_msg(2, ""); $ans2 = echo_yesno(2,"ダウンロードを実行しますか？(y/N) "); if ($ans2 != "y" && $ans2 != "Y" ) { continue; } rf_pcast_mp3_download($cnt,$dir,$sdir,$pname2,$mp3_list,$nmax,$art,$opt); rf_pause(); } return true; } function rf_ndays_ago($n) { $n2 = strtotime("-$n day") - 60*60; $nd = date("Ymd",$n2); $n2 = strtotime($nd); return $n2; } function rf_get_json($url) { for($i=0;$i<5;$i++) { if (($json = rf_file_get_contents($url)) !== false) { return $json; } sleep(1); } return false; } function rf_pcast_user_auto($ans,$sdir,$nmax,$lmt,$dncnt) { global $pcastdir; global $DS; $lists = array(); $dnlist = array(); $wdat = array(); echo_msg(2,"処理中..."); $dir = $pcastdir.$sdir; @mkdir($pcastdir); @mkdir($dir); if (is_dir($dir) === false) { echo_msg(2,""); echo_msg(2, "make dir error : $dir"); return $wdat; } foreach($ans as $an) { $pub = $an['pub']; $kw = $an['kw']; $rss = $an['rss']; $ttl = $an['title']; if ($rss == "") continue; $plist = rf_pcast_get_rss($rss,"",$ttl); if ($plist === false) { echo_msg(2,"ERROR $ttl (フォーマットエラーです。)"); echo_msg(2,"  $rss"); continue; } $ver = $plist['ver']; if ($ver == 'audee') { echo_msg(2,"ERROR $ttl (現在、$ver はサービスが終了しています。)"); echo_msg(2,"  $rss"); } else { $lists[] = $plist; } } $pcnt = 0; foreach($lists as $plist) { $pname = $plist['title']; $pname2 = rf_stradjust($pname,$nmax); if ($plist['ver'] == "jfn") { $flist = rf_pcast_jfn_get_mp3($plist,$nmax,1); } else if ($plist['ver'] == "radiko") { $flist = rf_pcast_radiko_get_mp3($plist,$nmax,1); } else if ($plist['ver'] == "audee") { $program = trim($plist['pgm']); $url = trim($plist['href']); $lists = ad_get_episode($url,$program,1); $flist = ad_get_mp3_list2($lists,$nmax,1); } else { $flist = rf_pcast_user_get_program($plist,$nmax,1); } if ($flist === false) continue; $cnt = count_73($flist); if ($cnt <= 0) continue; for($i=0;$i<$cnt;$i++) { $dt = $flist[$i]['date']; $diff = $lmt - strtotime($dt); if ($i >= $dncnt && $diff > 0) break; $pcnt++; $flist[$i]['dir'] = $pname2; $dnlist[] = $flist[$i]; } } foreach($dnlist as $list) { $name = $list["name"]; $dt = $list["date"]; $mp3 = $list["mp3"]; $pdir = $list["dir"]; $img = $list["image"]; if ($img == "") $img = 0; $pdir = fn_utf8_mac($pdir); $mdir = $dir.$DS.$pdir.$DS; @mkdir("$mdir"); if (is_dir("$mdir") === false) { echo_msg(2, "make dir error : $mdir"); continue; } $album = $pdir; $wdat[] = rf_make_wdata($dt,';',';',';',';',';',';',$name,';',$img,';',$mp3,$mdir,';',';',$album,';',';',';'); } return $wdat; } function rf_pcast_audee($pgm,$nmax,$art,$opt,$sdir) { global $pcastdir; global $DS; $audee_program = trim($pgm['pgm']); $url = trim($pgm['href']); $audee_program2 = rf_stradjust($audee_program,$nmax); $dir = $pcastdir.$sdir.$DS.$audee_program2.$DS; $rss = ""; $flists = ad_get_episode($url,$audee_program,0); if ($flists === false) { echo_msg(2, "tagidがない、または選択エラーです"); rf_pause(); return true; } if (count_73($flists) <= 0) { echo_msg(2, "エピソードがありません"); rf_pause(); return true; } while(1==1) { $flist2 = rf_pcast_select_episode($flists,$audee_program,$url); if ($flist2 === false) { return true; } $mp3_list = ad_get_mp3_list($flist2,$nmax,0); $cnt = count_73($mp3_list); if ($cnt <= 0) { echo_msg(2, "PCでは配信されていないようです。"); rf_pause(); continue; } foreach($mp3_list as $list) { $no = $list['no']; $title = $list['title']; echo_msg(2,"$no $title"); } echo_msg(2, ""); $ans2 = echo_yesno(2,"ダウンロードを実行しますか？(y/N) "); if ($ans2 != "y" && $ans2 != "Y" ) { continue; } rf_pcast_mp3_download($cnt,$dir,$sdir,$audee_program2,$mp3_list,$nmax,$art,$opt); rf_pause(); } return true; } function rf_pcast_get_fmo($home,$page) { $lists[0] = "https://feeds.soundcloud.com/users/soundcloud:users:187539410/sounds.rss"; return $lists; } function rf_pcast_add_user_preset_test($fil,$add_rss) { $texts = @file($fil); if ($texts === false) { return false; } $flist = array(); $exist_flag = 0; foreach($texts as $text) { $text = trim($text); if ($text == "") continue; if (substr($text,0,1) == ";") continue; $parts = explode(",",$text); $count = count_73($parts); if ($count <= 0) continue; if ($count >= 3) { continue; } else if ($count == 2) { $rss = trim($parts[1]); if ($rss == $add_rss) { $exist_flag = 1; break; } } else if ($count == 1) { $rss = trim($parts[0]); if ($rss == $add_rss) { $exist_flag = 1; break; } } } if ($exist_flag == 1) { return true; } return false; } function rf_pcast_get_google($home,$page,$pub,$kw) { global $ui_mode; $lists = array(); $pub = trim($pub); $kw = trim($kw); if ($kw == "" && $pub == "") { return $lists; } $kw2 = trim("$pub $kw"); $keyword = urlencode($kw2); echo_msg(2,"キーワード : '$kw2'"); echo_msg(2,""); $url = $page.$keyword; if ($kw == "@") $url = $home; $html = rf_file_get_contents($url); if ($html === false) return $lists; $result = rf_pcast_get_google_result($html); if ($kw == "@") { $data = rf_pcast_get_google_recommend($result); } else { $data = rf_pcast_get_google_normal($result); } $lists = array(); foreach ($data as $d) { if ($d == "") continue; $d0 = $d[0]; $d1 = $d[1]; $d6 = $d[6]; if ($d6 == "") continue; if ($d1 == "") continue; if ($pub != "") { if (stristr($d1,$pub) === false) continue; } if ($ui_mode == 2) { $lists[] = array('title'=>"$d0",'val'=>"$d6"); } else { $lists[] = $d6; } } $lists= array_unique($lists, SORT_REGULAR); return $lists; } function rf_http_check_pub($pub) { if (strpos($pub,"http://") !== false) return false; if (strpos($pub,"https://") !== false) return false; return true; } function rf_http_check_rss($rss) { if (substr($rss,0,7) != "http://" && substr($rss,0,8) != "https://") { return false; } if (strpos($rss,"http://",1) !== false) return false; if (strpos($rss,"https://",1) !== false) return false; return true; } function rf_pcast_get_flist_preset($fil) { $flist = array(); $texts = @file($fil); if ($texts === false) { return $flist; } $cnt = count_73($texts); if ($cnt <= 0 ) return $flist; $errcnt = 0; for($i= 0 ; $i < $cnt ; $i++) { $text = $texts[$i]; $title = ""; $pub = ""; $kw = ""; $rss = ""; $text = trim($text); if ($text == "") continue; if (substr($text,0,1) == ";") continue; $parts = explode(",",$text); $count = count_73($parts); switch($count) { case 1: $title = trim($parts[0]); $rss = trim($parts[0]); $chk = rf_http_check_rss($rss); if ($chk === false) { $texts[$i] = ";ERR ".$texts[$i]; $errcnt++; continue 2; } break; case 2: $title = trim($parts[0]); $pub = trim($parts[1]); $chk = rf_http_check_pub($pub); if ($chk === true) break; $rss = $pub; $pub = ""; $chk = rf_http_check_rss($rss); if ($chk === false) { $texts[$i] = ";ERR ".$texts[$i]; $errcnt++; continue 2; } break; case 3: $title = trim($parts[0]); $pub = trim($parts[1]); $kw = trim($parts[2]); $chk1 = rf_http_check_pub($pub); $chk2 = rf_http_check_pub($kw); if ($chk1 === true && $chk2 === true) break; $texts[$i] = ";ERR ".$texts[$i]; $errcnt++; continue 2; default: $texts[$i] = ";ERR ".$texts[$i]; $errcnt++; continue 2; } $flist[] = array('title'=>$title,'pub'=>$pub,'kw'=>$kw,'rss'=>$rss,'val'=>"$title,$rss"); } if ($errcnt > 0) { $contents = ""; foreach($texts as $text) { $contents .= $text; } file_put_contents($fil,$contents,LOCK_EX); } return $flist; } function rf_pcast_get_flist_cfm_preset($fil) { $flist = array(); $texts = @file($fil); if ($texts === false) { return $flist; } $cnt = count_73($texts); if ($cnt <= 0 ) return $flist; for($i= 0 ; $i < $cnt ; $i++) { $text = trim($texts[$i]); if ($text == "") continue; if (substr($text,0,1) == ";") continue; $parts = explode(",",$text); $count = count_73($parts); if ($count != 2) continue; $id = trim($parts[0]); $title = trim($parts[1]); $flist[] = array('title'=>$title,'val'=>"$id,$title"); } return $flist; } function rf_pcast_get_preset($fil,$typ) { global $ui_mode; $ans = array(); $flist = rf_pcast_get_flist_preset($fil); $count = count_73($flist); if ($count <= 0) { echo_msg(2,"not found $fil or empty"); rf_pause(); return $ans; } while(1==1) { $ans = array(); $opt = array( "title" => "プリセット一覧 ($count)", "input_type" => $typ, "page_control" => 1, "return_mes" => "終了", "input_mes" => "プリセットを選択してください", "mode" => 1, "multi" => 0, "confirm" => 0, "ht_selid" => "" ); $cnt1 = count_73($flist); echo_msg(2,""); $no = rf_pctl_disp($flist, $opt); if ($ui_mode == 2) return; $cnt2 = count_73($no); if ($cnt1 == $cnt2) { $ans1 = echo_yesno(2, "一括ダウンロードを開始しますか ? (y/N) : "); if ($ans1 == "y" || $ans == "Y") { $dt = date("Ymd"); rf_batsh_rec($ex_podcast, 1, $dt, 0, ""); echo_msg(2, "一括ダウンロードを開始しました"); echo_msg(2, "処理はバックグラウンドで行われます"); rf_pause(); } return $ans; } $ans0 = $no[0]; if ($ans0 == "r") { return $ans; } if ($ans0 == "e") { echo_msg(2, "入力エラー"); rf_pause(); continue; } if ($ans0 == "z") { echo_msg(2, "リストが空です"); rf_pause(); return $ans; } break; } foreach($no as $n) { $sel = $n-1; $title = $flist[$sel]['title']; $pub = $flist[$sel]['pub']; $kw = $flist[$sel]['kw']; $rss = $flist[$sel]['rss']; $ans[] = array('pub'=>$pub, 'kw'=>$kw, 'rss'=>$rss, 'title'=>$title); } return $ans; } function rf_pcast_get_lfr($url,$home) { $page = $home."/genre/".$url."/"; $xmlObject = url2xml($page); $result = $xmlObject->xpath( '//div[@class="p-pagination p-pagination--start"]//a[@class="page-numbers"]'); $program_pages[] = $page; foreach($result as $val) { $href = (string)$val->attributes()->href; $program_pages[] = $href; } $hrefs = array(); foreach($program_pages as $url) { echo_msg(2,$url); $xmlObject = url2xml($url); $result = $xmlObject->xpath( '//div[@class="p-program"]/a' ); foreach($result as $val) { if (empty($val->attributes()->href)) continue; $href = $home.(string)$val->attributes()->href."/"; $ttl = (string)$val->attributes()->{'aria-label'}; $hrefs[] = $href; } } $cnt = count_73($hrefs); $lists = array(); foreach($hrefs as $href) { echo "."; $html = rf_file_get_contents($href); if ($html === false) continue; $p1 = strpos($html,'rssfeed'); if ($p1 === false) continue; $p1 = $p1 + 10; $p2 = strpos($html,'/podcast.rss'); if ($p2 === false) continue; $p2 = $p2 + 12; $html2 = substr($html ,0,$p2); $rss = substr($html2,$p1); $rss = str_replace("\\",'',$rss); $lists[] = $rss; } echo "\n"; $cnt = count_73($lists); return $lists; } function rf_pcast_get_yfm($home,$page) { $lists = array(); $html = @file($page); if ($html === false) return false; $ans = array(); $ans1 = preg_grep('@podcast.rss@',$html); if ($ans1 !== false) $ans = array_merge($ans,$ans1); $ans1 = preg_grep('@podcast/rss@',$html); if ($ans1 !== false) $ans = array_merge($ans,$ans1); foreach($ans as $txt) { echo "."; $txt2 = explode('"',$txt); if (count_73($txt2) > 2) { $rss = trim($txt2[1]); $lists[] = $rss; } } echo "\n"; $cnt = count_73($lists); return $lists; } function rf_pcast_get_joqr($home,$page) { $html = rf_file_get_contents($page); $pattern = '/<script[^>](.*?)json">(.*)<\/script>/is'; $ret = preg_match($pattern, $html, $script); if ($ret === false) { echo_msg(2,"contents error"); return false; rf_pause(); } if ($ret == 0) { echo_msg(2,"contents error(not match)"); return false; rf_pause(); } $json = json_decode($script[2],true); if ($json == null) { echo_msg(2,"json decode error"); return false; rf_pause(); } $json2 = $json['props']['pageProps']['categoriesWithPrograms']; $lists = array(); foreach($json2 as $var) { $pgm = $var['programs']; foreach($pgm as $feed) { $rss = $feed['directoryLinks']['rssFeed']; $lists[] = $rss; } } return $lists; } function rf_pcast_get_nack5($home,$page) { $lists = array(); $html = @file($page); if ($html === false) return false; $ans = preg_grep('@rss.xml@',$html); if ($ans === false) return false; foreach($ans as $txt) { echo "."; $txt2 = explode('"',$txt); if (count_73($txt2) > 2) { $rss = trim($txt2[1]); if (substr($rss,0,2) == "..") $rss = substr($rss,2); $rss = $home.$rss; $lists[] = $rss; } } echo "\n"; $cnt = count_73($lists); return $lists; } function rf_pcast_get_crk($home,$page) { $lists = array(); $html = @file($page); if ($html === false) return false; $ans = preg_grep('@プレイヤーに登録@',$html); if ($ans === false) return false; foreach($ans as $txt) { echo "."; $txt2 = explode('"',$txt); if (count_73($txt2) > 2) { $rss = trim($txt2[1]); if (strpos($rss,".xml") !== false) { $lists[] = $rss; } } } echo "\n"; $cnt = count_73($lists); return $lists; } function rf_pcast_get_kbs($home,$page) { $lists = array(); $html = @file($page); if ($html === false) return false; $ans = preg_grep('@RSS Podcast KBS@',$html); if ($ans === false) return false; foreach($ans as $txt) { echo "."; $txt2 = explode('"',$txt); if (count_73($txt2) > 2) { $rss = trim($txt2[1]); if (strpos($rss,".xml") === false) continue; if (substr($rss,0,5) != "../..") continue; $rss = substr($rss,5); $rss = $home.$rss; $lists[] = $rss; } } echo "\n"; $cnt = count_73($lists); return $lists; } function rf_pcast_get_mbs($home,$page) { $xmlObject = url2xml($page); $result = $xmlObject->xpath( '////div'); $lists = array(); foreach($result as $val) { if (empty($val->attributes()->class)) continue; if ($val->attributes()->class != "program") continue; if (empty($val->ul->li[0]->a)) continue; $val2 = $val->ul->li[0]->a; $href = (string)$val2->attributes()->href; $url = $home.$href."rss.xml"; $lists[] = $url; } return $lists; } function rf_pcast_get_bayfm($home,$page) { $base = "https://omny.fm/shows/"; $lists[0] = $base."bayfm-program01/playlists/podcast.rss"; $lists[1] = $base."bayfm-program02/playlists/podcast.rss"; $lists[2] = $base."bayfm-program03/playlists/podcast.rss"; return $lists; } function rf_pcast_nhktop($url) { $lists = array(); $rand = mt_rand() / mt_getrandmax(); $exurl = $url.'?rand='.$rand; $options = [ 'http' => [ 'method' => 'GET', 'header' => 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36\r\n' ] ]; $context = stream_context_create($options); $xmlString = @file_get_contents($exurl, false, $context); if ($xmlString === false) { return $lists; } $xml = simplexml_load_string($xmlString); foreach ($xml->data as $program) { $ttl = $program->title; $rss = $program->regist; $lists[] = array('title'=>$ttl,'val'=>$rss); } return $lists; } function rf_jfn_getmaxpage($baseurl) { $xpath = rf_jfn_fetchdom($baseurl . '/program'); if (!$xpath) { return false; } $nodes = $xpath->query('//a[contains(@class, "button-pagination-link") or contains(@href, "page=")]'); $maxpage = 1; foreach ($nodes as $node) { $href = $node->getAttribute('href'); if (preg_match('/page=([0-9]+)/', $href, $m)) { $p = (int)$m[1]; if ($p > $maxpage) { $maxpage = $p; } } $val = (int)trim($node->textContent); if ($val > $maxpage) { $maxpage = $val; } } return $maxpage; } function rf_jfn_getmaxpage2($baseurl) { $options = [ 'http' => [ 'header' => "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)\r\n" ] ]; $context = stream_context_create($options); $url = "{$baseurl}/program?page=1"; $html = @file_get_contents($url, false, $context); if ($html === false) return false; if (!preg_match_all('/href="\/program\?page=(\d+)"/u', $html, $matches)) return false; if (empty($matches[1])) return false; $maxpage = max(array_map('intval', $matches[1])); return $maxpage; } function rf_jfn_fetchdom($url) { $options = [ 'http' => [ 'method' => 'GET', 'header' => "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36\r\n", 'timeout' => 20 ] ]; $context = stream_context_create($options); $html = @file_get_contents($url, false, $context); if (!$html) { return false; } $dom = new DOMDocument(); @$dom->loadHTML(mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8')); $xpath = new DOMXPath($dom); return $xpath; } function rf_jfn_getallprograms2($baseurl, $startpage, $endpage) { set_time_limit(120); $programs = []; for ($p=$startpage; $p<=$endpage; $p++) { $url = "{$baseurl}/program?page={$p}"; $html = @file_get_contents($url, false, $context); if ($html === false) continue; if (!preg_match_all('/<article[^>]*>([\s\S]*?)<\/article>/u', $html, $articles)) { return false; } foreach ($articles[1] as $article_html) { $href = ''; $title = ''; if (preg_match('/<a[^>]+href="(\/program\/[^"]+)"/u', $article_html, $m_href)) { $href = $m_href[1]; } else { continue; } if (preg_match('/<h3[^>]*data-role="card-title"[^>]*>(.*?)<\/h3>/us', $article_html, $m_title)) { $title = trim(strip_tags($m_title[1])); } $pgmid = str_replace('/program/','',$href); $pgmurl = $url.'/program/'.$pgmid.'/voice'; $base64ttl = base64_encode($title); $programs[] = ['title => $title, 'val' => "{$pgmurl},{$base64ttl}"];
        }
    }

    //header('Content-Type: application/json; charset=utf-8');
    //echo json_encode($programs, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

    return $programs;
}
//------------------------------------------------------------
function rf_jfn_makeprogramlists($programs)
{
    $lists = [];
    foreach($programs as $pgmid => $data) {
        $lists[] = ['title' => $data['title'], 'val' => "{$data['title']},{$data['image']}"];
    }
    return $lists;
}
//------------------------------------------------------------
// new LFR podcast 2026/11/02
// ニッポン放送 PODCAST STATION -ポッドキャストステーション-
//------------------------------------------------------------
function rf_lfr_getmaxpage($baseurl,$sect)
{
    if ($sect == 'all') {
       $url = $baseurl."/$sect/";
    } else {
       $url = $baseurl."/genre/$sect/";
    }
    $html = @file_get_contents($url);
    if ($html === false) return false;

    if (!preg_match_all('/<a[^>]+class="[^"]*page-numbers[^"]*"[^>]*>(\d+)<\/a>/u', $html, $matches)) return false;
    if (empty($matches[1])) return false;

    $max_page = max(array_map('intval', $matches[1]));
    return $max_page;
}
//------------------------------------------------------------
/*
function rf_lfr_getallprograms($baseurl, $sect, $startpage, $endpage)
{
    libxml_use_internal_errors(true);
    $options = [
        'http' => [
            'header' => "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)\r\n"
        ]
    ];
    $context = stream_context_create($options);

    if ($sect != 'all') {
        $startpage = 1;
        $endpage   = 1;
    }

    $all_programs = [];
    for ($p=$startpage;$p<=$endpage;$p++) {
        if ($sect == 'all') {
            if ($p == 1) {
                $url = $baseurl.'/all/';
            } else {
                $url = $baseurl."/all/page/{$p}/";
            }
        } else {
            $url = $baseurl."/genre/{$sect}/";
        }

        $html = @file_get_contents($url, false, $context);
        if ($html === false) continue;
        
        $dom = new DOMDocument();
        @$dom->loadHTML('<?xml encoding="utf-8"?>' . $html);
        $xpath = new DOMXPath($dom);
        $items = $xpath->query("//li[contains(@class, 'p-programList__item')]");

        foreach ($items as $item) {
            $links = $xpath->query(".//a[contains(@class, 'p-program__thumb')]", $item);
            if ($links->length === 0) continue;
            $linkNode = $links->item(0);

            $href = $linkNode->getAttribute('href');
            $ariaLabel = $linkNode->getAttribute('aria-label');

            $title = '';
            if (preg_match('/「(.*?)」/u', $ariaLabel, $match)) {
                $title = $match[1];
            }

            $imgs = $xpath->query(".//img", $linkNode);
            $imgSrc = ($imgs->length > 0) ? $imgs->item(0)->getAttribute('src') : '';

            $all_programs[] = [
                'title' => $title,
                'url'   => $href,
                'image' => $imgSrc,
            ];
        }
    }
    //header('Content-Type: application/json; charset=utf-8');
    //echo json_encode($all_programs, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

    return $all_programs;
}
*/
//------------------------------------------------------------
function rf_lfr_getallprograms2($baseurl, $sect, $startpage, $endpage)
{
    set_time_limit(60);

    $all_programs = [];
    $options = [
        'http' => [
            'header' => "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)\r\n"
        ]
    ];
    $context = stream_context_create($options);
    $no = 0;

    for ($p=$startpage;$p<=$endpage;$p++) {
        if ($sect == 'all') {
            if ($p == 1) {
                $url = $baseurl."/$sect/";
            } else {
                $url = $baseurl."/$sect/page/{$p}/";
            }
        } else{
            if ($p == 1) {
                $url = $baseurl."/genre/$sect/";
            } else {
                $url = $baseurl."/genre/$sect/page/{$p}/";
            }
        }
        $html = @file_get_contents($url, false, $context);
        if ($html === false) {
            continue;
        }

        if (!preg_match_all('/<li[^>]*class="[^"]*p-programList__item[^"]*"[^>]*>([\s\S]*?)<\/li>/u', $html, $items)) {
            return false;
        }
        
        foreach ($items[1] as $item_html) {
            $href = '';
            $ariaLabel = '';
            $imgSrc = '';

            if (preg_match('/<a[^>]+href="([^"]+)"/u', $item_html, $m_href)) {
                $href = $m_href[1];
                if (empty($href)) continue;
            }

            if (preg_match('/aria-label="([^"]+)"/u', $item_html, $m_aria)) {
                $ariaLabel = $m_aria[1];
            }
/*
            if (preg_match('/<img[^>]+src="([^"]+)"/u', $item_html, $m_img)) {
                $imgSrc = $m_img[1];
            }
*/
            $title = '';
            if (preg_match('/「(.*?)」/u', $ariaLabel, $m_title)) {
                $title = $m_title[1];
            }

            $no++;
            $all_programs[] = [
                'title' => "$no $title",
                'val'   => $href,
            ];
        }
    }

    //header('Content-Type: application/json; charset=utf-8');
    //echo json_encode($all_programs, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

    return $all_programs;
}
//------------------------------------------------------------
/*
function rf_lfr_getsectprograms2($baseurl,$sect)
{
    set_time_limit(60);

    $all_programs = [];
    $options = [
        'http' => [
            'header' => "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)\r\n"
        ]
    ];
    $context = stream_context_create($options);

    $url = $baseurl."/grnre/$sect/";
    $html = @file_get_contents($url, false, $context);
    if ($html === false) return $all_programs;

        if (!preg_match_all('/<li[^>]*class="[^"]*p-programList__item[^"]*"[^>]*>([\s\S]*?)<\/li>/u', $html, $items)) {
            return false;
        }
        
        foreach ($items[1] as $item_html) {
            $href = '';
            $ariaLabel = '';
            $imgSrc = '';

            if (preg_match('/<a[^>]+href="([^"]+)"/u', $item_html, $m_href)) {
                $href = $m_href[1];
                if (empty($href)) continue;
            }

            if (preg_match('/aria-label="([^"]+)"/u', $item_html, $m_aria)) {
                $ariaLabel = $m_aria[1];
            }

            if (preg_match('/<img[^>]+src="([^"]+)"/u', $item_html, $m_img)) {
                $imgSrc = $m_img[1];
            }

            $title = '';
            if (preg_match('/「(.*?)」/u', $ariaLabel, $m_title)) {
                $title = $m_title[1];
            }

            $all_programs[] = [
                'title' => $title,
                'url'   => $href,
                'image' => $imgSrc
            ];
        }

    //header('Content-Type: application/json; charset=utf-8');
    //echo json_encode($all_programs, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

    return $all_programs;
}
*/
//------------------------------------------------------------
function rf_lfr_getrsshref($baseurl, $pgm)
{
    $detail_url = $baseurl . "/$pgm/";

    $detail_html = @file_get_contents($detail_url, false, $context);
        
    if ($detail_html === false) return false;
    if (!preg_match('/"rssfeed"\s*:\s*"([^"]+)"/', $detail_html, $match_rss)) return false;
    $hrefrss = str_replace('\\/', '/', $match_rss[1]);
    return $hrefrss;
}
//------------------------------------------------------------
