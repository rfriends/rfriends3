#!/bin/sh
# -----------------------------------------
# rfriends3 (at,cron -> systemd )
# 作成　2026/02/16
# 修正　2026/02/16
# 確認　
# -----------------------------------------
cd `dirname $0`
base=`pwd`
ver=$base/_Rfriends3

if [ ! -f $ver ]; then
	echo $ver ファイルがありません
	echo ディレクトリ構成が間違っています。
	echo
	exit
fi
# -----------------------------------------
echo
cat $ver
echo ベースディレクトリは　$base です
echo
echo "ジョブスケジューリングをat,cron から systemd に変更します。"
echo
# -----------------------------------------
systemdini=$base/config/systemd.ini
if [ ! -f $systemdini ]; then
    echo $systemdini ファイルが存在しません
    exit
fi
# -----------------------------------------
sys=`pgrep -o systemd`
ret=$?
if [ $ret -ne 0 ]; then
    echo "systemd を確認できません。
    exit
fi

if [ $sys -ne 1 ] ;then
    echo "systemd が動作していません。
    exit
fi
# -----------------------------------------
echo 既存の予約および自動実行設定は破棄されます
echo
read -p "実行しますか ? (y/N): " yn
case "$yn" in [yY]*) ;; *) echo "abort." ; exit ;; esac
# --------------------------------------
atq | awk '{print $1}' | xargs atrm
echo 予約（at que）をクリアしました

crontab -r
echo 自動実行設定（crontab）を初期化しました
# --------------------------------------
# システムの起動時にサービスを起動し、ログアウト後もそのまま起動した状態を保つ
user=`whoami`
loginctl enable-linger $user
if [ $? -ne 0 ]; then
    echo loginctl の実行に失敗しました
    exit
fi
# --------------------------------------
cat <<EOF > config/systemd.ini
; ------------------------------------------------
; systemd.ini
; 2025/01/11 new
; ------------------------------------------------
; システム管理方式
;
; cron_type_lnx
; = 0 cron
; = 1 systemd
;
; at_type_lnx
; = 0 at
; = 1 systemd
;
; ------------------------------------------------
[systemd]
cron_type_lnx = 1
at_type_lnx = 1
; ------------------------------------------------
EOF

echo $systemdiniファイルをsystemdタイプに設定しました。
echo
echo 正常終了しました。
# -----------------------------------------
# 終了
# -----------------------------------------
echo
echo finished
exit
# -----------------------------------------
